(function(){
"use strict";
var ROOT=document.getElementById("rl-app");if(!ROOT)return;var $=function(s){return ROOT.querySelector(s)};
var FIELDS=[
 {k:"name",l:"Software Name",q:"What is the name of the software?",req:1,ph:"e.g. Microsoft 365 Business"},
 {k:"description",l:"Description",q:"Add a short description.",ta:1,ph:"What it is used for"},
 {k:"vendor",l:"Vendor",q:"Who is the vendor?",ph:"e.g. Microsoft"},
 {k:"website",l:"Website",q:"What is the website address?",ph:"https://"},
 {k:"username",l:"Username",q:"What is the username?"},
 {k:"dateFrom",l:"Date From",q:"When does the subscription start?",date:1,req:1},
 {k:"dateTo",l:"Date To",q:"When does it expire?",date:1,req:1},
 {k:"cost",l:"Cost excl. VAT (€)",q:"What is the cost excluding VAT (€)?",num:1,req:1},
 {k:"emails",l:"Notification emails",q:"Which e-mail addresses should receive the reminders? For several, separate them with a comma (,) or a semicolon (;) (optional).",ta:1,email:1,hint:"For several addresses use a comma (,) or a semicolon (;)",ph:"name@example.com, other@example.com"}
];
var REMIND=[7,14,30,60,90];
var S={items:[],contracts:[],tenders:[],contractors:[],provisions:[],trash:{sw:[],ct:[],tn:[],co:[],pv:[]},cat:"sw",loaded:{},uid:null,db:null,assets:null,dl:null,filter:"all",q:"",open:null,openCat:null,cw:null,impCat:null,mem:false,unsub:null};

function esc(s){return String(s==null?"":s).replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]})}
function pad(n){return (n<10?"0":"")+n}
function iso(d){return d.getFullYear()+"-"+pad(d.getMonth()+1)+"-"+pad(d.getDate())}
function todayIso(){return iso(new Date())}
function parseIso(s){var m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(s||"");if(!m)return null;var d=new Date(+m[1],+m[2]-1,+m[3]);return isNaN(d)?null:d}
function addDays(s,n){var d=parseIso(s);if(!d)return "";d.setDate(d.getDate()+n);return iso(d)}
function addYear(s){var d=parseIso(s);if(!d)return "";d.setFullYear(d.getFullYear()+1);d.setDate(d.getDate()-1);return iso(d)}
function fmtDate(s){var d=parseIso(s);return d?pad(d.getDate())+"/"+pad(d.getMonth()+1)+"/"+d.getFullYear():"—"}
function money(n){var v=Number(n);return isFinite(v)?"€"+v.toLocaleString("en-GB",{minimumFractionDigits:2,maximumFractionDigits:2}):"—"}
function daysLeft(s){var d=parseIso(s),t=parseIso(todayIso());return d?Math.round((d-t)/864e5):null}
function status(it){
  var d=daysLeft(it.dateTo);
  if(d==null)return {k:"ok",t:"No date",d:null};
  if(d<0)return {k:"bad",t:"Expired",d:d};
  if(d<=(+it.remindDays||30))return {k:"warn",t:"Due soon",d:d};
  return {k:"ok",t:"Active",d:d};
}
function dayText(d){if(d==null)return "";if(d<0)return Math.abs(d)+" day"+(Math.abs(d)==1?"":"s")+" ago";if(d==0)return "today";return "in "+d+" day"+(d==1?"":"s")}
function toast(m){
  if(toastUndo.pend){var p=toastUndo.pend;toastUndo.pend=null;clearTimeout(toastUndo.h);p.exp&&p.exp()}
  var t=$("#toast");t.textContent=m;t.hidden=false;clearTimeout(toast.h);toast.h=setTimeout(function(){t.hidden=true},3200)
}
/* A message with an Undo button for 8 s. onExpire runs when the time is up (or when another message replaces it), e.g. to really delete a file. */
function toastUndo(msg,onUndo,onExpire,el){
  if(toastUndo.pend){var p=toastUndo.pend;toastUndo.pend=null;p.exp&&p.exp()}
  clearTimeout(toast.h);clearTimeout(toastUndo.h);
  var t=$("#toast");t.innerHTML=esc(msg)+' <button type="button" class="toast-undo" data-act="undo">'+(el?"Αναίρεση":"Undo")+'</button>';t.hidden=false;
  toastUndo.pend={exp:onExpire};toastUndo.fn=onUndo;
  toastUndo.h=setTimeout(function(){var q=toastUndo.pend;toastUndo.pend=null;t.hidden=true;q&&q.exp&&q.exp()},8000);
}
function doUndo(){var f=toastUndo.fn;toastUndo.pend=null;toastUndo.fn=null;clearTimeout(toastUndo.h);$("#toast").hidden=true;if(f)f()}
function norm(o){
  return {name:String(o.name||"").trim(),description:String(o.description||"").trim(),vendor:String(o.vendor||"").trim(),
    website:String(o.website||"").trim(),username:String(o.username||"").trim(),emails:String(o.emails||"").trim(),
    dateFrom:o.dateFrom||"",dateTo:o.dateTo||"",cost:o.cost===""||o.cost==null?0:Number(o.cost),
    remindDays:+o.remindDays||30,attachments:o.attachments||[],history:o.history||[],milestones:o.milestones||[],budget:o.budget||[],custom:o.custom||{},createdAt:o.createdAt||Date.now(),sample:!!o.sample};
}
function uid(){return "s"+Date.now().toString(36)+Math.random().toString(36).slice(2,6)}

/* ---------- Ρυθμίσεις: general settings, custom fields, backup / restore (3.12.0) ---------- */
var ST_COLLS=["software","contracts","tenders","contractors"];
var ST_CAT={sw:"software",ct:"contracts",tn:"tenders",co:"contractors"};
var ST_NAMES={software:"Λογισμικά",contracts:"Συμβάσεις",tenders:"Διαγωνισμοί",contractors:"Ανάδοχοι",provisions:"Γενικές Πρόνοιες"};
var BK_COLLS=ST_COLLS.concat(["provisions"]); /* collections in a backup (custom fields exist only for ST_COLLS) */
var CF_TYPES={text:"Κείμενο",number:"Αριθμός / Ποσό",date:"Ημερομηνία",select:"Λίστα επιλογών (drop-down)"};
var ST_CACHE=null;
function stNorm(s){
  s=s&&typeof s==="object"?s:{};
  var vat=Number(s.vat);vat=s.vat===""||s.vat==null||!isFinite(vat)?19:Math.max(0,Math.min(100,vat));
  var rd=Math.round(Number(s.remindDays));rd=isFinite(rd)&&rd>=1?Math.min(365,rd):30;
  var cf={},cfs=s.customFields&&typeof s.customFields==="object"?s.customFields:{};
  ST_COLLS.forEach(function(c){
    var seen={};cf[c]=(Array.isArray(cfs[c])?cfs[c]:[]).filter(function(f){
      if(!f||!/^[A-Za-z0-9_-]{1,40}$/.test(String(f.id||""))||!String(f.label||"").trim()||seen[f.id])return false;seen[f.id]=1;return true;
    }).slice(0,30).map(function(f){
      var t=CF_TYPES[f.type]?f.type:"text";
      return {id:String(f.id),label:String(f.label).trim().slice(0,80),type:t,options:t==="select"&&Array.isArray(f.options)?f.options.map(function(o){return String(o).trim().slice(0,100)}).filter(function(o,i,a){return o&&a.indexOf(o)===i}).slice(0,50):[]};
    });
  });
  return {vat:vat,remindDays:rd,customFields:cf};
}
function stGet(){
  if(ST_CACHE)return ST_CACHE;
  var s=null;
  if(window.RL_CFG&&window.RL_CFG.settings)s=window.RL_CFG.settings;
  else{try{s=JSON.parse(localStorage.getItem("rl.settings")||"null")}catch(e){}}
  return (ST_CACHE=stNorm(s));
}
async function stSave(obj){
  obj=stNorm(obj);
  if(window.RL_SAVE_SETTINGS){
    try{var res=await window.RL_SAVE_SETTINGS(obj);window.RL_CFG.settings=res.settings||obj}
    catch(e){toast(e&&e.status===403?"Μόνο οι διαχειριστές μπορούν να αλλάξουν τις ρυθμίσεις":"Αποτυχία αποθήκευσης ρυθμίσεων: "+((e&&e.message)||""));return false}
  }else{try{localStorage.setItem("rl.settings",JSON.stringify(obj))}catch(e){toast("Δεν ήταν δυνατή η αποθήκευση των ρυθμίσεων σε αυτόν τον browser");return false}}
  ST_CACHE=null;return true;
}
function bdVat(){return stGet().vat/100}
function defRemind(){return stGet().remindDays}

/* custom fields: descriptors that plug into the existing forms (keys are "cf_<id>") */
function cfDescs(coll){
  return stGet().customFields[coll].map(function(f){
    return {k:"cf_"+f.id,l:f.label,q:f.label+";",cf:1,id:f.id,num:f.type==="number",date:f.type==="date",opts:f.type==="select"?f.options:null};
  });
}
function cfInput(f,v,id){
  v=v==null?"":v;
  if(f.opts){
    var o=f.opts.slice();if(v!==""&&o.indexOf(String(v))<0)o.push(String(v));
    return '<select id="'+id+'"><option value="">—</option>'+o.map(function(x){return '<option value="'+esc(x)+'"'+(String(v)===x?" selected":"")+'>'+esc(x)+'</option>'}).join("")+'</select>';
  }
  if(f.date)return '<input id="'+id+'" type="date" value="'+esc(v)+'">';
  if(f.num)return '<input id="'+id+'" type="number" step="any" inputmode="decimal" value="'+esc(v)+'" autocomplete="off">';
  return '<input id="'+id+'" type="text" value="'+esc(v)+'" autocomplete="off">';
}
function cfErr(f,v){
  if(v==null||String(v).trim()==="")return "";
  if(f.num&&!isFinite(Number(v)))return f.l+": πρέπει να είναι αριθμός.";
  if(f.date&&!parseIso(v))return f.l+": μη έγκυρη ημερομηνία.";
  return "";
}
function cfLoad(d,coll){
  cfDescs(coll).forEach(function(f){if(d[f.k]===undefined)d[f.k]=d.custom&&d.custom[f.id]!=null?d.custom[f.id]:""});
}
function cfApply(rec,d,coll){
  var c={};
  cfDescs(coll).forEach(function(f){
    var v=d[f.k];if(v===""||v==null)return;
    c[f.id]=f.num?Number(v):String(v).trim();
  });
  Object.keys(rec).forEach(function(k){if(/^cf_/.test(k))delete rec[k]});
  rec.custom=c;return rec;
}
function cfShow(f,v){
  if(v===""||v==null)return "—";
  if(f.type==="date")return fmtDate(v);
  if(f.type==="number")return Number(v).toLocaleString("en-GB",{maximumFractionDigits:4});
  return String(v);
}
function cfDetail(rec,coll){
  var defs=stGet().customFields[coll];if(!defs.length)return "";
  var c=rec.custom||{};
  return '<div class="sec"><h3>Πρόσθετα πεδία</h3><dl class="kv wl">'+defs.map(function(f){return '<dt>'+esc(f.label)+'</dt><dd'+(f.type==="number"?' class="num"':'')+'>'+esc(cfShow(f,c[f.id]))+'</dd>'}).join("")+'</dl></div>';
}
function cfCols(cat){
  var coll=ST_CAT[cat];if(!coll)return [];
  return stGet().customFields[coll].map(function(f){
    var val=function(it){var v=(it.custom||{})[f.id];return v==null?"":v};
    return cdef("cf_"+f.id,f.label,0,"1fr",{
      v:function(it){var v=val(it);return f.type==="number"&&v!==""?'<span class="num">'+esc(cfShow(f,v))+'</span>':'<span class="sub">'+esc(cfShow(f,v))+'</span>'},
      s:function(it){var v=val(it);return f.type==="number"&&v!==""?Number(v):v}
    });
  });
}
function swF(){return FIELDS.concat(ownOn()?[ownField("software")]:[],cfDescs("software"))}
function coF(){return CO_BASE.concat(cfDescs("contractors"))}
function colsAll(cat){return COLS[cat].concat(cfCols(cat))}
/* export columns (Excel / CSV): one column per custom field, rows in the same order as the base export */
function cfHead(coll){return stGet().customFields[coll].map(function(f){return f.label})}
function cfRow(coll,rec){var c=rec.custom||{};return stGet().customFields[coll].map(function(f){var v=c[f.id];return v==null?"":f.type==="number"&&v!==""?Number(v):v})}
function ctHead(n){return ctHead0(n).concat(cfHead("contracts"))}
function ctRowsOut(n){var l=S.contracts.slice().sort(function(a,b){return (a.dateTo||"").localeCompare(b.dateTo||"")});return ctRowsOut0(n).map(function(r,i){return r.concat(cfRow("contracts",l[i]))})}
function tnHead(n){return tnHead0(n).concat(cfHead("tenders"))}
function tnRowsOut(n){var l=S.tenders.slice().sort(function(a,b){return (a.dateFrom||"").localeCompare(b.dateFrom||"")});return tnRowsOut0(n).map(function(r,i){return r.concat(cfRow("tenders",l[i]))})}
function coHead(){return coHead0().concat(cfHead("contractors"))}
function coRowsOut(){var l=(S.contractors||[]).slice().sort(function(a,b){return String(a.name).localeCompare(String(b.name),"el",{sensitivity:"base"})});return coRowsOut0().map(function(r,i){return r.concat(cfRow("contractors",l[i]))})}
function swHead(){return HEAD.concat(cfHead("software"))}
function swRowsOut(){var l=S.items.slice().sort(function(a,b){return (a.dateTo||"").localeCompare(b.dateTo||"")});return rowsOut().map(function(r,i){return r.concat(cfRow("software",l[i]))})}

/* ---------- minimal ZIP (stored) writer / reader for the backup ---------- */
var CRC_T=null;
function crc32(u8){
  if(!CRC_T){CRC_T=new Int32Array(256);for(var n=0;n<256;n++){var c=n;for(var k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;CRC_T[n]=c}}
  var c2=-1;for(var i=0;i<u8.length;i++)c2=CRC_T[(c2^u8[i])&255]^(c2>>>8);
  return (c2^-1)>>>0;
}
function u8cat(parts){var n=0;parts.forEach(function(p){n+=p.length});var o=new Uint8Array(n),k=0;parts.forEach(function(p){o.set(p,k);k+=p.length});return o}
function zipBuild(entries){
  var enc=new TextEncoder(),parts=[],cen=[],off=0;
  entries.forEach(function(e){
    var nm=enc.encode(e.name),crc=crc32(e.data),sz=e.data.length;
    var lh=new DataView(new ArrayBuffer(30));
    lh.setUint32(0,0x04034b50,true);lh.setUint16(4,20,true);lh.setUint16(6,0x0800,true);lh.setUint16(12,0x21,true);lh.setUint32(14,crc,true);lh.setUint32(18,sz,true);lh.setUint32(22,sz,true);lh.setUint16(26,nm.length,true);
    parts.push(new Uint8Array(lh.buffer),nm,e.data);
    var ch=new DataView(new ArrayBuffer(46));
    ch.setUint32(0,0x02014b50,true);ch.setUint16(4,20,true);ch.setUint16(6,20,true);ch.setUint16(8,0x0800,true);ch.setUint16(14,0x21,true);ch.setUint32(16,crc,true);ch.setUint32(20,sz,true);ch.setUint32(24,sz,true);ch.setUint16(28,nm.length,true);ch.setUint32(42,off,true);
    cen.push(new Uint8Array(ch.buffer),nm);
    off+=30+nm.length+sz;
  });
  var cs=0;cen.forEach(function(p){cs+=p.length});
  var eo=new DataView(new ArrayBuffer(22));
  eo.setUint32(0,0x06054b50,true);eo.setUint16(8,entries.length,true);eo.setUint16(10,entries.length,true);eo.setUint32(12,cs,true);eo.setUint32(16,off,true);
  return u8cat(parts.concat(cen,[new Uint8Array(eo.buffer)]));
}
async function zipRead(buf){
  var u8=new Uint8Array(buf),dv=new DataView(u8.buffer,u8.byteOffset,u8.byteLength),dec=new TextDecoder("utf-8"),eo=-1,i;
  for(i=u8.length-22;i>=Math.max(0,u8.length-65557);i--){if(dv.getUint32(i,true)===0x06054b50){eo=i;break}}
  if(eo<0)throw new Error("Το αρχείο δεν είναι έγκυρο ZIP.");
  var n=dv.getUint16(eo+10,true),p=dv.getUint32(eo+16,true),out={};
  for(i=0;i<n;i++){
    if(dv.getUint32(p,true)!==0x02014b50)throw new Error("Αλλοιωμένο αρχείο ZIP.");
    var method=dv.getUint16(p+10,true),crc=dv.getUint32(p+16,true),csz=dv.getUint32(p+20,true),nl=dv.getUint16(p+28,true),el=dv.getUint16(p+30,true),cl=dv.getUint16(p+32,true),lho=dv.getUint32(p+42,true);
    var name=dec.decode(u8.subarray(p+46,p+46+nl));p+=46+nl+el+cl;
    var st=lho+30+dv.getUint16(lho+26,true)+dv.getUint16(lho+28,true),raw=u8.subarray(st,st+csz),data;
    if(method===0)data=raw;
    else if(method===8&&typeof DecompressionStream!=="undefined"){data=new Uint8Array(await new Response(new Blob([raw]).stream().pipeThrough(new DecompressionStream("deflate-raw"))).arrayBuffer())}
    else throw new Error("Μη υποστηριζόμενη συμπίεση ZIP. Χρησιμοποίησε ένα backup που δημιούργησε το PROCURE360.");
    if(crc32(data)!==crc)throw new Error("Το αρχείο «"+name+"» είναι αλλοιωμένο (αποτυχία ελέγχου CRC).");
    out[name]=data;
  }
  return out;
}

/* ---------- backup ---------- */
function bkAtts(rec){
  var a=(rec.attachments||[]).slice();
  (rec.milestones||[]).forEach(function(m){(m.attachments||[]).forEach(function(x){a.push(x)})});
  return a;
}
function bkData(){return {software:S.items,contracts:S.contracts,tenders:S.tenders,contractors:S.contractors,provisions:S.provisions||[]}}
async function bkCreate(){
  var enc=new TextEncoder(),st=$("#bkMsg"),say=function(t){if(st)st.textContent=t};
  var data=bkData(),entries=[],counts={},files={},missing=[],canRead=!!(S.assets&&S.assets.read);
  say("Συλλογή δεδομένων…");
  BK_COLLS.forEach(function(c){
    var list=(data[c]||[]).map(function(x){return Object.assign({},x)});counts[c]=list.length;
    entries.push({name:"data/"+c+".json",data:enc.encode(JSON.stringify(list))});
  });
  var seen={};
  for(var ci=0;ci<BK_COLLS.length;ci++){
    var list=data[BK_COLLS[ci]]||[];
    for(var i=0;i<list.length;i++){
      var at=bkAtts(list[i]);
      for(var j=0;j<at.length;j++){
        var a=at[j];if(!a||!a.id||seen[a.id])continue;seen[a.id]=1;
        if(!canRead){missing.push(a.name||a.id);continue}
        say("Συνημμένα: "+(a.name||a.id)+"…");
        try{var b=await S.assets.read(a.id);if(!b)throw new Error("empty");
          var bytes=new Uint8Array(await b.arrayBuffer());
          entries.push({name:"files/"+a.id,data:bytes});files[a.id]={name:a.name||a.id,size:bytes.length}}
        catch(e){missing.push(a.name||a.id)}
      }
    }
  }
  entries.push({name:"settings.json",data:enc.encode(JSON.stringify(stGet()))});
  entries.push({name:"articles.json",data:enc.encode(JSON.stringify(articles()))});
  entries.unshift({name:"manifest.json",data:enc.encode(JSON.stringify({app:"PROCURE360",format:1,createdAt:new Date().toISOString(),counts:counts,files:files,missingFiles:missing}))});
  say("Δημιουργία αρχείου…");
  var zip=zipBuild(entries),name="PROCURE360-backup-"+todayIso()+".zip";
  var ok=false;
  if(!S.dl){say("Οι λήψεις δεν είναι διαθέσιμες σε αυτό το περιβάλλον.");return}
  try{await S.dl.save({filename:name,data:zip});ok=true}catch(e){if(e&&e.code==="declined"){say("");return}say("Δεν ήταν δυνατή η αποθήκευση του αρχείου.");return}
  try{localStorage.setItem("rl.lastBackup",new Date().toISOString())}catch(e){}
  var tot=0;BK_COLLS.forEach(function(c){tot+=counts[c]});
  say("Το backup αποθηκεύτηκε: "+name+" ("+tot+" εγγραφές, "+Object.keys(files).length+" συνημμένα"+(missing.length?", δεν συμπεριλήφθηκαν "+missing.length+" συνημμένα: "+missing.slice(0,5).join(", ")+(missing.length>5?"…":""):"")+").");
  if(ok)stFreshInfo();
}
/* ---------- restore ---------- */
function bkPick(){
  var inp=document.createElement("input");inp.type="file";inp.accept=".zip,application/zip";
  inp.onchange=function(){if(inp.files&&inp.files[0])bkLoad(inp.files[0])};inp.click();
}
async function bkLoad(f){
  S.bkResult="";var box=$("#bkRestore");if(!box)return;
  box.innerHTML='<p class="hint">Ανάγνωση «'+esc(f.name)+'»…</p>';
  try{
    var z=await zipRead(await f.arrayBuffer()),dec=new TextDecoder("utf-8");
    var man=z["manifest.json"]?JSON.parse(dec.decode(z["manifest.json"])):null;
    if(!man||man.app!=="PROCURE360")throw new Error("Αυτό δεν είναι backup του PROCURE360.");
    if(man.format!==1)throw new Error("Μη υποστηριζόμενη έκδοση backup ("+man.format+").");
    var data={};
    BK_COLLS.forEach(function(c){var e=z["data/"+c+".json"];var l=e?JSON.parse(dec.decode(e)):[];data[c]=Array.isArray(l)?l.filter(function(x){return x&&/^[A-Za-z0-9_-]{1,64}$/.test(String(x.id||""))}):[]});
    S.bk={zip:z,man:man,data:data,settings:z["settings.json"]?JSON.parse(dec.decode(z["settings.json"])):null,articles:z["articles.json"]?JSON.parse(dec.decode(z["articles.json"])):null};
    bkPreview();
  }catch(e){S.bk=null;box.innerHTML='<p class="err">'+esc(e&&e.message||"Αποτυχία ανάγνωσης του backup")+'</p>'}
}
function bkExisting(c){var m={};(bkData()[c]||[]).forEach(function(x){m[x.id]=x});return m}
function bkPreview(){
  var b=S.bk,box=$("#bkRestore");if(!b||!box)return;
  var rows=BK_COLLS.map(function(c){
    var ex=bkExisting(c),nw=0,up=0;b.data[c].forEach(function(r){ex[r.id]?up++:nw++});
    return '<tr><td>'+esc(ST_NAMES[c])+'</td><td class="num">'+b.data[c].length+'</td><td class="num">'+nw+'</td><td class="num">'+up+'</td></tr>';
  }).join("");
  var nf=Object.keys(b.man.files||{}).length,miss=(b.man.missingFiles||[]).length;
  box.innerHTML='<div class="sec"><h3>Προεπισκόπηση restore</h3><p class="hint">Backup από '+esc(String(b.man.createdAt||"").replace("T"," ").slice(0,16))+' · '+nf+' συνημμένα'+(miss?' · '+miss+' συνημμένα δεν είχαν συμπεριληφθεί στο backup':'')+'</p>'+
   '<div class="tbl"><table><thead><tr><th>Καρτέλα</th><th class="num">Στο backup</th><th class="num">Νέες</th><th class="num">Θα αντικατασταθούν</th></tr></thead><tbody>'+rows+'</tbody></table></div>'+
   '<p class="hint">Οι εγγραφές με το ίδιο αναγνωριστικό αντικαθίστανται από την έκδοση του backup. <b>Δεν διαγράφεται τίποτα</b>: ό,τι υπάρχει τώρα και δεν υπάρχει στο backup μένει όπως είναι.</p>'+
   '<label class="chk"><input type="checkbox" id="bkSet"'+(b.settings?' checked':' disabled')+'> Επαναφορά ρυθμίσεων και custom fields</label> '+
   '<label class="chk"><input type="checkbox" id="bkArt"'+(b.articles?' checked':' disabled')+'> Επαναφορά άρθρων προϋπολογισμού</label>'+
   '<div class="actions"><button class="btn primary" type="button" data-act="bkgo">Επαναφορά τώρα</button><button class="btn" type="button" data-act="bkcancel">Άκυρο</button></div></div>';
}
async function bkRun(){
  var b=S.bk,box=$("#bkRestore");if(!b||!box||S.bkBusy)return;
  var wantSet=!!($("#bkSet")&&$("#bkSet").checked),wantArt=!!($("#bkArt")&&$("#bkArt").checked);
  if(!window.confirm("Να γίνει επαναφορά από το backup; Οι εγγραφές με το ίδιο αναγνωριστικό θα αντικατασταθούν."))return;
  S.bkBusy=true;
  var lines=[],errs=[],log=function(t){box.innerHTML='<p class="hint">'+esc(t)+'</p>'};
  try{
    if(wantSet&&b.settings){log("Επαναφορά ρυθμίσεων…");if(await stSave(b.settings))lines.push("Ρυθμίσεις: επαναφέρθηκαν");else errs.push("Ρυθμίσεις: δεν αποθηκεύτηκαν")}
    if(wantArt&&b.articles){
      log("Επαναφορά άρθρων…");
      try{
        var al=(b.articles||[]).filter(function(a){return a&&a.code});
        if(window.RL_SAVE_ARTICLES){var rr=await window.RL_SAVE_ARTICLES(al);window.RL_CFG.articles=rr.articles}
        else{localStorage.setItem("rl.articles",JSON.stringify(al))}
        lines.push("Άρθρα: "+al.length)
      }catch(e){errs.push("Άρθρα: "+((e&&e.message)||"αποτυχία"))}
    }
    var order=["contractors","tenders","contracts","software","provisions"],cat={software:"sw",contracts:"ct",tenders:"tn",contractors:"co",provisions:"pv"},map={};
    for(var oi=0;oi<order.length;oi++){
      var c=order[oi],ok=0,bad=0,ex=bkExisting(c);
      for(var i=0;i<b.data[c].length;i++){
        var r=Object.assign({},b.data[c][i]),id=r.id;delete r.id;
        log(ST_NAMES[c]+": "+(i+1)+" / "+b.data[c].length+"…");
        try{
          if(window.RL_TRASH&&!ex[id]){try{await window.RL_TRASH.restore(collName(cat[c]),id)}catch(e){}}/* WordPress: a record in the trash must be taken out of it before it can be written again */
          await bkFiles(r,ex[id],c,b);
          if(await save(id,r,cat[c]))ok++;else{bad++;if(errs.length<12)errs.push(ST_NAMES[c]+" «"+(r.title||r.name||id)+"»: δεν αποθηκεύτηκε")}
        }catch(e){bad++;if(errs.length<12)errs.push(ST_NAMES[c]+" «"+(r.title||r.name||id)+"»: "+((e&&e.message)||"σφάλμα"))}
      }
      lines.push(ST_NAMES[c]+": "+ok+" επαναφέρθηκαν"+(bad?", "+bad+" απέτυχαν":""));
    }
  }finally{S.bkBusy=false;S.bk=null}
  ST_CACHE=null;render();
  S.bkResult='<div class="sec"><h3>Ολοκληρώθηκε η επαναφορά</h3><ul class="files">'+lines.map(function(x){return '<li>'+esc(x)+'</li>'}).join("")+'</ul>'+(errs.length?'<p class="err">Προβλήματα:<br>'+errs.map(esc).join("<br>")+'</p>':'')+'</div>';
  var again=$("#bkRestore");if(again)again.innerHTML=S.bkResult;
}
/* attachments of a restored record: reuse a file the record already has (same name and size), otherwise upload it from the backup */
async function bkFiles(rec,existing,coll,b){
  var cache=bkFiles.cache||(bkFiles.cache={});
  var fix=async function(list){
    var out=[];
    for(var i=0;i<(list||[]).length;i++){
      var a=list[i];if(!a||!a.id)continue;
      var have=existing&&bkAtts(existing).filter(function(x){return x.name===a.name&&Number(x.size)===Number(a.size)})[0];
      if(have){out.push(Object.assign({},a,{id:have.id}));continue}
      var bytes=b.zip["files/"+a.id];
      if(!bytes||!S.assets||!S.assets.upload)continue;
      if(cache[b.man.createdAt+a.id]){out.push(Object.assign({},a,{id:cache[b.man.createdAt+a.id]}));continue}
      var ext=(String(a.name||"").split(".").pop()||"").toLowerCase(),type=MIME[ext]||"application/octet-stream";
      var f=new File([bytes],a.name||"file",{type:type});
      var r=await S.assets.upload(f,{type:type,coll:coll});
      cache[b.man.createdAt+a.id]=r.id;out.push({id:r.id,name:a.name,size:r.sizeBytes||a.size});
    }
    return out;
  };
  if(rec.attachments)rec.attachments=await fix(rec.attachments);
  if(Array.isArray(rec.milestones))for(var m=0;m<rec.milestones.length;m++){if(rec.milestones[m]&&rec.milestones[m].attachments)rec.milestones[m].attachments=await fix(rec.milestones[m].attachments)}
}

/* ---------- the Ρυθμίσεις page ---------- */
function stCanEdit(){return !window.RL_CFG||window.RL_CFG.canManage!==false}
function stLast(){var v="";try{v=localStorage.getItem("rl.lastBackup")||""}catch(e){}return v}
function stFreshInfo(){var e=$("#bkLast");if(e)e.innerHTML=stLastHtml()}
function stLastHtml(){
  var v=stLast();if(!v)return '<span class="err">Δεν έχει γίνει backup από αυτόν τον browser.</span>';
  var d=Math.floor((Date.now()-Date.parse(v))/864e5);
  return 'Τελευταίο backup από αυτόν τον browser: <b>'+esc(v.replace("T"," ").slice(0,16))+'</b>'+(d>=30?' <span class="err">(πριν από '+d+' ημέρες — κάνε νέο backup)</span>':'');
}
function stFieldRow(coll,f,i,isNew){
  return '<div class="cfrow" data-coll="'+coll+'" data-i="'+i+'" data-id="'+esc(f.id)+'" data-new="'+(isNew?1:0)+'">'+
   '<label class="f">Όνομα πεδίου<input type="text" data-cf="label" maxlength="80" value="'+esc(f.label)+'" placeholder="π.χ. Κωδικός CPV"></label>'+
   '<label class="f">Τύπος'+(isNew?'<select data-cf="type">'+Object.keys(CF_TYPES).map(function(t){return '<option value="'+t+'"'+(f.type===t?" selected":"")+'>'+CF_TYPES[t]+'</option>'}).join("")+'</select>':'<input type="text" disabled value="'+esc(CF_TYPES[f.type])+'"><input type="hidden" data-cf="type" value="'+f.type+'">')+'</label>'+
   '<label class="f cfopt"'+(f.type==="select"?'':' hidden')+'>Επιλογές (μία ανά γραμμή)<textarea data-cf="options" rows="3">'+esc((f.options||[]).join("\n"))+'</textarea></label>'+
   '<button type="button" class="btn small danger" data-act="cfdel" data-coll="'+coll+'" data-i="'+i+'">Διαγραφή</button></div>';
}
function stCollect(){
  var root=$("#stRoot");if(!root)return null;
  var s={vat:($("#stVat")||{}).value,remindDays:($("#stRem")||{}).value,customFields:{}};
  ST_COLLS.forEach(function(c){s.customFields[c]=[]});
  [].forEach.call(root.querySelectorAll(".cfrow"),function(r){
    var g=function(k){var n=r.querySelector('[data-cf="'+k+'"]');return n?n.value:""};
    var t=g("type");
    s.customFields[r.dataset.coll].push({id:r.dataset.id,label:g("label"),type:t,options:t==="select"?g("options").split(/\r?\n/):[],_new:r.dataset.new==="1"});
  });
  return s;
}
function stRaw(){return S.stDraft||stGet()}
/* ---------- προγραμματισμένο backup (3.13.0): μόνο WordPress, τρέχει στον server ---------- */
function bsFmt(v){if(!v)return "";var d=new Date(v);return isNaN(d)?"":d.toLocaleString("el-GR",{dateStyle:"short",timeStyle:"short"})}
function bsStatus(s){
  var h="";
  if(s.lastRun)h+='Τελευταία εκτέλεση: <b>'+esc(bsFmt(s.lastRun))+'</b> — '+(s.lastOk?'<span>επιτυχία'+(s.lastFile?' ('+esc(s.lastFile)+')':'')+'</span>':'<span class="err">απέτυχε</span>')+(s.lastMessage?': '+esc(s.lastMessage):'')+'.';
  else h+='Δεν έχει γίνει ακόμη προγραμματισμένο backup.';
  if(s.enabled)h+=' '+(s.next?'Επόμενο: μετά τις <b>'+esc(bsFmt(s.next))+'</b>.':'Το πρώτο θα γίνει στον επόμενο έλεγχο (έως 1 ώρα).');
  return h;
}
function bsCard(){
  var c=window.RL_CFG;
  if(!c)return '<div class="stcard"><h3>Προγραμματισμένο backup</h3><p class="hint">Η αυτόματη εβδομαδιαία ή μηνιαία αποθήκευση σε φάκελο δικτύου δεν γίνεται μέσα από τον browser. <b>Έκδοση WordPress:</b> ρυθμίζεται εδώ από διαχειριστή και τρέχει στον server. <b>Έκδοση Windows:</b> τρέξε το <code>Schedule-Backup.bat</code> από τον φάκελο εγκατάστασης. <b>Απλό αρχείο HTML:</b> μόνο χειροκίνητο backup.</p></div>';
  if(!c.canManage)return '<div class="stcard"><h3>Προγραμματισμένο backup</h3><p class="hint">Το προγραμματισμένο backup ρυθμίζεται μόνο από διαχειριστή του WordPress.</p></div>';
  var s=c.backupSchedule||{enabled:false,frequency:"weekly",path:"",keep:8};
  return '<div class="stcard" id="bsCard"><h3>Προγραμματισμένο backup σε φάκελο</h3>'+
   '<p class="hint">Ο server φτιάχνει αυτόματα το ίδιο αρχείο .zip με το χειροκίνητο backup και το αποθηκεύει στον φάκελο που ορίζεις. Μπορεί να είναι φάκελος δικτύου, αρκεί να τον βλέπει και να γράφει σε αυτόν ο server (π.χ. <code>/mnt/backup/procure360</code> ή <code>\\\\server\\share\\procure360</code>). Ο φάκελος πρέπει να είναι <b>εκτός</b> του WordPress site.</p>'+
   '<div class="stgrid">'+
   '<label class="chk"><input type="checkbox" id="bsOn"'+(s.enabled?' checked':'')+'> Ενεργό προγραμματισμένο backup</label>'+
   '<label class="f">Συχνότητα<select id="bsFreq"><option value="weekly"'+(s.frequency==="weekly"?' selected':'')+'>Κάθε εβδομάδα</option><option value="monthly"'+(s.frequency==="monthly"?' selected':'')+'>Κάθε μήνα</option></select></label>'+
   '<label class="f">Φάκελος προορισμού<input id="bsPath" type="text" maxlength="500" value="'+esc(s.path||"")+'" placeholder="/mnt/backup/procure360"></label>'+
   '<label class="f">Πόσα backup να κρατούνται<small>Τα παλαιότερα διαγράφονται αυτόματα (μόνο αρχεία που δημιούργησε η εφαρμογή).</small><input id="bsKeep" type="number" min="1" max="100" step="1" value="'+esc(s.keep||8)+'"></label></div>'+
   '<div class="actions"><button type="button" class="btn primary" data-act="bssave">Αποθήκευση προγράμματος</button><button type="button" class="btn" data-act="bsrun">Αποθήκευση και backup τώρα</button></div>'+
   '<p class="hint err" id="bsErr"></p><p class="hint" id="bsStatus">'+bsStatus(s)+'</p>'+
   '<p class="hint">Ο έλεγχος γίνεται κάθε ώρα από το WP-Cron του WordPress, που τρέχει όταν το site έχει επισκέψεις. Η εκτέλεση μπορεί να καθυστερήσει λίγο μετά την προγραμματισμένη ώρα. Αν αποτύχει, στέλνεται email στους παραλήπτες υπενθυμίσεων (ή στον διαχειριστή) το πολύ μία φορά την ημέρα. Δοκίμασε τη διαδρομή με «Αποθήκευση και backup τώρα».</p></div>';
}
async function bsDo(run){
  var err=$("#bsErr"),st=$("#bsStatus");if(err)err.textContent="";
  var o={enabled:!!($("#bsOn")&&$("#bsOn").checked),frequency:$("#bsFreq")?$("#bsFreq").value:"weekly",path:$("#bsPath")?$("#bsPath").value.trim():"",keep:$("#bsKeep")?+$("#bsKeep").value:8};
  if(!isFinite(o.keep)||o.keep<1||o.keep>100||Math.floor(o.keep)!==o.keep){if(err)err.textContent="Πόσα backup να κρατούνται: δώσε ακέραιο από 1 έως 100.";return}
  if(o.enabled&&!o.path){if(err)err.textContent="Δώσε τον φάκελο προορισμού.";return}
  if(S.bsBusy)return;S.bsBusy=true;
  try{
    var r=await window.RL_BACKUP_SCHEDULE.save(o);window.RL_CFG.backupSchedule=r.schedule;
    if(run){if(st)st.textContent="Γίνεται backup… (μπορεί να πάρει λίγο αν υπάρχουν πολλά συνημμένα)";
      try{var rr=await window.RL_BACKUP_SCHEDULE.run();window.RL_CFG.backupSchedule=rr.schedule;toast("Το backup αποθηκεύτηκε: "+rr.result.file)}
      catch(e){var sc=await window.RL_BACKUP_SCHEDULE.get().catch(function(){return null});if(sc)window.RL_CFG.backupSchedule=sc.schedule;if(err)err.textContent="Το backup απέτυχε: "+((e&&e.message)||"σφάλμα")}
    }else toast("Το πρόγραμμα αποθηκεύτηκε");
  }catch(e){if(err)err.textContent=(e&&e.message)||"Δεν αποθηκεύτηκε.";}
  finally{S.bsBusy=false}
  var s2=window.RL_CFG.backupSchedule;if(s2&&st)st.innerHTML=bsStatus(s2);
}
function renderStPage(){
  var tabs=document.querySelectorAll(".tabs .tab");[].forEach.call(tabs,function(t){t.setAttribute("aria-selected",String(t.id==="tabSt"))});
  ["#btnAdd","#btnImport","#btnExport"].forEach(function(s){var n=$(s);if(n)n.style.display="none"});
  var sq=$("#q");if(sq){sq.style.display="";sq.placeholder="Αναζήτηση στις ρυθμίσεις…"}
  $("#stats").innerHTML="";$("#alerts").innerHTML="";$("#chips").innerHTML="";$("#stats").setAttribute("lang","el");
  $("#note").textContent="Ρυθμίσεις της εφαρμογής: backup και restore, custom fields και γενικές ρυθμίσεις.";
  var st=stRaw(),can=stCanEdit();
  var cfHtml=ST_COLLS.map(function(c){
    var l=st.customFields[c]||[],ex=stGet().customFields[c].map(function(f){return f.id});
    return '<div class="cfgrp"><h4>'+esc(ST_NAMES[c])+'</h4>'+(l.length?l.map(function(f,i){return stFieldRow(c,f,i,ex.indexOf(f.id)<0)}).join(""):'<p class="hint">Δεν υπάρχουν πρόσθετα πεδία.</p>')+
     '<div><button type="button" class="btn small" data-act="cfadd" data-coll="'+c+'">+ Νέο πεδίο</button></div></div>';
  }).join("");
  var n=0;BK_COLLS.forEach(function(c){n+=(bkData()[c]||[]).length});
  var h='<div id="stRoot" lang="el">'+
   '<div class="stcard"><h3>Backup &amp; Restore</h3>'+
   '<p class="hint">Το backup είναι ένα αρχείο .zip με <b>όλες τις εγγραφές</b> (Λογισμικά, Συμβάσεις, Διαγωνισμοί, Ανάδοχοι), τα <b>συνημμένα</b>, τις <b>ρυθμίσεις/custom fields</b> και τα άρθρα προϋπολογισμού. Δεν περιλαμβάνει τον κάδο. Περιέχει πραγματικά δεδομένα (και usernames): φύλαξέ το σε ασφαλές μέρος.</p>'+
   '<p class="hint" id="bkLast">'+stLastHtml()+'</p>'+
   '<div class="actions"><button type="button" class="btn primary" data-act="bkdo">⬇ Λήψη backup ('+n+' εγγραφές)</button>'+(can?'<button type="button" class="btn" data-act="bkpick">⬆ Restore από αρχείο…</button>':'')+'</div>'+
   '<p class="hint" id="bkMsg"></p><div id="bkRestore"></div></div>'+
   ownCard()+bsCard()+ntCard()+atCard()+
   '<div class="stcard"><h3>Γενικές ρυθμίσεις</h3><div class="stgrid">'+
   '<label class="f">Ποσοστό ΦΠΑ Προϋπολογισμού (%)<small>Τα ποσά των εγγραφών είναι χωρίς ΦΠΑ· ο Προϋπολογισμός τα εμφανίζει με ΦΠΑ.</small><input id="stVat" type="number" step="0.01" min="0" max="100" value="'+esc(st.vat)+'"'+(can?'':' disabled')+'></label>'+
   '<label class="f">Προεπιλεγμένη υπενθύμιση ετών σύμβασης (ημέρες πριν τη λήξη)<small>Ισχύει για τα νέα έτη σύμβασης· κάθε έτος αλλάζει ξεχωριστά.</small><input id="stRem" type="number" step="1" min="1" max="365" value="'+esc(st.remindDays)+'"'+(can?'':' disabled')+'></label></div></div>'+
   '<div class="stcard"><h3>Custom fields</h3><p class="hint">Πρόσθετα πεδία για κάθε καρτέλα. Εμφανίζονται στη φόρμα, στις λεπτομέρειες, στις στήλες της λίστας (⚙ Στήλες) και στο Excel/CSV. Ο τύπος ενός πεδίου δεν αλλάζει αφού αποθηκευτεί. Αν διαγράψεις ένα πεδίο, οι τιμές του δεν εμφανίζονται πια και αφαιρούνται από κάθε εγγραφή όταν αυτή αποθηκευτεί ξανά.</p>'+cfHtml+'</div>'+
   (can?'<div class="actions"><button type="button" class="btn primary" data-act="stsave">Αποθήκευση ρυθμίσεων</button></div><div class="err" id="stErr"></div>':'<p class="hint">Μόνο οι διαχειριστές αλλάζουν τις ρυθμίσεις.</p>')+
   '<div class="stcard"><h3>Πληροφορίες</h3><p class="hint">'+(window.RL_CFG?'Τα δεδομένα αποθηκεύονται στη βάση του WordPress.':'Τα δεδομένα αποθηκεύονται <b>μόνο σε αυτόν τον browser</b> (όχι στο cloud). Κάνε backup τακτικά και πριν καθαρίσεις τα δεδομένα του browser.')+'</p>'+
   '<p class="hint">Εγγραφές: '+n+' · Άρθρα προϋπολογισμού: '+articles().length+'</p></div></div>';
  $("#list").innerHTML=h;
  ntShowInfo();
  if(S.bk)bkPreview();else if(S.bkResult){var br=$("#bkRestore");if(br)br.innerHTML=S.bkResult}
  stFilter();
}
/* search on the Settings page (v3.15.0): hides the cards (and custom-field groups) that do not contain the text; typed values count too */
function stFilter(){
  var root=$("#stRoot");if(!root)return;var q=String(S.q||"").trim().toLowerCase(),shown=0;
  function txt(n){var t=n.textContent||"";[].forEach.call(n.querySelectorAll("input,select,textarea"),function(i){t+=" "+(i.value||"")});return t.toLowerCase()}
  [].forEach.call(root.querySelectorAll(".stcard"),function(c){
    var h=c.querySelector("h3"),hit=!q||txt(c).indexOf(q)>=0,groups=c.querySelectorAll(".cfgrp");
    if(q&&hit&&groups.length&&!(h&&h.textContent.toLowerCase().indexOf(q)>=0)){[].forEach.call(groups,function(g){g.style.display=txt(g).indexOf(q)>=0?"":"none"})}
    else[].forEach.call(groups,function(g){g.style.display=""});
    c.style.display=hit?"":"none";if(hit)shown++;
  });
  var m=$("#stNone");
  if(q&&!shown){if(!m){m=document.createElement("p");m.id="stNone";m.className="hint";root.appendChild(m)}m.textContent="Δεν βρέθηκε τίποτα στις ρυθμίσεις για «"+S.q+"»."}else if(m)m.remove();
}
async function stSaveClick(){
  var s=stCollect();if(!s)return;var e="",err=$("#stErr");
  var vat=Number(s.vat),rd=Number(s.remindDays);
  if(s.vat===""||!isFinite(vat)||vat<0||vat>100)e="ΦΠΑ: δώσε αριθμό από 0 έως 100.";
  else if(s.remindDays===""||!isFinite(rd)||rd<1||rd>365||Math.floor(rd)!==rd)e="Υπενθύμιση: δώσε ακέραιο αριθμό ημερών από 1 έως 365.";
  ST_COLLS.forEach(function(c){
    if(e)return;var seen={};
    s.customFields[c].forEach(function(f){
      if(e)return;var lab=String(f.label||"").trim();
      if(!lab)e=ST_NAMES[c]+": κάθε custom field χρειάζεται όνομα.";
      else if(seen[lab.toLowerCase()])e=ST_NAMES[c]+": το πεδίο «"+lab+"» υπάρχει δύο φορές.";
      else if(f.type==="select"&&!f.options.some(function(o){return o.trim()}))e=ST_NAMES[c]+": το πεδίο «"+lab+"» χρειάζεται τουλάχιστον μία επιλογή.";
      seen[lab.toLowerCase()]=1;
    });
  });
  if(e){if(err)err.textContent=e;return}
  if(await stSave(s)){S.stDirty=false;S.stDraft=null;toast("Οι ρυθμίσεις αποθηκεύτηκαν");render()}
}
/* Administrators: records without an owner (contracts of the time before 3.21, tenders made by the automatic run) get an owner here. */
function ownCard(){
  if(!window.RL_OWN||!window.RL_OWN.canAssign)return "";
  return '<div class="stcard"><h3>Ιδιοκτήτες εγγραφών</h3><p class="hint">Κάθε εγγραφή σε Λογισμικά, Συμβάσεις, Διαγωνισμούς και Γενικές Πρόνοιες έχει ιδιοκτήτη (στις Συμβάσεις είναι ο συντονιστής). Όποιος δεν έχει δικαίωμα «Βλέπει όλες τις εγγραφές» βλέπει μόνο τις δικές του. Εδώ ορίζετε ιδιοκτήτη στις εγγραφές που δεν έχουν· μέχρι τότε τις βλέπουν μόνο όσοι βλέπουν όλες.</p>'+
   '<div class="actions"><button type="button" class="btn" data-act="ownload">Εγγραφές χωρίς ιδιοκτήτη</button></div><div id="ownBox"></div></div>';
}
async function ownShowUnassigned(){
  var box=$("#ownBox");if(!box)return;box.textContent="Φόρτωση…";
  var r;try{r=await window.RL_OWN.unassigned()}catch(e){box.textContent="Δεν ήταν δυνατή η φόρτωση.";return}
  S.ownUn=r;
  if(!r.items.length){box.innerHTML='<p class="hint">Όλες οι εγγραφές έχουν ιδιοκτήτη.</p>';return}
  var rows=r.items.map(function(it,i){
    return '<tr><td>'+esc(OWN_NAMES[it.coll]||it.coll)+'</td><td>'+esc(it.title||it.id)+(it.trashed?' <span class="hint">(στον Κάδο)</span>':'')+'</td><td>'+esc(it.coordinator||it.createdBy||"—")+'</td>'+
      '<td><select data-ownun="'+i+'"><option value="">— Επιλογή —</option>'+r.users.map(function(u){return '<option value="'+u.id+'"'+(u.id===it.suggested?' selected':'')+'>'+esc(u.name)+'</option>'}).join("")+'</select></td></tr>';
  }).join("");
  box.innerHTML='<div class="tbl"><table><thead><tr><th>Ενότητα</th><th>Εγγραφή</th><th>Συντονιστής (κείμενο) / Δημιουργός</th><th>Ιδιοκτήτης</th></tr></thead><tbody>'+rows+'</tbody></table></div>'+
    '<p class="hint">Προτείνεται χρήστης μόνο όταν το όνομα ταιριάζει ακριβώς με έναν χρήστη. Ελέγξτε τις επιλογές πριν αποθηκεύσετε.</p>'+
    '<div class="actions"><button type="button" class="btn primary" data-act="ownsave">Αποθήκευση αντιστοιχίσεων</button></div><p class="hint" id="ownMsg"></p>';
}
async function ownSaveUnassigned(){
  var items=[];
  [].forEach.call(document.querySelectorAll("select[data-ownun]"),function(sel){
    var it=S.ownUn&&S.ownUn.items[+sel.getAttribute("data-ownun")];
    if(it&&sel.value)items.push({coll:it.coll,id:it.id,owner:Number(sel.value)});
  });
  var msg=$("#ownMsg");
  if(!items.length){if(msg)msg.textContent="Δεν έχει επιλεγεί κανένας ιδιοκτήτης.";return}
  try{var r=await window.RL_OWN.assign(items);toast("Ορίστηκε ιδιοκτήτης σε "+r.assigned+" εγγραφές");await ownShowUnassigned()}
  catch(e){if(msg)msg.textContent="Η αποθήκευση απέτυχε: "+((e&&e.message)||"")}
}
function stAction(act,b){
  switch(act){
    case "ownload":ownShowUnassigned();return true;
    case "ownsave":ownSaveUnassigned();return true;
    case "stsave":stSaveClick();return true;
    case "cfadd":{var s=stNorm2(stCollect()||stGet());s.customFields[b.dataset.coll].push({id:"f"+Date.now().toString(36)+Math.random().toString(36).slice(2,5),label:"",type:"text",options:[]});S.stDraft=s;S.stDirty=true;renderStPage();return true}
    case "cfdel":{var s2=stCollect();if(!s2)return true;var l=s2.customFields[b.dataset.coll],i=+b.dataset.i,f=l[i];
      if(f&&!f._new){var used=(bkData()[b.dataset.coll]||[]).filter(function(r){return r.custom&&r.custom[f.id]!=null}).length;
        if(!window.confirm("Να διαγραφεί το πεδίο «"+(f.label||"")+"»;"+(used?" "+used+" εγγραφές έχουν τιμή σε αυτό· δεν θα εμφανίζεται πια.":"")))return true}
      l.splice(i,1);S.stDraft=stNorm2(s2);S.stDirty=true;renderStPage();return true}
    case "autotn":atRunNow();return true;
    case "ntdl":ntDownloadTpl();return true;
    case "ntup":ntPick();return true;
    case "ntreset":ntReset();return true;
    case "bkdo":bkCreate();return true;
    case "bssave":bsDo(false);return true;
    case "bsrun":bsDo(true);return true;
    case "bkpick":bkPick();return true;
    case "bkgo":bkRun();return true;
    case "bkcancel":S.bk=null;S.bkResult="";{var bx=$("#bkRestore");if(bx)bx.innerHTML=""}return true;
  }
  return false;
}
/* keeps unsaved rows (also with empty names) while the page is edited, unlike stNorm which drops them */
function stNorm2(s){
  var o={vat:s.vat,remindDays:s.remindDays,customFields:{}};
  ST_COLLS.forEach(function(c){o.customFields[c]=(s.customFields[c]||[]).map(function(f){return {id:f.id,label:f.label||"",type:CF_TYPES[f.type]?f.type:"text",options:Array.isArray(f.options)?f.options:[]}})});
  return o;
}
document.addEventListener("input",function(e){
  if(S.cat!=="st"||!e.target||!e.target.closest||!e.target.closest("#stRoot"))return;
  S.stDirty=true;
});
document.addEventListener("change",function(e){
  var t=e.target;if(S.cat!=="st"||!t||!t.matches||!t.matches('[data-cf="type"]'))return;
  var row=t.closest(".cfrow"),o=row&&row.querySelector(".cfopt");if(o)o.hidden=t.value!=="select";
});

/* ---------- storage ---------- */
function col(n){return S.db.doc("data/users/"+S.uid+"/app").collection(n||"software")}
var CATS={sw:{c:"software",k:"items"},ct:{c:"contracts",k:"contracts"},tn:{c:"tenders",k:"tenders"},co:{c:"contractors",k:"contractors"},pv:{c:"provisions",k:"provisions"}};
function ctLike(c){return c==="ct"||c==="tn"}
function listOf(cat){return S[(CATS[cat]||CATS.sw).k]}
function getItem(cat,id){return listOf(cat).find(function(x){return x.id===id})}
/* ---------- record owners (3.21, WordPress only) ----------
   Software, contracts, tenders and general provisions have an owner: the contract coordinator (Συντονιστής) or the person responsible (Υπεύθυνος).
   A user without the "view_all" permission only sees the records he or she owns. The server enforces it; this code only offers the choices. */
function ownOn(){return !!window.RL_OWN}
function ownMe(){return window.RL_OWN?window.RL_OWN.me:0}
var OWN_COLL={sw:"software",ct:"contracts",tn:"tenders",pv:"provisions"};
var OWN_NAMES={software:"Λογισμικά",contracts:"Συμβάσεις",tenders:"Διαγωνισμοί",provisions:"Γενικές Πρόνοιες"};
function ownField(coll){
  if(coll==="software")return {k:"ownerId",l:"Owner",q:"Who is responsible for this software?",owner:1,coll:coll,hint:"The person who owns the record. A user who sees only his or her own records sees only these."};
  if(coll==="contracts")return {k:"ownerId",l:"ΣΥΝΤΟΝΙΣΤΗΣ ΣΥΜΒΑΣΗΣ",q:"Ποιος είναι ο συντονιστής της σύμβασης;",owner:1,coll:coll,hint:"Ο συντονιστής βλέπει τη σύμβαση, ακόμη κι αν δεν έχει δικαίωμα να βλέπει όλες."};
  return {k:"ownerId",l:"ΥΠΕΥΘΥΝΟΣ",q:"Ποιος είναι ο υπεύθυνος αυτής της εγγραφής;",owner:1,coll:coll,hint:"Ο υπεύθυνος βλέπει την εγγραφή, ακόμη κι αν δεν έχει δικαίωμα να βλέπει όλες."};
}
function ownOpts(cur){
  cur=Number(cur)||0;var list=S.ownUsers||[],has=false;
  var h='<option value=""'+(cur?'':' selected')+'>— Χωρίς ιδιοκτήτη —</option>'+list.map(function(u){if(u.id===cur)has=true;return '<option value="'+u.id+'"'+(u.id===cur?' selected':'')+'>'+esc(u.name)+'</option>'}).join("");
  if(cur&&!has)h+='<option value="'+cur+'" selected>'+esc((window.RL_OWN&&window.RL_OWN.name(cur))||(cur===ownMe()?"Εγώ":"Χρήστης #"+cur))+'</option>';
  return h;
}
function ownLoad(){
  if(S.ownUsers||S.ownLoading||!window.RL_OWN)return;
  S.ownLoading=1;
  window.RL_OWN.users().then(function(l){S.ownUsers=l;S.ownLoading=0;ownFill()},function(){S.ownLoading=0});
}
function ownFill(){[].forEach.call(document.querySelectorAll("select[data-own]"),function(sel){var cur=sel.value||sel.getAttribute("data-cur")||"";sel.innerHTML=ownOpts(cur)})}
/* editing: only users who see all records may change the owner of an existing record */
function ownSelect(id,cur,coll,editing){
  var lock=!!editing&&window.RL_OWN.restricted(coll);ownLoad();
  return '<select id="'+id+'" data-own="1" data-cur="'+(Number(cur)||"")+'"'+(lock?' disabled':'')+'>'+ownOpts(cur)+'</select>'+(lock?'<small>Τον ιδιοκτήτη τον αλλάζουν μόνο όσοι έχουν δικαίωμα να βλέπουν όλες τις εγγραφές.</small>':'');
}
/* The creator who names somebody else as the owner stops seeing the record: ask first. */
function ownWarn(coll,newOwner,curOwner){
  if(!window.RL_OWN||!window.RL_OWN.restricted(coll))return true;
  var n=Number(newOwner)||0;
  if(n<=0||n===ownMe()||n===(Number(curOwner)||0))return true;
  return window.confirm("Ορίζετε ως "+(coll==="contracts"?"συντονιστή":"υπεύθυνο")+" τον/την «"+(window.RL_OWN.name(n)||"επιλεγμένο χρήστη")+"». Μετά την αποθήκευση δεν θα βλέπετε πλέον αυτή την εγγραφή. Να συνεχίσω;");
}
function ownRow(it,coll){
  if(!window.RL_OWN)return "";
  var nm=it._ownerName||(it._owner?window.RL_OWN.name(it._owner):"");
  return '<dt>'+(coll==="software"?"Owner":"ΥΠΕΥΘΥΝΟΣ")+'</dt><dd>'+esc(nm||"—")+'</dd>';
}
function ownKey(s){return String(s||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/\s+/g," ").trim()}
/* the user whose name equals the text (accents and case ignored), only when there is exactly one */
function ownMatch(text){
  var k=ownKey(text);if(!k)return null;
  var m=(S.ownUsers||[]).filter(function(u){return ownKey(u.name)===k});
  return m.length===1?m[0]:null;
}
function saveErr(e){
  var c=e&&e.code,m={rl_duplicate_contractor:"Υπάρχει ήδη ανάδοχος με το ίδιο όνομα.",rl_duplicate_tender:"Ο αριθμός διαγωνισμού υπάρχει ήδη σε άλλον διαγωνισμό.",rl_duplicate_contract:"Υπάρχει ήδη Σύμβαση καταχωρημένη με τον ίδιο αριθμό διαγωνισμού.",rl_bad_contractor:"Ο επιλεγμένος ανάδοχος δεν υπάρχει πια. Επίλεξε άλλον."};
  return m[c]||"Could not save ("+(c||"error")+")";
}
async function save(id,rec,cat){
  cat=cat||"sw";
  if(S.db&&S.uid){try{await col(collName(cat)).doc(id).set(rec)}catch(e){toast(saveErr(e));return false}}
  else{var L=listOf(cat),i=L.findIndex(function(x){return x.id===id}),o=Object.assign({id:id},rec);if(i>=0)L[i]=o;else L.push(o);render()}
  return true;
}
/* Deleting never destroys: the record goes to the trash (WordPress: on the server; here: kept with a deletedAt mark) and can be restored. */
var TRASH_DAYS=30;
function trashDays(){return window.RL_TRASH?(window.RL_TRASH.days||0):TRASH_DAYS}
function collName(cat){return (CATS[cat]||CATS.sw).c}
function recName(cat,it){return cat==="sw"||cat==="co"?(it.name||""):(it.title||"")}
async function remove(id,cat){
  cat=cat||"sw";var it=getItem(cat,id);if(!it)return false;
  if(window.RL_TRASH){try{await col(collName(cat)).doc(id).delete()}catch(e){toast(e&&e.code==="rl_contractor_in_use"?"Ο ανάδοχος χρησιμοποιείται σε συμβάσεις και δεν μπορεί να διαγραφεί.":"Could not delete");return false}loadTrash(cat)}
  else if(S.db&&S.uid){var rec=strip(it);rec.deletedAt=Date.now();try{await col(collName(cat)).doc(id).set(rec)}catch(e){toast("Could not delete");return false}}
  else{var k=CATS[cat].k;S[k]=S[k].filter(function(x){return x.id!==id});S.trash[cat].push(Object.assign({},it,{deletedAt:Date.now()}));render()}
  return true;
}
/* trash lists: S.trash.sw / S.trash.ct hold {id,...record,_at (ms),_by} */
function trashFromDocs(cat,docs){S.trash[cat]=docs.map(function(d){return Object.assign({id:d.id},d.data(),{_at:d.data().deletedAt||0})})}
async function loadTrash(cat){
  if(!window.RL_TRASH||!window.RL_TRASH.can(collName(cat)))return;
  try{var l=await window.RL_TRASH.list(collName(cat));S.trash[cat]=l.map(function(x){return Object.assign({id:x.id},x.data,{_at:x.at,_by:x.by})});render()}catch(e){}
}
async function restoreItem(cat,id){
  var it=(S.trash[cat]||[]).find(function(x){return x.id===id});if(!it)return false;
  if(cat==="co"){var dq=coDup(it.name,"",id);if(dq){toast("Δεν επαναφέρθηκε: υπάρχει ήδη ανάδοχος με το ίδιο όνομα («"+dq.name+"»)");return false}}
  if(cat==="tn"){var dp=tnDup(it.tender,id);if(dp){toast("Δεν επαναφέρθηκε: ο αριθμός διαγωνισμού «"+it.tender+"» χρησιμοποιείται ήδη από τον διαγωνισμό «"+dp.title+"»");return false}}
  if(cat==="ct"){var dc=ctDup(it.tender,id);if(dc){toast("Δεν επαναφέρθηκε: υπάρχει ήδη Σύμβαση με τον ίδιο αριθμό διαγωνισμού «"+it.tender+"» («"+dc.title+"»)");return false}}
  if(window.RL_TRASH){try{await window.RL_TRASH.restore(collName(cat),id)}catch(e){toast("Could not restore");return false}await loadTrash(cat);return true}
  var rec=strip(it);delete rec.deletedAt;delete rec._at;delete rec._by;
  if(S.db&&S.uid){try{await col(collName(cat)).doc(id).set(rec)}catch(e){toast("Could not restore");return false}}
  else{S.trash[cat]=S.trash[cat].filter(function(x){return x.id!==id});listOf(cat).push(Object.assign({id:id},rec));render()}
  return true;
}
async function purgeItem(cat,id){
  var it=(S.trash[cat]||[]).find(function(x){return x.id===id});if(!it)return false;
  if(window.RL_TRASH){try{await window.RL_TRASH.purge(collName(cat),id)}catch(e){toast("Could not delete");return false}await loadTrash(cat);return true}
  var files=(it.attachments||[]).concat((it.milestones||[]).reduce(function(a,m){return a.concat(m.attachments||[])},[]));
  if(S.db&&S.uid){try{await col(collName(cat)).doc(id).delete()}catch(e){toast("Could not delete");return false}}
  else{S.trash[cat]=S.trash[cat].filter(function(x){return x.id!==id});render()}
  if(S.assets)for(var i=0;i<files.length;i++){if(fileInUse(files[i].id,cat,id))continue;try{await S.assets.delete(files[i].id)}catch(_){}}
  return true;
}
/* browser versions: remove records that have been in the trash longer than TRASH_DAYS */
async function autoPurge(){
  if(window.RL_TRASH||!TRASH_DAYS)return;
  var lim=Date.now()-TRASH_DAYS*864e5;
  ["sw","ct","tn","co","pv"].forEach(function(c){(S.trash[c]||[]).filter(function(x){return x._at&&x._at<lim}).forEach(function(x){purgeItem(c,x.id)})});
}
/* a file may be referenced by two records (a promoted tender and its contract in the browser builds): only delete it when nothing else uses it */
function fileInUse(fid,xcat,xid){
  var hit=false;
  function chk(cat,l){(l||[]).forEach(function(r){if(hit||(cat===xcat&&r.id===xid))return;var a=(r.attachments||[]).concat((r.milestones||[]).reduce(function(q,m){return q.concat(m.attachments||[])},[]));if(a.some(function(f){return f.id===fid}))hit=true})}
  chk("sw",S.items);chk("ct",S.contracts);chk("tn",S.tenders);chk("pv",S.provisions);["sw","ct","tn","pv"].forEach(function(c){chk(c,S.trash[c])});
  return hit;
}
function byId(id){return S.items.find(function(x){return x.id===id})}
function strip(it){var o=Object.assign({},it);delete o.id;return o}

/* ---------- list rendering ---------- */
function filtered(){
  var q=S.q.toLowerCase();
  return sortList("sw",S.items.filter(function(it){
    var st=status(it).k;
    if(S.filter==="expired"&&st!=="bad")return false;
    if(S.filter==="due"&&st!=="warn")return false;
    if(S.filter==="active"&&st!=="ok")return false;
    if(!q)return true;
    return [it.name,it.vendor,it.website,it.description].join(" ").toLowerCase().indexOf(q)>=0;
  }));
}
function renderSw(){
  var all=S.items,exp=0,due=0,act=0,spend=0;
  all.forEach(function(it){var s=status(it).k;if(s==="bad")exp++;else if(s==="warn")due++;else act++;if(s!=="bad")spend+=Number(it.cost)||0});
  $("#stats").innerHTML=
    '<div class="stat"><b>'+all.length+'</b><span>Software</span></div>'+
    '<div class="stat bad"><b>'+exp+'</b><span>Expired</span></div>'+
    '<div class="stat warn"><b>'+due+'</b><span>Due soon</span></div>'+
    '<div class="stat"><b>'+act+'</b><span>Active</span></div>'+
    '<div class="stat"><b class="num" style="font-family:var(--f-display)">'+money(spend).replace(/\.00$/,"")+'</b><span>Running cost excl. VAT</span></div>';
  var al="";
  var ex=all.filter(function(i){return status(i).k==="bad"}),du=all.filter(function(i){return status(i).k==="warn"});
  function names(a){return a.slice(0,3).map(function(i){return esc(i.name)}).join(", ")+(a.length>3?" +"+(a.length-3)+" more":"")}
  if(ex.length)al+='<div class="alert bad"><span>Expired: '+names(ex)+'</span><button type="button" data-f="expired">Show</button></div>';
  if(du.length)al+='<div class="alert"><span>Renewal due: '+names(du)+'</span><button type="button" data-f="due">Show</button></div>';
  $("#alerts").innerHTML=al+msAlertHtml("sw")+crossAlert("sw");
  var chips=[["all","All"],["expired","Expired"],["due","Due soon"],["active","Active"],["trash","🗑 Trash"+(S.trash.sw.length?" ("+S.trash.sw.length+")":"")]];
  $("#chips").innerHTML=chips.map(function(c){return '<button type="button" class="chip" data-f="'+c[0]+'" aria-pressed="'+(S.filter===c[0])+'">'+c[1]+'</button>'}).join("")+'<button type="button" class="chip" data-act="cols">⚙ Columns</button>'+(window.RL_CFG?'':'<button type="button" class="chip" data-act="arts">Budget articles</button>');
  var rows=filtered(),h="";
  if(!all.length){
    h='<div class="empty"><h2>No software added yet</h2><p>Add your first subscription one field at a time, or import many at once from an Excel file.</p><div class="actions"><button class="btn primary" type="button" id="emAdd">+ Add software</button><button class="btn" type="button" id="emImp">Import Excel</button><button class="btn" type="button" id="emSample">Load 3 sample rows</button></div></div>';
  }else if(!rows.length){
    h='<div class="empty"><h2>No matches</h2><p>Try another search or filter.</p></div>';
  }else{
    h=listHtml("sw",rows);
  }
  $("#list").innerHTML=h;
}

/* ---------- panel helpers ---------- */
function openPanel(html,kind,wide){
  var o=$("#overlay");o.dataset.kind=kind;
  o.innerHTML='<div class="panel'+(wide?' wide':'')+'" role="dialog" aria-modal="true">'+html+'</div>';
  o.hidden=false;
  var f=o.querySelector("input:not([type=hidden]),select,textarea");if(f&&kind!=="detail")f.focus();
}
function closePanel(){var o=$("#overlay");o.hidden=true;o.innerHTML="";S.pv=null;S.open=null;S.openCat=null;S.wiz=null;S.cw=null;S.co=null;S.imp=null;S.dirty=false}
/* Forms (Λογισμικά, Συμβάσεις, Διαγωνισμοί, renew, milestone) never close by a click outside them or by Backspace; Escape / Cancel ask first when something was typed. */
var FORMKINDS={wiz:1,renew:1,ms:1};
function formOpen(){var o=$("#overlay");return !!o&&!o.hidden&&!!FORMKINDS[o.dataset.kind]}
function askClose(){
  if(S.co){coCancel();return}
  if(formOpen()&&S.dirty&&!window.confirm("Να κλείσει η φόρμα; Ό,τι έχεις συμπληρώσει και δεν έχει αποθηκευτεί θα χαθεί."))return;
  closePanel();
}
document.addEventListener("keydown",function(ev){if(ev.key==="Escape"&&!$("#overlay").hidden)askClose()});
window.addEventListener("beforeunload",function(e){if(formOpen()&&S.dirty){e.preventDefault();e.returnValue=""}});

/* ---------- detail panel ---------- */
function showDetail(id){
  var it=byId(id);if(!it)return;S.open=id;S.openCat="sw";
  var s=status(it);
  var files=(it.attachments||[]).map(function(a,i){
    return '<li><a href="#" data-blob="'+esc(a.id)+'">'+esc(a.name)+'</a><button type="button" class="btn small danger" data-delfile="'+i+'">Remove</button></li>';
  }).join("");
  var hist=(it.history||[]).slice().reverse().map(function(h){
    return '<tr><td>'+fmtDate(h.from)+' – '+fmtDate(h.to)+'</td><td class="num">'+money(h.cost)+'</td></tr>';
  }).join("");
  var opts=REMIND.map(function(n){return '<option value="'+n+'"'+(+it.remindDays===n?" selected":"")+'>'+n+' days before</option>'}).join("");
  if(REMIND.indexOf(+it.remindDays)<0)opts+='<option value="'+(+it.remindDays)+'" selected>'+(+it.remindDays)+' days before</option>';
  var web=it.website?(/^https?:\/\//i.test(it.website)?'<a href="'+esc(it.website)+'" target="_blank" rel="noopener">'+esc(it.website)+'</a>':esc(it.website)):"—";
  openPanel(
   '<div class="ph"><div><h2>'+esc(it.name)+'</h2><span class="pill '+s.k+'">'+s.t+'</span> <span class="hint">'+dayText(s.d)+'</span></div><button class="btn small" type="button" data-act="close">Close</button></div>'+
   '<dl class="kv">'+ownRow(it,"software")+
   '<dt>Description</dt><dd>'+esc(it.description||"—")+'</dd>'+
   '<dt>Vendor</dt><dd>'+esc(it.vendor||"—")+'</dd>'+
   '<dt>Website</dt><dd>'+web+'</dd>'+
   '<dt>Username</dt><dd>'+(it.username?'<span class="mono">'+esc(it.username)+'</span> <button class="btn small" type="button" data-copy="username">Copy</button>':"—")+'</dd>'+
   '<dt>Notification emails</dt><dd>'+esc(it.emails||"—")+'</dd>'+
   '<dt>Date From</dt><dd class="mono">'+fmtDate(it.dateFrom)+'</dd>'+
   '<dt>Date To</dt><dd class="mono">'+fmtDate(it.dateTo)+'</dd>'+
   '<dt>Cost excl. VAT</dt><dd class="num">'+money(it.cost)+'</dd></dl>'+
   '<div class="sec"><h3>Reminder</h3><label class="f">Alert me before expiry<select id="remSel">'+opts+'</select></label><span class="hint">The alert appears at the top of the ledger from this point until the date passes.</span></div>'+
   '<div class="sec"><h3>Attachments</h3>'+(files?'<ul class="files">'+files+'</ul>':'<span class="hint">No invoices or receipts attached yet.</span>')+
   '<div><button class="btn" type="button" data-act="attach"'+(S.assets?'':' disabled')+'>+ Attach files</button> <span class="hint">'+(S.assets?'Invoices, receipts, PDFs, images, Word, Excel, HTML (up to '+attMB()+' MB each).':'Uploads are not available in this view.')+'</span></div></div>'+
   bpDetail(it,0)+msSection("sw",it)+
   '<div class="sec"><h3>Renewal</h3><div><button class="btn primary" type="button" data-act="renew">Renew…</button> <button class="btn" type="button" data-act="swnote">Ετοιμασία Σημειώματος</button></div>'+
   (hist?'<div class="tbl"><table><thead><tr><th>Previous period</th><th>Cost excl. VAT</th></tr></thead><tbody>'+hist+'</tbody></table></div>':'')+'</div>'+
   cfDetail(it,"software")+'<div class="sec"><div class="actions"><button class="btn" type="button" data-act="edit">Edit details</button><button class="btn danger" type="button" data-act="del">Delete</button></div><div id="delbox"></div></div>'
  ,"detail");
}

/* ---------- add / edit (guided prompt or full form) ---------- */
function inputHtml(f,val,pre){
  var id=pre+f.k,v=val==null?"":val;
  if(f.owner)return ownSelect(id,v,f.coll,!!(S.wiz&&S.wiz.id));
  if(f.cf)return cfInput(f,v,id);
  if(f.ta)return '<textarea id="'+id+'" placeholder="'+esc(f.ph||"")+'">'+esc(v)+'</textarea>';
  var t=f.date?"date":f.num?"number":f.k==="website"?"url":"text";
  return '<input id="'+id+'" type="'+t+'"'+(f.num?' step="0.01" min="0" inputmode="decimal"':'')+' value="'+esc(v)+'" placeholder="'+esc(f.ph||"")+'" autocomplete="off">';
}
function remindSel(v,id){return '<select id="'+id+'">'+REMIND.map(function(n){return '<option value="'+n+'"'+(+v===n?" selected":"")+'>'+n+' days before expiry</option>'}).join("")+'</select>'}
function startWizard(id){
  var it=id?byId(id):null;
  S.wiz={id:id||null,mode:it?"full":"step",i:0,err:"",data:it?Object.assign({},it):{dateFrom:todayIso(),remindDays:30}};
  if(ownOn())S.wiz.data.ownerId=it?(it._owner||""):ownMe();
  drawWizard();
}
function collect(){
  var w=S.wiz;
  swF().forEach(function(f){var el=$("#w_"+f.k);if(el)w.data[f.k]=el.value});
  var r=$("#w_remind");if(r)w.data.remindDays=+r.value;
  bpCollect(w.data);
  if(bpHas(w.data))w.data.cost=bpSum(w.data.budget);
}
function validate(keys){
  var d=S.wiz.data;
  for(var i=0;i<keys.length;i++){
    var f=swF().filter(function(x){return x.k===keys[i]})[0];if(!f)continue;
    var v=d[f.k];
    if(f.cf){var ce=cfErr(f,v);if(ce)return ce}
    if(f.req&&(v==null||String(v).trim()===""))return f.l+" is required.";
    if(f.date&&v&&!parseIso(v))return f.l+" is not a valid date.";
    if(f.email&&v&&emailsErr(v))return emailsErr(v);
    if(f.num&&v!==""&&v!=null&&(!isFinite(Number(v))||Number(v)<0))return "Enter the cost as a number, for example 120.50.";
  }
  if(keys.indexOf("dateTo")>=0&&d.dateFrom&&d.dateTo&&d.dateTo<d.dateFrom)return "Date To must be on or after Date From.";
  if(keys.indexOf("cost")>=0||keys.length>3){var be=bpErr(d,0);if(be)return be}
  return "";
}
function bpSec(d){return '<div class="sec"><h3>Cost breakdown (optional)</h3><p class="hint">Split the cost into partial amounts per year, each with its budget article. When you add partial amounts, the cost is their sum.</p>'+bpBlock(d,null,0,msYears("sw",d))+'</div>'}
function drawWizard(){
  var w=S.wiz,d=w.data,h;cfLoad(d,"software");
  var head='<div class="ph"><h2>'+(w.id?"Edit software":"Add software")+'</h2><button class="btn small" type="button" data-act="close">Cancel</button></div>';
  if(w.mode==="full"){
    h=head+'<div style="display:grid;gap:12px">'+swF().map(function(f){
      var ih=inputHtml(f,d[f.k],"w_");if(f.k==="cost"&&bpHas(d))ih=ih.replace("<input","<input readonly");
      return '<label class="f">'+f.l+(f.req?' *':'')+(f.hint?'<small>'+esc(f.hint)+'</small>':'')+ih+'</label>'+(f.k==="cost"?'</div>'+bpSec(d)+'<div style="display:grid;gap:12px">':'');
    }).join("")+'<label class="f">Reminder<small>Alert me before expiry</small>'+remindSel(d.remindDays||30,"w_remind")+'</label></div>'+
    '<div class="err" id="werr">'+esc(w.err)+'</div>'+
    '<div class="actions"><button class="btn primary" type="button" data-act="wsave">Save</button>'+(w.id?'':'<button class="btn" type="button" data-act="wstep">Guided mode</button>')+'</div>';
  }else{
    var total=swF().length+1,i=w.i,last=i===total-1;
    var body;
    if(i<swF().length){var f=swF()[i];body='<label class="f"><span class="big-q">'+f.q+(f.req?'':' <small>(optional)</small>')+'</span>'+inputHtml(f,d[f.k],"w_")+'</label>'}
    else body='<label class="f"><span class="big-q">When should we alert you before it expires?</span>'+remindSel(d.remindDays||30,"w_remind")+'</label>'+bpSec(d);
    h=head+'<div class="steps" aria-hidden="true"><i style="width:'+Math.round((i+1)/total*100)+'%"></i></div><div class="hint">Step '+(i+1)+' of '+total+'</div>'+body+
    '<div class="err" id="werr">'+esc(w.err)+'</div>'+
    '<div class="actions">'+(i>0?'<button class="btn" type="button" data-act="wback">Back</button>':'')+
    '<button class="btn primary" type="button" data-act="'+(last?'wsave':'wnext')+'">'+(last?'Save':'Next')+'</button></div>'+
    '<div><button class="btn small" type="button" data-act="wfull">Switch to full form</button></div>';
  }
  openPanel(h,"wiz");
}
async function wizSave(){
  collect();var w=S.wiz;
  var e=validate(swF().map(function(f){return f.k}));
  if(e){w.err=e;var x=$("#werr");if(x)x.textContent=e;return}
  var base=w.id?byId(w.id):{};
  var rec=norm(Object.assign({},base,w.data));cfApply(rec,w.data,"software");
  if(ownOn()){var ov=Number(w.data.ownerId)||0;if(!ownWarn("software",ov,base&&base._owner))return;if(ov>0)rec._owner=ov}
  rec.budget=bpClean(w.data);if(rec.budget.length)rec.cost=bpSum(rec.budget);
  var id=w.id||uid();
  if(await save(id,rec)){closePanel();toast(w.id?"Saved":"Added "+rec.name);if(!w.id)showDetail(id)}
}
function wizNext(){
  collect();var w=S.wiz,f=swF()[w.i];
  var e=validate([f.k]);
  if(e){w.err=e;var x=$("#werr");if(x)x.textContent=e;return}
  if(f.k==="dateFrom"&&!w.data.dateTo)w.data.dateTo=addYear(w.data.dateFrom);
  if(f.k==="dateTo"){e=validate(["dateTo"]);if(e){w.err=e;drawWizard();return}}
  w.err="";w.i++;drawWizard();
}

/* ---------- renew ---------- */
function showRenew(id){
  var it=byId(id);if(!it)return;
  var nf=it.dateTo?addDays(it.dateTo,1):todayIso();
  openPanel('<div class="ph"><h2>Renew '+esc(it.name)+'</h2><button class="btn small" type="button" data-act="back" data-id="'+esc(id)+'">Cancel</button></div>'+
   '<p class="hint">Current period: '+fmtDate(it.dateFrom)+' – '+fmtDate(it.dateTo)+' at '+money(it.cost)+'. It is kept in the renewal history.</p>'+
   '<div class="grid2"><label class="f">New Date From<input id="r_from" type="date" value="'+nf+'"></label><label class="f">New Date To<input id="r_to" type="date" value="'+addYear(nf)+'"></label></div>'+
   '<label class="f">New cost excl. VAT (€)<input id="r_cost" type="number" step="0.01" min="0" value="'+esc(it.cost)+'" inputmode="decimal"></label>'+
   '<div class="err" id="rerr"></div><div class="actions"><button class="btn primary" type="button" data-act="rsave" data-id="'+esc(id)+'">Confirm renewal</button></div>',"renew");
  $("#r_from").addEventListener("change",function(){var v=$("#r_from").value;if(parseIso(v))$("#r_to").value=addYear(v)});
}
async function doRenew(id){
  var it=byId(id),f=$("#r_from").value,t=$("#r_to").value,c=$("#r_cost").value,err="";
  if(!parseIso(f)||!parseIso(t))err="Enter both dates.";
  else if(t<f)err="New Date To must be on or after New Date From.";
  else if(c===""||!isFinite(Number(c))||Number(c)<0)err="Enter the new cost as a number.";
  if(err){$("#rerr").textContent=err;return}
  var rec=norm(it);
  rec.history=(it.history||[]).concat([{from:it.dateFrom,to:it.dateTo,cost:Number(it.cost)||0,renewedOn:todayIso()}]);
  rec.dateFrom=f;rec.dateTo=t;rec.cost=Number(c);rec.budget=[];rec.sample=it.sample;
  if(await save(id,rec)){toast("Renewed until "+fmtDate(t));showDetail(id)}
}

/* ---------- attachments ---------- */
/* Largest attachment: 20 MB, or less when the WordPress server (PHP upload_max_filesize / post_max_size) allows less. */
function attMax(){var m=window.RL_CFG&&Number(window.RL_CFG.maxUpload);return m>0?Math.min(m,20971520):20971520}
function attMB(){var v=attMax()/1048576;return v>=10?String(Math.round(v)):String(Math.round(v*10)/10).replace(".",",")}
function attTooBig(f,el){
  if(f.size<=attMax())return "";
  var sz=(f.size/1048576).toFixed(1).replace(".",",");
  return el?"το αρχείο είναι "+sz+" MB και το όριο είναι "+attMB()+" MB"+(window.RL_CFG&&attMax()<20971520?" (όριο του server: ζήτα από τον διαχειριστή του hosting να αυξήσει τα upload_max_filesize και post_max_size σε τουλάχιστον 20M)":""):"file is "+sz+" MB, the limit is "+attMB()+" MB";
}
var MIME={html:"text/html",htm:"text/html",pdf:"application/pdf",png:"image/png",jpg:"image/jpeg",jpeg:"image/jpeg",gif:"image/gif",webp:"image/webp",csv:"text/csv",txt:"text/plain",md:"text/markdown",json:"application/json",xml:"application/xml",eml:"message/rfc822",msg:"application/vnd.ms-outlook",lic:"application/octet-stream",rtf:"application/rtf",log:"text/plain",ics:"text/calendar",vcf:"text/vcard",zip:"application/zip","7z":"application/x-7z-compressed",rar:"application/vnd.rar",gz:"application/gzip",tar:"application/x-tar",p7m:"application/pkcs7-mime",p7s:"application/pkcs7-signature",cer:"application/pkix-cert",crt:"application/x-x509-ca-cert",tif:"image/tiff",tiff:"image/tiff",bmp:"image/bmp",dwg:"application/octet-stream",dxf:"application/octet-stream",mp4:"video/mp4",webm:"video/webm"};
function reopen(cat,id){cat==="pv"?showPvDetail(id):cat==="co"?showCoDetail(id):cat==="tn"?showTnDetail(id):cat==="ct"?showCtDetail(id):showDetail(id)}
async function attachFiles(files){
  var cat=S.openCat||"sw",id=S.open,it=getItem(cat,id);if(!it||!S.assets)return;
  var list=(it.attachments||[]).slice(),n=0,el=cat!=="sw";
  for(var i=0;i<files.length;i++){
    var f=files[i],ext=(f.name.split(".").pop()||"").toLowerCase(),type=f.type&&MIME[ext]===f.type?f.type:MIME[ext]||f.type;
    var big=attTooBig(f,el);if(big){toast(f.name+": "+big);continue}
    try{var r=await S.assets.upload(f,type?{type:type}:undefined);list.push({id:r.id,name:f.name,size:r.sizeBytes});n++}
    catch(e){toast(f.name+": "+(e&&e.code==="unsupported_type"?(el?"μη υποστηριζόμενος τύπος (PDF, εικόνα, CSV, κείμενο, Word, Excel, PowerPoint, HTML, XML, email (eml/msg), άδεια (lic), zip/7z/rar κ.ά.)":"file type not supported (use PDF, image, CSV, text, Word, Excel, PowerPoint, HTML, XML, email (eml/msg), license (lic), zip/7z/rar and similar)"):e&&(e.code==="bad_content"||e.code==="infected")?(el?(e.code==="infected"?"το αρχείο απορρίφθηκε από τον έλεγχο ιών":"το περιεχόμενο δεν ταιριάζει με τον τύπο του αρχείου, ή είναι πρόγραμμα"):(e.code==="infected"?"refused by the antivirus check":"content does not match the file type, or it is a program")):e&&e.code==="av_unavailable"?(el?"ο έλεγχος ιών δεν ολοκληρώθηκε· το αρχείο δεν αποθηκεύτηκε":"antivirus check could not be completed; file not stored"):e&&e.code==="too_large"?(el?"μεγαλύτερο από το όριο ("+attMB()+" MB)":"larger than the limit ("+attMB()+" MB)"):(el?"αποτυχία μεταφόρτωσης":"upload failed")))}
  }
  if(n){var rec=strip(it);rec.attachments=list;if(await save(id,rec,cat)){toast(el?n+" αρχείο/α προστέθηκαν":n+" file"+(n>1?"s":"")+" attached");reopen(cat,id)}}
}
async function removeFile(i){
  var cat=S.openCat||"sw",it=getItem(cat,S.open);if(!it)return;var a=(it.attachments||[])[i];if(!a)return;
  var rec=strip(it);rec.attachments=it.attachments.filter(function(_,j){return j!==i});
  var before=(it.attachments||[]).slice(),id=it.id,el=cat!=="sw";
  if(await save(id,rec,cat)){
    reopen(cat,id);
    /* the file itself is only deleted when the 8 s to undo are over */
    toastUndo(el?"Το αρχείο αφαιρέθηκε":"File removed",async function(){
      var cur=getItem(cat,id);if(!cur)return;var r2=strip(cur);r2.attachments=before;
      if(await save(id,r2,cat)&&S.open===id)reopen(cat,id);
    },function(){if(fileInUse(a.id))return;try{S.assets.delete(a.id)}catch(e){}},el);
  }
}

/* =============== MILESTONES (both categories) =============== */
var REMIND_MS=[30,60];
function msIsEl(cat){return cat==="ct"}
function msList(it){return (it&&it.milestones)||[]}
/* Number of "years" of a record: contracts use their year table; software counts whole years from Date From to Date To. */
function msYears(cat,it){
  if(cat==="ct")return Math.max(1,(it.years||[]).length);
  var a=parseIso(it.dateFrom),b=parseIso(it.dateTo);if(!a||!b||b<a)return 1;
  var n=1;while(n<60&&addDays(addMonths(it.dateFrom,12*n),-1)<it.dateTo)n++;
  return n;
}
function msYearRange(cat,it,y){
  if(cat==="ct"){var r=(it.years||[])[y-1];return r?fmtDate(r.from)+" – "+fmtDate(r.to):""}
  var f=addMonths(it.dateFrom,12*(y-1));if(!parseIso(f))return "";
  var t=addDays(addMonths(it.dateFrom,12*y),-1);if(it.dateTo&&t>it.dateTo)t=it.dateTo;
  return fmtDate(f)+" – "+fmtDate(t);
}
function msInfo(m){
  var el=!!m._el,d=daysLeft(m.due);
  if(m.done)return {k:"ok",t:el?"Ολοκληρώθηκε":"Done",d:d};
  if(d==null)return {k:"ok",t:el?"Χωρίς ημερομηνία":"No date",d:null};
  if(d<0)return {k:"bad",t:el?"Εκπρόθεσμο":"Overdue",d:d};
  if(d<=(+m.remind||30))return {k:"warn",t:el?"Πλησιάζει":"Due soon",d:d};
  return {k:"ok",t:el?"Προγραμματισμένο":"Scheduled",d:d};
}
function msAll(cat){
  var out=[];
  listOf(cat).forEach(function(it){if(cat==="ct"&&ctInfo(it).archived)return;msList(it).forEach(function(m){
    var s=msInfo(Object.assign({_el:cat==="ct"},m));
    if(s.k!=="ok")out.push({cat:cat,it:it,m:m,s:s});
  })});
  out.sort(function(a,b){return a.s.d-b.s.d});
  return out;
}
function msAttn(cat){return msAll(cat).length}
function msTitle(cat,it){return cat==="ct"?it.title:it.name}
function msAlertHtml(cat){
  var l=msAll(cat);if(!l.length)return "";
  var el=cat==="ct";
  var h=l.slice(0,4).map(function(x){
    return '<div class="alert'+(x.s.k==="bad"?' bad':'')+'"><span>'+(el?"Milestone: ":"Milestone: ")+'<b>'+esc(x.m.description)+'</b> · '+esc(msTitle(cat,x.it))+' · '+fmtDate(x.m.due)+' ('+(el?dayTextEl(x.s.d):dayText(x.s.d))+')</span>'+
      '<button type="button" data-act="openid" data-cat="'+cat+'" data-id="'+esc(x.it.id)+'">'+(el?"Άνοιγμα":"Open")+'</button></div>';
  }).join("");
  if(l.length>4)h+='<div class="alert"><span>+'+(l.length-4)+' milestones</span></div>';
  return h;
}
function msFilesHtml(m){
  var f=(m.attachments||[]).map(function(a){return '<a href="#" data-blob="'+esc(a.id)+'">'+esc(a.name)+'</a>'}).join(" · ");
  return f?'<div class="msf">'+f+'</div>':"";
}
function msSection(cat,it){
  var el=cat==="ct",L=msList(it),max=msYears(cat,it);
  L.forEach(function(m){if(m.year>max)max=m.year});
  var h='<div class="sec"><h3>Milestones</h3><span class="hint">'+(el?"Πρόσθεσε milestones ανά έτος. Η ειδοποίηση εμφανίζεται και στέλνεται με email 30 ή 60 ημέρες πριν την ημερομηνία παράδοσης.":"Add milestones per year. The alert shows on screen and is e-mailed 30 or 60 days before the delivery date.")+'</span>';
  for(var y=1;y<=max;y++){
    var rows=L.filter(function(m){return m.year===y}).sort(function(a,b){return (a.due||"9999").localeCompare(b.due||"9999")});
    h+='<div class="msyear"><div class="msyh"><div><b>'+(el?"Έτος ":"Year ")+y+'</b> <span class="hint">'+msYearRange(cat,it,y)+'</span></div>'+
      '<button class="btn small" type="button" data-act="msadd" data-year="'+y+'">'+(el?"+ Προσθήκη milestone":"+ Add milestone")+'</button></div>';
    if(rows.length)h+='<ul class="files ms">'+rows.map(function(m){
      var s=msInfo(Object.assign({_el:el},m));
      return '<li class="'+(m.done?"done":"")+'"><div class="msb"><div><b>'+esc(m.description)+'</b> <span class="pill '+s.k+'">'+s.t+'</span></div>'+
        '<div class="hint">'+fmtDate(m.due)+(s.d!=null&&!m.done?' · '+(el?dayTextEl(s.d):dayText(s.d)):'')+' · '+(el?"ειδοποίηση ":"alert ")+(+m.remind||30)+(el?" ημ. πριν":" days before")+'</div>'+
        (m.comments?'<div class="msc">'+esc(m.comments)+'</div>':'')+msFilesHtml(m)+'</div>'+
        '<div class="actions"><button class="btn small" type="button" data-act="msdone" data-mid="'+esc(m.id)+'">'+(m.done?(el?"Επανάνοιγμα":"Reopen"):(el?"Ολοκληρώθηκε":"Mark done"))+'</button>'+
        '<button class="btn small" type="button" data-act="msedit" data-mid="'+esc(m.id)+'">'+(el?"Επεξεργασία":"Edit")+'</button>'+
        '<button class="btn small danger" type="button" data-act="msdel" data-mid="'+esc(m.id)+'">'+(el?"Διαγραφή":"Delete")+'</button></div></li>';
    }).join("")+'</ul>';
    else h+='<span class="hint">'+(el?"Κανένα milestone για αυτό το έτος.":"No milestones for this year.")+'</span>';
    h+='</div>';
  }
  return h+'</div>';
}
function showMsForm(cat,id,mid,year){
  var it=getItem(cat,id);if(!it)return;
  var m=mid?msList(it).find(function(x){return x.id===mid}):null;
  S.ms={cat:cat,id:id,mid:mid||null,year:m?m.year:year,added:[],removed:[],err:"",
    d:m?JSON.parse(JSON.stringify(m)):{description:"",due:"",remind:30,comments:"",done:false,attachments:[]}};
  msDraw();
}
function msCollect(){
  var w=S.ms,d=w.d,a=$("#ms_desc");if(!a)return;
  d.description=a.value;d.due=$("#ms_due").value;d.remind=+$("#ms_rem").value||30;d.comments=$("#ms_com").value;
}
function msDraw(){
  var w=S.ms,d=w.d,el=w.cat==="ct",it=getItem(w.cat,w.id);
  var files=(d.attachments||[]).map(function(a,i){return '<li><a href="#" data-blob="'+esc(a.id)+'">'+esc(a.name)+'</a><button type="button" class="btn small danger" data-act="msrmfile" data-i="'+i+'">'+(el?"Αφαίρεση":"Remove")+'</button></li>'}).join("");
  openPanel('<div class="ph"><div><h2>'+(w.mid?(el?"Επεξεργασία milestone":"Edit milestone"):(el?"Νέο milestone":"New milestone"))+'</h2><span class="hint">'+esc(msTitle(w.cat,it))+' · '+(el?"Έτος ":"Year ")+w.year+'</span></div><button class="btn small" type="button" data-act="mscancel">'+(el?"Άκυρο":"Cancel")+'</button></div>'+
   '<label class="f">'+(el?"Περιγραφή":"Description")+'<textarea id="ms_desc" maxlength="1000">'+esc(d.description)+'</textarea></label>'+
   '<div class="grid2"><label class="f">'+(el?"Ημερομηνία παράδοσης":"Delivery date")+'<input id="ms_due" type="date" value="'+esc(d.due)+'"></label>'+
   '<label class="f">'+(el?"Ειδοποίηση":"Alert")+'<select id="ms_rem">'+remOpts(d.remind,REMIND_MS,el?" ημέρες πριν":" days before")+'</select></label></div>'+
   '<label class="f">'+(el?"Σχόλια":"Comments")+'<textarea id="ms_com" maxlength="4000">'+esc(d.comments)+'</textarea></label>'+
   '<div class="sec"><h3>'+(el?"Συνημμένα":"Attachments")+'</h3>'+(files?'<ul class="files">'+files+'</ul>':'<span class="hint">'+(el?"Δεν υπάρχουν συνημμένα.":"No attachments yet.")+'</span>')+
   '<div><button class="btn" type="button" data-act="msattach"'+(S.assets?'':' disabled')+'>'+(el?"+ Προσθήκη αρχείων":"+ Attach files")+'</button> <span class="hint">'+(el?"Μέγιστο μέγεθος αρχείου "+attMB()+" MB.":"Max file size "+attMB()+" MB.")+'</span></div></div>'+
   '<div class="err" id="mserr">'+esc(w.err)+'</div><div class="actions"><button class="btn primary" type="button" data-act="mssave">'+(el?"Αποθήκευση":"Save")+'</button></div>',"ms");
}
function msPick(){
  var inp=document.createElement("input");inp.type="file";inp.multiple=true;
  inp.addEventListener("change",function(){var fl=Array.prototype.slice.call(inp.files);if(fl.length)msUpload(fl)});
  inp.click();
}
async function msUpload(files){
  var w=S.ms;if(!w||!S.assets)return;msCollect();var el=w.cat==="ct";
  for(var i=0;i<files.length;i++){
    var f=files[i],ext=(f.name.split(".").pop()||"").toLowerCase(),type=f.type&&MIME[ext]===f.type?f.type:MIME[ext]||f.type;
    var big=attTooBig(f,el);if(big){toast(f.name+": "+big);continue}
    try{var r=await S.assets.upload(f,type?{type:type}:undefined);w.d.attachments.push({id:r.id,name:f.name,size:r.sizeBytes});w.added.push(r.id)}
    catch(e){toast(f.name+": "+(e&&e.code==="unsupported_type"?(el?"μη υποστηριζόμενος τύπος":"file type not supported"):e&&(e.code==="bad_content"||e.code==="infected")?(el?(e.code==="infected"?"το αρχείο απορρίφθηκε από τον έλεγχο ιών":"το περιεχόμενο δεν ταιριάζει με τον τύπο του αρχείου, ή είναι πρόγραμμα"):(e.code==="infected"?"refused by the antivirus check":"content does not match the file type, or it is a program")):e&&e.code==="av_unavailable"?(el?"ο έλεγχος ιών δεν ολοκληρώθηκε· το αρχείο δεν αποθηκεύτηκε":"antivirus check could not be completed; file not stored"):e&&e.code==="too_large"?(el?"μεγαλύτερο από το όριο ("+attMB()+" MB)":"larger than the limit ("+attMB()+" MB)"):(el?"αποτυχία μεταφόρτωσης":"upload failed")))}
  }
  msDraw();
}
async function msSave(){
  var w=S.ms;msCollect();var d=w.d,el=w.cat==="ct",it=getItem(w.cat,w.id);if(!it)return;
  var e="";
  if(!String(d.description).trim())e=el?"Συμπλήρωσε την περιγραφή.":"Enter a description.";
  else if(!parseIso(d.due))e=el?"Επίλεξε ημερομηνία παράδοσης.":"Choose a delivery date.";
  if(e){w.err=e;var x=$("#mserr");if(x)x.textContent=e;return}
  var obj={id:w.mid||uid(),year:w.year,description:String(d.description).trim(),due:d.due,remind:d.remind===60?60:30,comments:String(d.comments||"").trim(),done:!!d.done,attachments:d.attachments||[]};
  var list=msList(it).slice(),i=list.findIndex(function(x){return x.id===obj.id});
  if(i>=0)list[i]=obj;else list.push(obj);
  var rec=strip(it);rec.milestones=list;
  if(await save(w.id,rec,w.cat)){
    var gone=(w.removed||[]).slice();
    for(var k=0;k<gone.length;k++){try{await S.assets.delete(gone[k])}catch(_){}}
    S.ms=null;toast(el?"Το milestone αποθηκεύτηκε":"Milestone saved");reopen(w.cat,w.id);
  }
}
async function msCancel(){
  var w=S.ms;if(!w)return;
  var add=(w.added||[]).slice();S.ms=null;
  for(var k=0;k<add.length;k++){try{await S.assets.delete(add[k])}catch(_){}}
  reopen(w.cat,w.id);
}
async function msToggleDone(mid){
  var cat=S.openCat||"sw",it=getItem(cat,S.open);if(!it)return;
  var list=msList(it).map(function(m){return m.id===mid?Object.assign({},m,{done:!m.done}):m});
  var rec=strip(it);rec.milestones=list;
  if(await save(it.id,rec,cat))reopen(cat,it.id);
}
async function msDelete(mid){
  var cat=S.openCat||"sw",it=getItem(cat,S.open);if(!it)return;
  var m=msList(it).find(function(x){return x.id===mid});if(!m)return;
  var before=msList(it).slice(),id=it.id,el=cat==="ct",rec=strip(it);rec.milestones=before.filter(function(x){return x.id!==mid});
  if(await save(id,rec,cat)){
    reopen(cat,id);
    /* the milestone's files are only deleted when the 8 s to undo are over */
    toastUndo(el?"Το milestone διαγράφηκε":"Milestone deleted",async function(){
      var cur=getItem(cat,id);if(!cur)return;var r2=strip(cur);r2.milestones=before;
      if(await save(id,r2,cat)&&S.open===id)reopen(cat,id);
    },async function(){var f=(m.attachments||[]);for(var k=0;k<f.length;k++){try{await S.assets.delete(f[k].id)}catch(_){}}},el);
  }
}

/* Passwords are no longer kept: records saved by older versions lose theirs the first time they are loaded. */
async function purgePasswords(){
  var old=S.items.filter(function(i){return Object.prototype.hasOwnProperty.call(i,"password")});
  for(var k=0;k<old.length;k++){var rec=strip(old[k]);delete rec.password;try{await col("software").doc(old[k].id).set(rec)}catch(e){}}
}

/* ---------- list columns: choose which to show, sort every column ---------- */
function emailsErr(v,el){
  var l=String(v||"").split(/[,;\s]+/).filter(Boolean);
  if(l.length>20)return el?"Έως 20 διευθύνσεις email.":"At most 20 e-mail addresses.";
  for(var i=0;i<l.length;i++){if(!/^[^\s@,;]+@[^\s@,;]+\.[^\s@,;]{2,}$/.test(l[i]))return (el?"Μη έγκυρο email: ":"Invalid e-mail address: ")+l[i]}
  return "";
}
function msOpen(it){return msList(it).filter(function(m){return !m.done}).length}
function msText(it){
  return msList(it).map(function(m){return "Έτος "+m.year+": "+m.description+" - "+fmtDate(m.due)+" ("+(+m.remind||30)+"d)"+(m.done?" [done]":"")}).join("; ");
}
function cTxt(f){return {v:function(it){return esc(it[f]||"—")},s:function(it){return it[f]||""}}}
function cNum(f){return {v:function(it){return '<span class="num">'+(it[f]===""||it[f]==null?"—":money(it[f]))+'</span>'},s:function(it){return it[f]===""||it[f]==null?"":Number(it[f])}}}
function cDate(f){return {v:function(it){return '<span class="mono">'+fmtDate(it[f])+'</span>'},s:function(it){return it[f]||""}}}
function cFiles(){return {v:function(it){var n=(it.attachments||[]).length;return '<span class="sub">'+(n?n+" file"+(n>1?"s":""):"—")+'</span>'},s:function(it){return (it.attachments||[]).length}}}
function cMs(){return {v:function(it){var a=msList(it).length,o=msOpen(it);return '<span class="num">'+(a?o+" / "+a:"—")+'</span>'},s:function(it){return msOpen(it)}}}
function cEm(){return {v:function(it){return '<span class="sub">'+esc(it.emails||"—")+'</span>'},s:function(it){return it.emails||""}}}
function cdef(k,l,d,w,o){return Object.assign({k:k,l:l,d:d,w:w},o)}
var COLS={
 sw:[
  cdef("name","Software",1,"2fr",{v:function(it){return '<span class="n">'+esc(it.name)+(it.sample?' <span class="hint">(sample)</span>':'')+'</span>'},s:function(it){return it.name||""}}),
  cdef("vendor","Vendor",1,"1.2fr",cTxt("vendor")),
  cdef("description","Description",0,"2fr",cTxt("description")),
  cdef("website","Website",0,"1.4fr",cTxt("website")),
  cdef("username","Username",0,"1.2fr",cTxt("username")),
  cdef("dateFrom","Date From",1,"1fr",cDate("dateFrom")),
  cdef("dateTo","Expires",1,"1fr",cDate("dateTo")),
  cdef("status","Status",1,"1.2fr",{v:function(it){var s=status(it);return '<span class="pill '+s.k+'">'+s.t+'</span> <span class="sub">'+dayText(s.d)+'</span>'},s:function(it){var d=status(it).d;return d==null?"":d}}),
  cdef("cost","Cost excl. VAT",1,"1fr",cNum("cost")),
  cdef("remindDays","Reminder",0,"1fr",{v:function(it){return '<span class="num">'+(+it.remindDays||30)+' d</span>'},s:function(it){return +it.remindDays||30}}),
  cdef("milestones","Milestones",0,"1fr",cMs()),
  cdef("emails","Notification emails",0,"1.6fr",cEm()),
  cdef("files","Files",1,"90px",cFiles())
 ],
 ct:[
  cdef("title","Σύμβαση",1,"2fr",{v:function(c){return '<span class="n">'+esc(c.title)+(c.sample?' <span class="hint">(δείγμα)</span>':'')+'</span>'},s:function(c){return c.title||""}}),
  cdef("tender","Αρ. διαγωνισμού",1,"1fr",cTxt("tender")),
  cdef("description","Περιγραφή",0,"2fr",cTxt("description")),
  cdef("contractor","Ανάδοχος",1,"1.3fr",{v:function(c){return esc(ctrOf(c).name||"—")},s:function(c){return ctrOf(c).name}}),
  cdef("coordinator","Συντονιστής",0,"1.2fr",cTxt("coordinator")),
  cdef("months","Διάρκεια (μήνες)",0,"1fr",{v:function(c){return '<span class="num">'+esc(c.months||"—")+'</span>'},s:function(c){return Number(c.months)||""}}),
  cdef("dateFrom","Έναρξη",0,"1fr",cDate("dateFrom")),
  cdef("dateTo","Λήξη",1,"1fr",cDate("dateTo")),
  cdef("status","Κατάσταση",1,"1.3fr",{v:function(c){var s=ctInfo(c);return '<span class="pill '+s.k+'">'+s.t+'</span> <span class="sub">'+esc(s.sub)+'</span>'},s:function(c){var d=ctInfo(c).d;return d==null?"":d}}),
  cdef("cost","Κόστος",1,"1fr",{v:function(c){return '<span class="num">'+money(ctTotal(c))+'</span>'},s:function(c){return ctTotal(c)}}),
  cdef("milestones","Milestones",0,"1fr",cMs()),
  cdef("emails","Email ειδοποιήσεων",0,"1.6fr",cEm()),
  cdef("files","Αρχεία",1,"90px",cFiles())
 ],
 co:[
  cdef("name","Ανάδοχος",1,"2fr",{v:function(c){return '<span class="n">'+esc(c.name)+(c.sample?' <span class="hint">(δείγμα)</span>':'')+'</span>'},s:function(c){return c.name||""}}),
  cdef("address","Διεύθυνση",0,"2fr",{v:function(c){return esc(coAddr(c)||"—")},s:function(c){return coAddr(c)}}),
  cdef("city","Πόλη",0,"1fr",cTxt("city")),
  cdef("contact","Άτομο επικοινωνίας",1,"1.3fr",cTxt("contact")),
  cdef("email","Email",1,"1.5fr",cTxt("email")),
  cdef("phone","Τηλέφωνο",1,"1.2fr",cTxt("phone")),
  cdef("active","Ενεργές συμβάσεις",1,"1fr",{v:function(c){return '<span class="num">'+coStats(c.id).n+'</span>'},s:function(c){return coStats(c.id).n}}),
  cdef("tenders","Αρ. διαγωνισμού ενεργών συμβάσεων",1,"2fr",{v:function(c){var t=coStats(c.id).tenders;return t.length?'<span class="sub">'+t.map(esc).join(", ")+'</span>':"—"},s:function(c){return coStats(c.id).tenders.join(", ")}})
 ],
 tn:[
  cdef("title","Διαγωνισμός",1,"2fr",{v:function(c){return '<span class="n">'+esc(c.title)+(c.sample?' <span class="hint">(δείγμα)</span>':'')+'</span>'},s:function(c){return c.title||""}}),
  cdef("tender","Αρ. διαγωνισμού",1,"1fr",cTxt("tender")),
  cdef("description","Περιγραφή",0,"2fr",cTxt("description")),
  cdef("months","Διάρκεια (μήνες)",1,"1fr",{v:function(c){return '<span class="num">'+esc(c.months||"—")+'</span>'},s:function(c){return Number(c.months)||""}}),
  cdef("dateFrom","Εκτιμ. έναρξη",1,"1fr",cDate("dateFrom")),
  cdef("dateTo","Εκτιμ. λήξη",1,"1fr",cDate("dateTo")),
  cdef("status","Κατάσταση",1,"1.4fr",{v:function(c){var s=tnInfo(c);return '<span class="pill '+s.k+'">'+s.t+'</span> <span class="sub">'+esc(s.sub)+'</span>'},s:function(c){return tnInfo(c).t}}),
  cdef("cost","Εκτιμώμενο κόστος",1,"1fr",cNum("cost")),
  cdef("files","Αρχεία",1,"90px",cFiles())
 ]
};
function loadPrefs(){
  var d={cols:{sw:[],ct:[],tn:[],co:[]},sort:{sw:{k:"dateTo",dir:1},ct:{k:"dateTo",dir:1},tn:{k:"dateFrom",dir:1},co:{k:"name",dir:1}}},p=null;
  try{p=JSON.parse(localStorage.getItem("rl.listprefs")||"null")}catch(e){}
  ["sw","ct","tn","co"].forEach(function(c){
    var keys=colsAll(c).map(function(x){return x.k}),sel=p&&p.cols&&Array.isArray(p.cols[c])?p.cols[c].filter(function(k){return keys.indexOf(k)>=0}):null;
    d.cols[c]=sel&&sel.length?sel:colsAll(c).filter(function(x){return x.d}).map(function(x){return x.k});
    var so=p&&p.sort&&p.sort[c];if(so&&keys.indexOf(so.k)>=0)d.sort[c]={k:so.k,dir:so.dir===-1?-1:1};
  });
  return d;
}
function savePrefs(){try{localStorage.setItem("rl.listprefs",JSON.stringify({cols:S.cols,sort:S.sort}))}catch(e){}}
function colsOf(cat){var sel=S.cols[cat];return colsAll(cat).filter(function(c){return sel.indexOf(c.k)>=0})}
function sortList(cat,list){
  var so=S.sort[cat],c=colsAll(cat).filter(function(x){return x.k===so.k})[0]||colsAll(cat).filter(function(x){return x.k==="dateTo"})[0];
  return list.slice().sort(function(a,b){
    var x=c.s(a),y=c.s(b),xe=x===""||x==null,ye=y===""||y==null;
    if(xe||ye)return xe&&ye?0:xe?1:-1; /* empty values always last */
    var r=typeof x==="number"&&typeof y==="number"?x-y:String(x).localeCompare(String(y),"el",{numeric:true,sensitivity:"base"});
    return r*so.dir||String(a.id).localeCompare(String(b.id));
  });
}
function listHtml(cat,rows){
  var cs=colsOf(cat),so=S.sort[cat],el=cat!=="sw";
  var MIN={name:210,title:230,description:250,website:180,emails:210,status:200,files:80,months:110,remindDays:90,milestones:100,cost:110,tender:130,vat:120,city:120,active:120,tenders:150,phone:140};
  var mins=cs.map(function(c){return MIN[c.k]||125}),total=mins.reduce(function(x,y){return x+y},0);
  var tpl=cs.map(function(c,i){return c.k==="files"?mins[i]+"px":"minmax("+mins[i]+"px,"+c.w+")"}).join(" ");
  var st='grid-template-columns:'+tpl+';min-width:'+total+'px';
  var h='<div class="lw"><div class="head"'+(el?' lang="el"':'')+' style="'+st+'">'+cs.map(function(c){
    var on=so.k===c.k;
    return '<button type="button" class="hc" data-sort="'+c.k+'" aria-sort="'+(on?(so.dir===1?"ascending":"descending"):"none")+'" title="'+(el?"Ταξινόμηση":"Sort")+'">'+esc(c.l)+'<span class="ar">'+(on?(so.dir===1?" ▲":" ▼"):"")+'</span></button>';
  }).join("")+'</div>';
  h+=rows.map(function(it){
    return '<button type="button" class="row" data-id="'+esc(it.id)+'" style="'+st+'">'+cs.map(function(c,i){
      var sv=c.s(it),tt=sv===""||sv==null||c.k==="status"?"":' title="'+esc(String(sv))+'"';
      return '<span class="cell" data-l="'+esc(c.l)+'"'+(i?'':' data-first="1"')+tt+'>'+c.v(it)+'</span>';
    }).join("")+'</button>';
  }).join("")+'</div>';
  return h;
}
function setSort(k){
  var cat=S.cat,so=S.sort[cat];
  S.sort[cat]=so.k===k?{k:k,dir:-so.dir}:{k:k,dir:1};
  savePrefs();render();
}
function showCols(){
  var cat=S.cat,el=cat!=="sw",sel=S.cols[cat];
  var h='<div class="ph"><h2>'+(el?"Στήλες λίστας":"List columns")+'</h2><button class="btn small" type="button" data-act="close">'+(el?"Κλείσιμο":"Close")+'</button></div>'+
   '<p class="hint">'+(el?"Επίλεξε ποιες στήλες θα εμφανίζονται στην αρχική σελίδα. Μπορείς να ταξινομήσεις οποιαδήποτε στήλη πατώντας στην επικεφαλίδα της.":"Choose which columns are shown on the main page. Click any column heading to sort it ascending or descending.")+'</p>'+
   '<div class="colpick">'+colsAll(cat).map(function(c){return '<label><input type="checkbox" data-col="'+c.k+'"'+(sel.indexOf(c.k)>=0?' checked':'')+'> '+esc(c.l)+'</label>'}).join("")+'</div>'+
   '<div class="actions"><button class="btn" type="button" data-act="colsreset">'+(el?"Προεπιλογή":"Reset to default")+'</button></div>';
  openPanel(h,"cols");
}
function toggleCol(k,on){
  var cat=S.cat,sel=S.cols[cat].slice(),i=sel.indexOf(k);
  if(on&&i<0)sel.push(k);if(!on&&i>=0)sel.splice(i,1);
  if(!sel.length){showCols();return}
  S.cols[cat]=sel;savePrefs();render();
}
function resetCols(){S.cols[S.cat]=colsAll(S.cat).filter(function(x){return x.d}).map(function(x){return x.k});S.sort[S.cat]={k:S.cat==="tn"?"dateFrom":S.cat==="co"?"name":"dateTo",dir:1};savePrefs();render();showCols()}
var PREFS=loadPrefs();S.cols=PREFS.cols;S.sort=PREFS.sort;

/* ---------- budget breakdown: partial amounts per year, each with a budget article ---------- */
var DEFAULT_ARTICLES=[{"code":"03460","desc":"Τηλεπικοινωνιακός, Μηχανογραφικός και Άλλος Εξοπλισμός","cat":"03300","catDesc":"ΣΥΝΤΗΡΗΣΕΙΣ ΚΑΙ ΕΠΙΔΙΟΡΘΩΣΕΙΣ","split":true},{"code":"03461","desc":"Συντήρηση Μηχανογραφικού Εξοπλισμού","cat":"03300","catDesc":"ΣΥΝΤΗΡΗΣΕΙΣ ΚΑΙ ΕΠΙΔΙΟΡΘΩΣΕΙΣ","split":true},{"code":"03462","desc":"Συντήρηση Τηλεπικοινωνιακού Εξοπλισμού","cat":"03300","catDesc":"ΣΥΝΤΗΡΗΣΕΙΣ ΚΑΙ ΕΠΙΔΙΟΡΘΩΣΕΙΣ","split":true},{"code":"03466","desc":"Συντήρηση Εξοπλισμού Γραφείου","cat":"03300","catDesc":"ΣΥΝΤΗΡΗΣΕΙΣ ΚΑΙ ΕΠΙΔΙΟΡΘΩΣΕΙΣ","split":true},{"code":"03468","desc":"Συντήρηση Άλλου Εξοπλισμού","cat":"03300","catDesc":"ΣΥΝΤΗΡΗΣΕΙΣ ΚΑΙ ΕΠΙΔΙΟΡΘΩΣΕΙΣ","split":true},{"code":"03583","desc":"Αγορά Υπηρεσιών","cat":"03580","catDesc":"ΣΥΜΒΑΣΗ ΥΠΗΡΕΣΙΩΝ","split":true},{"code":"07651","desc":"Αγορά Μηχανολογικού και Ηλεκτρονικού Εξοπλισμού","cat":"07650","catDesc":"ΑΓΟΡΑ ΕΞΟΠΛΙΣΜΟΥ","split":false},{"code":"07654","desc":"Αγορά Εξοπλισμού Γραφείων","cat":"07650","catDesc":"ΑΓΟΡΑ ΕΞΟΠΛΙΣΜΟΥ","split":false},{"code":"07655","desc":"Αγορά Τηλεπικοινωνιακού Εξοπλισμού","cat":"07650","catDesc":"ΑΓΟΡΑ ΕΞΟΠΛΙΣΜΟΥ","split":false},{"code":"07661","desc":"Αγορά Ηλεκτρονικών Συστημάτων Ασφάλειας","cat":"07650","catDesc":"ΑΓΟΡΑ ΕΞΟΠΛΙΣΜΟΥ","split":false},{"code":"07663","desc":"Αγορά Συστημάτων Πυρασφάλειας","cat":"07650","catDesc":"ΑΓΟΡΑ ΕΞΟΠΛΙΣΜΟΥ","split":false},{"code":"07681","desc":"Αγορά Μηχανογραφικού Εξοπλισμού, Προγραμμάτων και Υπηρεσιών","cat":"07650","catDesc":"ΑΓΟΡΑ ΕΞΟΠΛΙΣΜΟΥ","split":false},{"code":"07755","desc":"Εφαρμογή του Προτύπου ISO 27002","cat":"07750","catDesc":"ΑΓΟΡΑ ΑΛΛΩΝ ΣΤΟΙΧΕΙΩΝ ΕΝΕΡΓΗΤΙΚΟΥ","split":false},{"code":"07758","desc":"Δορυφορικές Εικόνες","cat":"07750","catDesc":"ΑΓΟΡΑ ΑΛΛΩΝ ΣΤΟΙΧΕΙΩΝ ΕΝΕΡΓΗΤΙΚΟΥ","split":false},{"code":"07759","desc":"Ανάπτυξη Συστήματος Διαχείρισης Μέτρων του Προγράμματος Αγροτικής Ανάπτυξης","cat":"07750","catDesc":"ΑΓΟΡΑ ΑΛΛΩΝ ΣΤΟΙΧΕΙΩΝ ΕΝΕΡΓΗΤΙΚΟΥ","split":false},{"code":"07760","desc":"Επανασχεδιασμός Ολοκληρωμένου Συστήματος Διαχείρισης και Ελέγχου (ΟΣΔΕ)","cat":"07750","catDesc":"ΑΓΟΡΑ ΑΛΛΩΝ ΣΤΟΙΧΕΙΩΝ ΕΝΕΡΓΗΤΙΚΟΥ","split":false},{"code":"07761","desc":"Ανάπτυξη Μηχανογραφικών Συστημάτων για την Νέα Κοινή Αγροτική Πολιτική (ΚΑΠ)","cat":"07750","catDesc":"ΑΓΟΡΑ ΑΛΛΩΝ ΣΤΟΙΧΕΙΩΝ ΕΝΕΡΓΗΤΙΚΟΥ","split":false}];
function r2(x){return Math.round((Number(x)||0)*100)/100}
/* article = {code, desc, cat, catDesc, split}; split = "ΠΟΣΟ ΑΝΑΛΥΣΗΣ ΑΝΑ ΕΤΟΣ" is ΝΑΙ */
function normArt(x){
  if(typeof x==="string")return parseArtLines(x)[0]||null;
  if(!x||!x.code)return null;
  return {code:String(x.code),desc:String(x.desc||""),cat:String(x.cat||""),catDesc:String(x.catDesc||""),split:!!x.split};
}
function parseArtLines(text){
  var out=[],seen={};
  String(text||"").split(/\r?\n/).forEach(function(line){
    var p=line.split(/\t|\|/).map(function(x){return x.trim()}),code=(p[0]||"").slice(0,40);
    if(!code||seen[code])return;seen[code]=1;
    out.push({code:code,desc:(p[1]||"").slice(0,200),cat:(p[2]||"").slice(0,40),catDesc:(p[3]||"").slice(0,200),split:/^(Ν|N|YES|Y)/i.test((p[4]||"").trim())});
  });
  return out.slice(0,500);
}
function artLines(list){return list.map(function(a){return [a.code,a.desc,a.cat,a.catDesc,a.split?"ΝΑΙ":"ΌΧΙ"].join(" | ")}).join("\n")}
function articles(){
  var a=null;
  if(window.RL_CFG&&Array.isArray(window.RL_CFG.articles))a=window.RL_CFG.articles;
  else{try{a=JSON.parse(localStorage.getItem("rl.articles")||"null")}catch(e){}}
  if(!Array.isArray(a))a=DEFAULT_ARTICLES;
  return a.map(normArt).filter(Boolean);
}
/* find an article by its code (also accepts "code description" text) */
function artFind(v,list){
  v=String(v||"").trim();if(!v)return null;list=list||articles();
  for(var i=0;i<list.length;i++)if(list[i].code===v)return list[i];
  var t=v.split(/\s/)[0];
  for(var j=0;j<list.length;j++)if(list[j].code===t)return list[j];
  return null;
}
function artLabel(v){var a=artFind(v);return a?(a.code+" — "+a.desc):String(v||"")}
function artOpts(v,el){
  var l=articles(),cur=artFind(v,l),val=cur?cur.code:String(v||""),groups=[],map={};
  l.forEach(function(a){var k=a.cat+"|"+a.catDesc;if(!map[k]){map[k]={t:(a.cat+(a.catDesc?" · "+a.catDesc:"")).trim(),l:[]};groups.push(map[k])}map[k].l.push(a)});
  var opt=function(a){return '<option value="'+esc(a.code)+'"'+(a.code===val?' selected':'')+'>'+esc(a.code+" — "+a.desc)+'</option>'};
  var h='<option value="">'+(el?"— Άρθρο προϋπολογισμού —":"— Budget article —")+'</option>'+groups.map(function(g){return '<optgroup label="'+esc(g.t)+'">'+g.l.map(opt).join("")+'</optgroup>'}).join("");
  if(val&&!cur)h+='<option value="'+esc(val)+'" selected>'+esc(val)+'</option>';
  return h;
}
function bpHas(d,year){return (d.budget||[]).some(function(p){return year==null||+p.year===year})}
function bpSum(list,year){return r2((list||[]).filter(function(p){return year==null||+p.year===year}).reduce(function(a,p){return a+(Number(p.amount)||0)},0))}
function bpCollect(d){(d.budget||[]).forEach(function(p,i){var a=$("#bp_amt_"+i),r=$("#bp_art_"+i),y=$("#bp_yr_"+i);if(a)p.amount=a.value;if(r)p.article=r.value;if(y)p.year=+y.value||1})}
function bpClean(d){return (d.budget||[]).filter(function(p){return p.amount!==""&&p.amount!=null&&isFinite(Number(p.amount))}).map(function(p){return {year:Math.max(1,+p.year||1),amount:r2(p.amount),article:String(p.article||"")}})}
function bpErr(d,el){
  for(var i=0;i<(d.budget||[]).length;i++){var p=d.budget[i];
    if(p.amount===""||p.amount==null){if(p.article)return el?"Συμπλήρωσε το ποσό σε κάθε επιμέρους γραμμή.":"Enter an amount on every partial amount line.";continue}
    if(!isFinite(Number(p.amount))||Number(p.amount)<0)return el?"Τα επιμέρους ποσά πρέπει να είναι αριθμοί, π.χ. 500.50.":"Partial amounts must be numbers, for example 500.50."}
  return "";
}
/* rows for one year (contracts) or all rows with a year selector (software) */
function bpBlock(d,year,el,nYears){
  var rows=(d.budget||[]).map(function(p,i){return {p:p,i:i}}).filter(function(x){return year==null||+x.p.year===year});
  var h='<div class="bpb">'+rows.map(function(x){
    var ysel=year==null?'<select id="bp_yr_'+x.i+'" title="'+(el?"Έτος":"Year")+'">'+Array.apply(null,Array(Math.max(nYears,+x.p.year||1))).map(function(_,k){return '<option value="'+(k+1)+'"'+((+x.p.year||1)===k+1?' selected':'')+'>'+(el?"Έτος ":"Year ")+(k+1)+'</option>'}).join("")+'</select>':'';
    return '<div class="bp">'+ysel+'<input id="bp_amt_'+x.i+'" type="number" step="0.01" min="0" inputmode="decimal" placeholder="'+(el?"Ποσό (€)":"Amount (€)")+'" value="'+esc(x.p.amount)+'"><select id="bp_art_'+x.i+'">'+artOpts(x.p.article,el)+'</select>'+
      '<button type="button" class="btn small danger" data-act="bpdel" data-i="'+x.i+'" title="'+(el?"Αφαίρεση":"Remove")+'">✕</button></div>'}).join("")+
    '<div><button type="button" class="btn small" data-act="bpadd"'+(year!=null?' data-year="'+year+'"':'')+'>'+(el?"+ Επιμέρους ποσό":"+ Add partial amount")+'</button></div></div>';
  return h;
}
function bpDetail(it,el){
  var l=it.budget||[];if(!l.length)return "";
  var years=[];l.forEach(function(p){if(years.indexOf(+p.year)<0)years.push(+p.year)});years.sort(function(a,b){return a-b});
  return '<div class="sec"><h3>'+(el?"Επιμέρους ποσά ανά έτος":"Cost breakdown")+'</h3>'+years.map(function(y){
    var rows=l.filter(function(p){return +p.year===y});
    return '<div class="msyear"><div class="msyh"><b>'+(el?"Έτος ":"Year ")+y+'</b><span class="num">'+(el?"Σύνολο ":"Total ")+(el?mc(bpSum(l,y)):money(bpSum(l,y)))+'</span></div><ul class="files">'+rows.map(function(p){
      return '<li><span>'+esc(p.article?artLabel(p.article):(el?"(χωρίς άρθρο)":"(no article)"))+'</span><span class="num">'+(el?mc(p.amount):money(p.amount))+'</span></li>'}).join("")+'</ul></div>'}).join("")+'</div>';
}
function bpText(it){
  return (it.budget||[]).map(function(p){return "Έτος "+p.year+": "+Number(p.amount).toFixed(2)+(p.article?" ["+artLabel(p.article)+"]":"")}).join("; ");
}
/* how many records (live and trashed) use an article code */
function artUsage(code){
  var n=0,fn=function(it){if((it.budget||[]).concat(it.extras||[]).some(function(p){return String(p.article||"")===code}))n++};
  S.items.forEach(fn);S.contracts.forEach(fn);S.tenders.forEach(fn);S.trash.sw.forEach(fn);S.trash.ct.forEach(fn);S.trash.tn.forEach(fn);
  return n;
}
/* what the user may do with the articles: add (create), change (edit), remove (delete). Browser builds: everything. */
function artCan(k){return !window.RL_CFG||!!(window.RL_CFG.artPerms&&window.RL_CFG.artPerms[k])}
function artRow(a){
  var isNew=!a,ro=!isNew&&!artCan("edit")?' disabled':'',noDel=!artCan("delete")?' disabled':'';
  a=a||{code:"",desc:"",cat:"",catDesc:"",split:false};
  return '<tr><td><input data-k="code" value="'+esc(a.code)+'" size="7" aria-label="Κωδικός"'+ro+'></td><td><input data-k="desc" value="'+esc(a.desc)+'" aria-label="Περιγραφή άρθρου"'+ro+'></td><td><input data-k="cat" value="'+esc(a.cat)+'" size="7" aria-label="Κατηγορία"'+ro+'></td><td><input data-k="catDesc" value="'+esc(a.catDesc)+'" aria-label="Περιγραφή κατηγορίας"'+ro+'></td>'+
   '<td><select data-k="split" aria-label="Ποσό ανάλυσης ανά έτος"'+ro+'><option value="1"'+(a.split?' selected':'')+'>ΝΑΙ</option><option value="0"'+(a.split?'':' selected')+'>ΌΧΙ</option></select></td>'+
   '<td class="artuse">'+(a.code&&artUsage(a.code)?artUsage(a.code):"—")+'</td><td><button class="btn small" type="button" data-act="artdel" title="'+(noDel?'Δεν έχεις δικαίωμα διαγραφής άρθρων':'Διαγραφή άρθρου')+'"'+noDel+'>✕</button></td></tr>';
}
function showArticles(){
  var el=S.cat!=="sw";
  openPanel('<div class="ph"><h2>'+(el?"Άρθρα προϋπολογισμού":"Budget articles")+'</h2><button class="btn small" type="button" data-act="close">'+(el?"Κλείσιμο":"Close")+'</button></div>'+
   '<p class="hint">'+(el?"Κάθε γραμμή είναι ένα άρθρο. «Ποσό ανάλυσης ανά έτος»: ΝΑΙ = το ποσό κατανέμεται ανά μήνα στα έτη της περιόδου, ΌΧΙ = στο έτος έναρξης. Άρθρο που χρησιμοποιείται σε εγγραφές δεν μπορεί να διαγραφεί ή να αλλάξει κωδικό.":"Each row is one article. Split per year: ΝΑΙ = spread by month over the years of the period, ΌΧΙ = start year. An article used by records cannot be deleted or have its code changed.")+'</p>'+
   '<div class="tbl"><table class="art"><thead><tr><th>Κωδικός</th><th>Περιγραφή άρθρου</th><th>Κατηγορία</th><th>Περιγραφή κατηγορίας</th><th>Ανάλυση ανά έτος</th><th>Σε χρήση</th><th></th></tr></thead><tbody id="artRows">'+articles().map(artRow).join("")+'</tbody></table></div>'+
   '<div class="actions"><button class="btn" type="button" data-act="artadd"'+(artCan("create")?'':' disabled title="Δεν έχεις δικαίωμα προσθήκης άρθρων"')+'>'+(el?"+ Προσθήκη νέου άρθρου":"+ Add article")+'</button><button class="btn primary" type="button" data-act="artsave">'+(el?"Αποθήκευση":"Save")+'</button></div>',"arts");
}
function saveArticles(){
  var list=[],seen={};
  [].forEach.call(document.querySelectorAll("#artRows tr"),function(tr){
    var o={};[].forEach.call(tr.querySelectorAll("[data-k]"),function(n){o[n.dataset.k]=n.value.replace(/[|\t\r\n]/g," ").trim()});
    if(!o.code||seen[o.code])return;seen[o.code]=1;
    list.push({code:o.code.slice(0,40),desc:(o.desc||"").slice(0,200),cat:(o.cat||"").slice(0,40),catDesc:(o.catDesc||"").slice(0,200),split:o.split==="1"});
  });
  var kept=[];
  articles().forEach(function(a){if(!seen[a.code]&&artUsage(a.code)){list.push(a);kept.push(a.code)}});
  list=list.slice(0,500);
  function done(){
    closePanel();toast(kept.length?(S.cat!=="sw"?"Αποθηκεύτηκαν. Διατηρήθηκαν επειδή χρησιμοποιούνται: ":"Saved. Kept because they are in use: ")+kept.join(", "):S.cat!=="sw"?"Τα άρθρα αποθηκεύτηκαν":"Articles saved");
    if(S.cat==="bd"||S.cat==="ar")render();else{var ca=$("#cntAr");if(ca)ca.textContent=articles().length||""}
  }
  if(window.RL_SAVE_ARTICLES){
    /* WordPress: the server stores the list (and keeps articles that records still use) */
    window.RL_SAVE_ARTICLES(list).then(function(res){
      window.RL_CFG.articles=res.articles;kept=res.kept||[];done();
    },function(e){toast(e&&e.status===403?"Δεν έχεις δικαίωμα επεξεργασίας άρθρων":"Αποτυχία αποθήκευσης άρθρων: "+((e&&e.message)||""))});
    return;
  }
  try{localStorage.setItem("rl.articles",JSON.stringify(list))}catch(e){}
  done();
}
function bpRedraw(){
  if(ctLike(S.cat)){ctCollect();ctRefresh(true)}else{collect();drawWizard()}
}
function bpLive(){
  if(ctLike(S.cat)){ctCollect();(S.cw.d.years||[]).forEach(function(y,i){var c=$("#cy_cost_"+i);if(c&&bpHas(S.cw.d,i+1))c.value=y.cost});var sp=$("#cSum");if(sp)sp.textContent=mc(ctSum(S.cw.d.years));exTotals()}
  else{collect();var c=$("#w_cost");if(c&&bpHas(S.wiz.data))c.value=bpSum(S.wiz.data.budget)}
}

/* =============== TRASH VIEW =============== */
function fmtDay(ms){if(!ms)return "—";var d=new Date(ms);return ("0"+d.getDate()).slice(-2)+"/"+("0"+(d.getMonth()+1)).slice(-2)+"/"+d.getFullYear()}
function renderTrash(cat){
  var el=cat!=="sw",L=(S.trash[cat]||[]).slice().sort(function(a,b){return (b._at||0)-(a._at||0)}),days=trashDays(),now=Date.now();
  var canPurge=window.RL_TRASH?window.RL_TRASH.canPurge(collName(cat)):true;
  $("#stats").innerHTML='<div class="stat"><b>'+L.length+'</b><span>'+(el?"Στον κάδο":"In the trash")+'</span></div>';
  $("#alerts").innerHTML='<div class="alert"><span>'+(el?"Οι εγγραφές στον κάδο δεν εμφανίζονται στη λίστα, δεν στέλνουν υπενθυμίσεις και δεν μπαίνουν στον Προϋπολογισμό. ":"Records in the trash are hidden from the list, send no reminders and are left out of the budget. ")+
    (days?(el?"Διαγράφονται οριστικά "+days+" ημέρες μετά τη διαγραφή.":"They are deleted for good "+days+" days after deletion."):(el?"Δεν διαγράφονται αυτόματα.":"They are not removed automatically."))+'</span></div>';
  $("#chips").innerHTML='<button type="button" class="chip" data-f="all">← '+(el?"Πίσω στη λίστα":"Back to the list")+'</button>';
  var h;
  if(!L.length)h='<div class="empty"><h2>'+(el?"Ο κάδος είναι άδειος":"The trash is empty")+'</h2><p>'+(el?"Οι εγγραφές που διαγράφεις θα εμφανίζονται εδώ και θα μπορείς να τις επαναφέρεις.":"Records you delete show up here and can be restored.")+'</p></div>';
  else h='<div class="tbl"><table class="art"><thead><tr><th>'+(cat==="pv"?"Γενική Πρόνοια":cat==="co"?"Ανάδοχος":cat==="tn"?"Διαγωνισμός":el?"Σύμβαση":"Software")+'</th><th>'+(el?"Διαγράφηκε":"Deleted")+'</th><th>'+(el?"Οριστική διαγραφή σε":"Deleted for good in")+'</th><th></th></tr></thead><tbody>'+L.map(function(it){
    var left=days&&it._at?Math.max(0,Math.ceil((it._at+days*864e5-now)/864e5)):null;
    return '<tr><td>'+esc(recName(cat,it)||"—")+'</td><td>'+fmtDay(it._at)+(it._by?" · "+esc(it._by):"")+'</td><td>'+(left===null?"—":left+(el?" ημ.":" d"))+'</td><td class="trbtn"><button class="btn small" type="button" data-act="trrestore" data-id="'+esc(it.id)+'">'+(el?"Επαναφορά":"Restore")+'</button> '+
      '<button class="btn small danger" type="button" data-act="trpurge" data-id="'+esc(it.id)+'">'+(el?"Οριστική διαγραφή":"Delete for good")+'</button></td></tr>';
  }).join("")+'</tbody></table></div>';
  $("#list").innerHTML=h;
  if(!canPurge)[].forEach.call(document.querySelectorAll('[data-act=trpurge]'),function(n){n.hidden=true});
}

/* =============== BUDGET SHEET (Προϋπολογισμός) =============== */
/*BD-CALC-START*/
function bdParts(s){var m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(s||"");return m?{y:+m[1],m:+m[2],d:+m[3]}:null}
function bdGr(s){var p=bdParts(s);return p?(p.d<10?"0":"")+p.d+"/"+(p.m<10?"0":"")+p.m+"/"+p.y:"—"}
function bdEur(n){var v=r2(n),s=Math.abs(v).toFixed(2).split(".");return (v<0?"-":"")+s[0].replace(/\B(?=(\d{3})+(?!\d))/g,".")+","+s[1]+" €"}
function bdNum(n){return bdEur(n).replace(" €","")}
function bdMo(x){return String(Math.round(x*100)/100).replace(".",",")}
/* months of the period that fall in each calendar year; a part-month counts by the share of its days */
function bdMonths(f,t){
  var a=bdParts(f),b=bdParts(t);if(!a||!b||t<f)return null;
  var by={},tot=0,y=a.y,m=a.m;
  while(y<b.y||(y===b.y&&m<=b.m)){
    var dim=new Date(Date.UTC(y,m,0)).getUTCDate(),s=(y===a.y&&m===a.m)?a.d:1,e=(y===b.y&&m===b.m)?b.d:dim,fr=(e-s+1)/dim;
    by[y]=(by[y]||0)+fr;tot+=fr;m++;if(m>12){m=1;y++}
  }
  return {by:by,total:tot};
}
/* split=true (ΝΑΙ): spread by month over the calendar years of the period; otherwise the whole amount goes to the start year */
function bdAlloc(amount,from,to,split){
  var f=bdParts(from);if(!f)return null;
  var by={},txt,note="";
  if(split){
    var mo=bdMonths(from,to);
    if(mo){
      var ys=Object.keys(mo.by).map(Number).sort(function(a,b){return a-b});
      if(ys.length===1){by[ys[0]]=r2(amount);txt="όλο το διάστημα εντός του "+ys[0]}
      else{
        var acc=0,parts=[];
        ys.forEach(function(y,i){
          var v=i===ys.length-1?r2(amount-acc):r2(amount*mo.by[y]/mo.total);acc=r2(acc+v);by[y]=v;
          parts.push(y+": "+bdMo(mo.by[y])+"/"+bdMo(mo.total)+" μήνες = "+bdEur(v));
        });
        txt="κατανομή ανά μήνα ("+parts.join(", ")+")";
      }
      return {by:by,text:txt};
    }
    note=" (χωρίς έγκυρη ημερομηνία λήξης)";
  }
  by[f.y]=r2(amount);
  return {by:by,text:"ολόκληρο το ποσό στο έτος έναρξης "+f.y+note};
}
/* rows: one per record and article; amounts per calendar year */
var BD_VAT=0.19; /* amounts in the records are net of VAT; the budget sheet shows them including 19% VAT */
function bdBuild(arts,items,contracts,tenders,vat,provs){
  vat=vat==null?bdVat():vat;
  var rows={},order=[],warn=[];
  function rowFor(code,kind,id,desc,head){var k=code+"|"+kind+"|"+id;if(!rows[k]){rows[k]={code:code,kind:kind,id:id,desc:desc,how:head.slice(),by:{}};order.push(k)}return rows[k]}
  function seg(kind,id,desc,head,label,from,to,parts,cost,force){
    var list=(parts||[]).filter(function(p){var n=Number(p.amount);return p.amount!==""&&p.amount!=null&&isFinite(n)&&n!==0});
    if(!list.length&&Number(cost)>0)list=[{amount:Number(cost),article:""}];
    var groups={},gorder=[];
    list.forEach(function(p){
      var a=artFind(p.article,arts),code=a?a.code:"",g=groups[code];
      if(!g){g=groups[code]={a:a,sum:0,amts:[],raw:""};gorder.push(code)}
      g.sum=r2(g.sum+Number(p.amount));g.amts.push(Number(p.amount));
      if(!a&&p.article)g.raw=String(p.article);
    });
    gorder.forEach(function(code){
      var g=groups[code],gross=r2(g.sum*(1+vat)),al=bdAlloc(gross,from,to,!!(force||(g.a&&g.a.split)));
      if(!al){warn.push(desc+" ("+label+"): δεν έχει έγκυρη ημερομηνία έναρξης, το ποσό "+bdEur(g.sum)+" δεν περιλαμβάνεται.");return}
      var r=rowFor(code,kind,id,desc,head);
      Object.keys(al.by).forEach(function(y){r.by[y]=r2((r.by[y]||0)+al.by[y])});
      r.how.push(label+" ("+bdGr(from)+" – "+bdGr(to)+"): "+bdEur(g.sum)+(g.amts.length>1?" = "+g.amts.map(bdNum).join(" + "):"")+(vat?" + ΦΠΑ "+(Math.round(vat*10000)/100)+"% ("+bdEur(r2(gross-g.sum))+") = "+bdEur(gross):"")+" — "+al.text+(g.raw?" · το άρθρο «"+g.raw+"» δεν υπάρχει στη λίστα άρθρων":(code===""?" · χωρίς άρθρο":"")));
    });
  }
  (items||[]).forEach(function(it){
    seg("sw",it.id,it.name||"",["Ανανέωση: "+bdGr(it.dateFrom)+" – "+bdGr(it.dateTo)],"Ποσό",it.dateFrom,it.dateTo,it.budget,it.cost);
  });
  (contracts||[]).forEach(function(c){
    var head=["Διαγωνισμός: "+(c.tender||"—")+" · Διάρκεια: "+(c.months!==""&&c.months!=null?c.months:"—")+" μήνες","Σύμβαση: "+bdGr(c.dateFrom)+" – "+bdGr(c.dateTo)];
    (c.years||[]).forEach(function(y,i){
      seg("ct",c.id,c.title||"",head,"Έτος "+(i+1),y.from,y.to,(c.budget||[]).filter(function(p){return +p.year===i+1}),y.cost);
    });
  });
  /* additional / optional services: the yearly amount of every contract year, spread by month over that year (always monthly) */
  (contracts||[]).forEach(function(c){
    var head=["Διαγωνισμός: "+(c.tender||"—")+" · Διάρκεια: "+(c.months!==""&&c.months!=null?c.months:"—")+" μήνες","Σύμβαση: "+bdGr(c.dateFrom)+" – "+bdGr(c.dateTo)];
    (c.extras||[]).forEach(function(e){
      if(!exOk(e))return;
      (c.years||[]).forEach(function(y,i){
        seg("ct",c.id,c.title||"",head,"Έτος "+(i+1)+" · υπηρεσία «"+(e.desc||"")+"»",y.from,y.to,[{amount:Number(e.amount),article:e.article}],0,true);
      });
    });
  });
  (tenders||[]).forEach(function(c){
    var head=["Εκτιμώμενος διαγωνισμός: "+(c.tender||"—")+" · Διάρκεια: "+(c.months!==""&&c.months!=null?c.months:"—")+" μήνες","Εκτιμώμενη περίοδος: "+bdGr(c.dateFrom)+" – "+bdGr(c.dateTo)];
    (c.years||[]).forEach(function(y,i){
      seg("tn",c.id,c.title||"",head,"Έτος "+(i+1),y.from,y.to,(c.budget||[]).filter(function(p){return +p.year===i+1}),y.cost);
    });
  });
  /* general provisions (3.16.0): the amount of each of the 3 years goes whole into that calendar year, at the article of the provision */
  (provs||[]).forEach(function(p){
    var b=+p.baseYear||0;
    (p.amounts||[]).forEach(function(a){
      var y=+a.year;if(!y||y<=b||y>b+3)return;
      seg("pv",p.id,p.title||"",["Γενική Πρόνοια · καταχωρήθηκε το "+(b||"—")],"Πρόνοια "+y,y+"-01-01",y+"-12-31",[{amount:Number(a.amount),article:p.article}],0,false);
    });
  });
  var byArt={},min=null,max=null;
  order.forEach(function(k){
    var r=rows[k];(byArt[r.code]=byArt[r.code]||[]).push(r);
    Object.keys(r.by).forEach(function(y){y=+y;if(min===null||y<min)min=y;if(max===null||y>max)max=y});
  });
  Object.keys(byArt).forEach(function(c){byArt[c].sort(function(a,b){return a.desc.localeCompare(b.desc,"el")})});
  var years=[];if(min!==null)for(var y=min;y<=max;y++)years.push(y);
  return {byArt:byArt,years:years,warn:warn};
}
function bdTotals(rows,years){return years.map(function(y){return r2(rows.reduce(function(a,r){return a+(r.by[y]||0)},0))})}
/*BD-CALC-END*/
function bdSel(){
  var v=S.bdArt;if(v==null){try{v=localStorage.getItem("rl.bdart")}catch(e){}}
  return v||"all";
}
function bdTable(title,sub,rows,years){
  var tot=bdTotals(rows,years);
  return '<section class="bds"><h3>'+esc(title)+'</h3>'+(sub?'<p class="hint">'+esc(sub)+'</p>':'')+
   '<div class="tbl"><table class="bdt"><thead><tr><th>Α/Α</th><th>Λεπτομέρειες Δαπάνης (Περιγραφή)</th><th>Τρόπος Υπολογισμού</th>'+
   years.map(function(y){return '<th class="num">Προϋπολ.<br>ΕΤΟΣ <b class="yr">'+y+'</b><br>€ με ΦΠΑ</th>'}).join("")+'</tr></thead><tbody>'+
   (rows.length?rows.map(function(r,i){
     return '<tr class="src-'+esc(r.kind)+'"><td>'+(i+1)+'</td><td>'+esc(r.desc)+'</td><td class="how">'+r.how.map(esc).join("<br>")+'</td>'+years.map(function(y){return '<td class="num">'+(r.by[y]?bdNum(r.by[y]):"")+'</td>'}).join("")+'</tr>';
   }).join(""):'<tr><td colspan="'+(3+years.length)+'" class="hint">Δεν υπάρχουν γραμμές για αυτό το άρθρο.</td></tr>')+
   '<tr class="tot"><td colspan="3">Σύνολα</td>'+tot.map(function(v){return '<td class="num">'+bdNum(v)+'</td>'}).join("")+'</tr></tbody></table></div></section>';
}
function renderBd(){
  var arts=articles(),B=bdBuild(arts,S.items,S.contracts,S.tenders.filter(tnActive),null,S.provisions),sel=bdSel(),years=B.years.length?B.years:[new Date().getFullYear()];
  var all=[];Object.keys(B.byArt).forEach(function(c){all=all.concat(B.byArt[c])});
  var tot=bdTotals(all,years);
  /* search (v3.15.0): rows whose text matches, or every row of an article whose heading matches */
  var bq=String(S.q||"").trim().toLowerCase(),fB=B.byArt;
  if(bq){fB={};Object.keys(B.byArt).forEach(function(c){var a=artFind(c,arts),hit=(a?a.code+" "+a.desc+" "+a.cat+" "+(a.catDesc||""):"χωρίς άρθρο").toLowerCase().indexOf(bq)>=0;var rs=B.byArt[c].filter(function(r){return hit||(r.desc+" "+r.how.join(" ")).toLowerCase().indexOf(bq)>=0});if(rs.length)fB[c]=rs})}
  $("#stats").innerHTML=years.map(function(y,i){return '<div class="stat"><b class="num" style="font-family:var(--f-display)">'+bdNum(tot[i])+'</b><span>Σύνολο προϋπολογισμού <b class="yr">'+y+'</b> (€, με ΦΠΑ '+(BD_VAT*100)+'%)</span></div>'}).join("");
  $("#alerts").innerHTML=B.warn.map(function(w){return '<div class="alert bad"><span>'+esc(w)+'</span></div>'}).join("");
  var opts='<option value="all">Όλα τα άρθρα</option>'+arts.map(function(a){var n=(B.byArt[a.code]||[]).length;return '<option value="'+esc(a.code)+'"'+(sel===a.code?' selected':'')+'>'+esc(a.code+" — "+a.desc)+(n?" ("+n+")":"")+'</option>'}).join("")+
    (B.byArt[""]?'<option value="none"'+(sel==="none"?' selected':'')+'>Χωρίς άρθρο ('+B.byArt[""].length+')</option>':'');
  if(sel==="all")opts=opts.replace('<option value="all">','<option value="all" selected>');
  $("#chips").innerHTML='<label class="bdsel">Άρθρο <select id="bdArt">'+opts+'</select></label>'+(!window.RL_CFG||window.RL_CFG.canArticles?' <button type="button" class="chip" data-act="arts">Άρθρα προϋπολογισμού</button>':'');
  var h='<p class="bdleg"><span class="lg sw">Λογισμικά</span><span class="lg ct">Συμβάσεις</span><span class="lg tn">Διαγωνισμοί (εκτιμώμενοι)</span><span class="lg pv">Γενικές Πρόνοιες</span></p>';
  function secFor(a){return bdTable(a.code+" — "+a.desc,"Κατηγορία "+a.cat+(a.catDesc?" · "+a.catDesc:"")+" · Ποσό ανάλυσης ανά έτος: "+(a.split?"ΝΑΙ (κατανομή ανά μήνα στα έτη)":"ΌΧΙ (στο έτος έναρξης)"),fB[a.code]||[],years)}
  if(sel==="all"){
    var hlen=h.length;
    arts.forEach(function(a){if((fB[a.code]||[]).length)h+=secFor(a)});
    if(fB[""])h+=bdTable("Χωρίς άρθρο","Ποσά που δεν έχουν συνδεθεί με άρθρο προϋπολογισμού (ολόκληρο το ποσό στο έτος έναρξης).",fB[""],years);
    if(bq&&h.length===hlen)h='<div class="empty"><h2>Καμία γραμμή δεν ταιριάζει</h2><p>Δεν βρέθηκε τίποτα για «'+esc(S.q)+'» στον Προϋπολογισμό. Η αναζήτηση ψάχνει στον κωδικό και την περιγραφή του άρθρου, στην περιγραφή της δαπάνης και στον τρόπο υπολογισμού.</p></div>';
    if(h.length===hlen)h='<div class="empty"><h2>Δεν υπάρχουν ποσά ακόμα</h2><p>Ο πίνακας συμπληρώνεται αυτόματα από τα επιμέρους ποσά (με άρθρο) που καταχωρείς ανά έτος στις Συμβάσεις, στους ενεργούς Διαγωνισμούς και στα Λογισμικά.</p></div>';
  }else if(sel==="none")h=bdTable("Χωρίς άρθρο","Ποσά που δεν έχουν συνδεθεί με άρθρο προϋπολογισμού.",fB[""]||[],years);
  else{var a=artFind(sel,arts);h=a?secFor(a):""}
  if(bq)h='<p class="hint">Φίλτρο: «'+esc(S.q)+'». Τα «Σύνολα» κάθε πίνακα αφορούν μόνο τις γραμμές που εμφανίζονται· τα σύνολα στο πάνω μέρος αφορούν όλο τον προϋπολογισμό.</p>'+h;
  $("#list").innerHTML=h;
}
function bdExport(){
  if(needX())return;
  var arts=articles(),B=bdBuild(arts,S.items,S.contracts,S.tenders.filter(tnActive),null,S.provisions),years=B.years.length?B.years:[new Date().getFullYear()];
  var wb=XLSX.utils.book_new(),used={},fmt="#,##0.00";
  function name(s){s=String(s).replace(/[\\\/\?\*\[\]:]/g,"").trim().slice(0,31)||"Φύλλο";var n=s,k=2;while(used[n.toLowerCase()]){n=s.slice(0,28)+" "+k++}used[n.toLowerCase()]=1;return n}
  function num(v,f,c){var o={t:"n",v:v,z:fmt};if(f)o.f=f;return o}
  function colL(i){return XLSX.utils.encode_col(i)}
  var yh=years.map(function(y){return "Προϋπολ.\nΕΤΟΣ "+y+"\n€ με ΦΠΑ"});
  var sum=[["Άρθρο","Περιγραφή άρθρου","Κατηγορία","Ποσό ανάλυσης ανά έτος"].concat(yh)],codes=[];
  arts.forEach(function(a){if((B.byArt[a.code]||[]).length)codes.push(a.code)});
  codes.forEach(function(c){
    var a=artFind(c,arts),t=bdTotals(B.byArt[c],years);
    sum.push([a.code,a.desc,(a.cat+" "+a.catDesc).trim(),a.split?"ΝΑΙ":"ΌΧΙ"].concat(t.map(function(v){return num(v)})));
  });
  if(B.byArt[""]){sum.push(["—","Χωρίς άρθρο","","ΌΧΙ"].concat(bdTotals(B.byArt[""],years).map(function(v){return num(v)})))}
  var n=sum.length-1,trow=["Σύνολα","","",""];
  years.forEach(function(y,i){var L=colL(4+i),t=0;for(var r=1;r<=n;r++)t+=sum[r][4+i].v;trow.push(num(r2(t),"SUM("+L+"2:"+L+(n+1)+")"))});
  sum.push(trow);
  var ws0=XLSX.utils.aoa_to_sheet(sum);ws0["!cols"]=[{wch:10},{wch:48},{wch:36},{wch:14}].concat(years.map(function(){return {wch:16}}));
  XLSX.utils.book_append_sheet(wb,ws0,name("Σύνοψη"));
  function sheet(title,rows){
    var aoa=[["Α/Α","Λεπτομέρειες Δαπάνης (Περιγραφή)","Τρόπος Υπολογισμού","","",""].concat(yh)],mer=[{s:{r:0,c:2},e:{r:0,c:5}}];
    rows.forEach(function(r,i){aoa.push([i+1,r.desc,r.how.join(" | "),"","",""].concat(years.map(function(y){return num(r.by[y]||0)})));mer.push({s:{r:i+1,c:2},e:{r:i+1,c:5}})});
    var k=rows.length,tr=["Σύνολα","","","","",""];
    years.forEach(function(y,i){var L=colL(6+i);tr.push(num(bdTotals(rows,[y])[0],k?"SUM("+L+"2:"+L+(k+1)+")":null))});
    aoa.push(tr);mer.push({s:{r:k+1,c:0},e:{r:k+1,c:5}});
    var ws=XLSX.utils.aoa_to_sheet(aoa);ws["!merges"]=mer;
    ws["!cols"]=[{wch:8},{wch:44},{wch:30},{wch:14},{wch:14},{wch:14}].concat(years.map(function(){return {wch:16}}));
    XLSX.utils.book_append_sheet(wb,ws,name(title));
  }
  codes.forEach(function(c){var a=artFind(c,arts);sheet(a.code+" "+a.desc,B.byArt[c])});
  if(B.byArt[""])sheet("Χωρίς άρθρο",B.byArt[""]);
  if(!codes.length&&!B.byArt[""]){toast("Δεν υπάρχουν ποσά προϋπολογισμού για εξαγωγή");return}
  offer("budget-"+todayIso()+".xlsx",XLSX.write(wb,{bookType:"xlsx",type:"array"}));
}

/* =============== CONTRACTS (Συμβάσεις) =============== */
var REMIND_CT=[14,30,60,90,120,180];
var CT_BASE=[
 {k:"title",l:"ΣΥΜΒΑΣΗ",q:"Ποια είναι η σύμβαση;",req:1,ph:"π.χ. Συντήρηση πληροφοριακών συστημάτων"},
 {k:"tender",l:"ΑΡΙΘΜΟΣ ΔΙΑΓΩΝΙΣΜΟΥ",q:"Ποιος είναι ο αριθμός διαγωνισμού;",ph:"π.χ. 12/2026"},
 {k:"description",l:"ΠΕΡΙΓΡΑΦΗ",q:"Γράψε μια σύντομη περιγραφή της σύμβασης.",ta:1},
 {k:"contractorId",l:"ΑΝΑΔΟΧΟΣ",q:"Ποιος είναι ο ανάδοχος; Επίλεξέ τον από τη λίστα αναδόχων.",sel:1},
 {k:"repName",l:"ΟΝΟΜΑΤΕΠΩΝΥΜΟ ΑΝΤΙΠΡΟΣΩΠΟΥ ΑΝΑΔΟΧΟΥ (ΓΙΑ ΤΗ ΣΥΜΒΑΣΗ)",q:"Ποιος είναι ο αντιπρόσωπος του αναδόχου για αυτή τη σύμβαση; (προαιρετικό)"},
 {k:"repPhone",l:"ΤΗΛΕΦΩΝΟ ΑΝΤΙΠΡΟΣΩΠΟΥ",q:"Ποιο είναι το τηλέφωνο του αντιπροσώπου; (προαιρετικό)",phone:1,ph:"π.χ. 22 123456, 99 123456"},
 {k:"repEmail",l:"EMAIL ΑΝΤΙΠΡΟΣΩΠΟΥ",q:"Ποιο είναι το email του αντιπροσώπου; Για περισσότερα χρησιμοποίησε κόμμα (,) ή ερωτηματικό (;) (προαιρετικό).",email:1,hint:"Για περισσότερα email χρησιμοποίησε κόμμα (,) ή ερωτηματικό (;)",ph:"name@example.com"},
 {k:"coordinator",l:"ΣΥΝΤΟΝΙΣΤΗΣ ΣΥΜΒΑΣΗΣ",q:"Ποιος είναι ο συντονιστής της σύμβασης;"},
 {k:"months",l:"ΔΙΑΡΚΕΙΑ ΣΥΜΒΑΣΗΣ (ΜΗΝΕΣ)",q:"Ποια είναι η διάρκεια της σύμβασης σε μήνες;",num:1,req:1,ph:"π.χ. 62"},
 {k:"dateFrom",l:"ΗΜΕΡ. ΕΝΑΡΞΗΣ",q:"Πότε ξεκινά η σύμβαση;",date:1,req:1},
 {k:"dateTo",l:"ΗΜΕΡ. ΛΗΞΗΣ",q:"Πότε λήγει; Υπολογίζεται από τη διάρκεια, μπορείς να την αλλάξεις.",date:1,req:1},
 {k:"cost",l:"ΚΟΣΤΟΣ (€)",q:"Ποιο είναι το συνολικό κόστος (€);",num:1},
 {k:"emails",l:"EMAIL ΕΙΔΟΠΟΙΗΣΕΩΝ",q:"Σε ποια email να στέλνονται οι ειδοποιήσεις; Για περισσότερα από ένα χρησιμοποίησε κόμμα (,) ή ερωτηματικό (;) (προαιρετικό).",ta:1,email:1,hint:"Για περισσότερα email χρησιμοποίησε κόμμα (,) ή ερωτηματικό (;)",ph:"name@example.com, other@example.com"}
];
var TN_BASE=[
 {k:"title",l:"ΟΝΟΜΑ ΔΙΑΓΩΝΙΣΜΟΥ",q:"Ποιο είναι το όνομα του διαγωνισμού;",req:1,ph:"π.χ. Προμήθεια εξοπλισμού δικτύου"},
 {k:"tender",l:"ΑΡΙΘΜΟΣ ΔΙΑΓΩΝΙΣΜΟΥ",q:"Ποιος είναι ο αριθμός του διαγωνισμού;",ph:"π.χ. 12/2027"},
 {k:"description",l:"ΠΕΡΙΓΡΑΦΗ",q:"Γράψε μια σύντομη περιγραφή του διαγωνισμού.",ta:1},
 {k:"months",l:"ΔΙΑΡΚΕΙΑ (ΜΗΝΕΣ)",q:"Ποια είναι η διάρκεια σε μήνες;",num:1,req:1,ph:"π.χ. 36"},
 {k:"dateFrom",l:"ΕΚΤΙΜΩΜΕΝΗ ΗΜΕΡ. ΕΝΑΡΞΗΣ",q:"Ποια είναι η εκτιμώμενη ημερομηνία έναρξης;",date:1,req:1},
 {k:"dateTo",l:"ΕΚΤΙΜΩΜΕΝΗ ΗΜΕΡ. ΛΗΞΗΣ",q:"Ποια είναι η εκτιμώμενη ημερομηνία λήξης; Υπολογίζεται από τη διάρκεια, μπορείς να την αλλάξεις.",date:1,req:1},
 {k:"cost",l:"ΕΚΤΙΜΩΜΕΝΟ ΚΟΣΤΟΣ (€)",q:"Ποιο είναι το εκτιμώμενο συνολικό κόστος (€);",num:1},
 {k:"contractId",l:"ΣΧΕΤΙΖΟΜΕΝΗ ΣΥΜΒΑΣΗ",q:"Με ποια σύμβαση σχετίζεται ο διαγωνισμός;",ctl:1}
];
/* contract form: the contractor is chosen from the registered contractors and shown read-only */
function ctrSelOpts(d){
  var cur=d.contractorId||"",list=(S.contractors||[]).slice().sort(function(a,b){return String(a.name).localeCompare(String(b.name),"el",{sensitivity:"base"})});
  var h='<option value="">— Επιλογή αναδόχου —</option>'+list.map(function(c){return '<option value="'+esc(c.id)+'"'+(c.id===cur?' selected':'')+'>'+esc(c.name)+'</option>'}).join("");
  if(cur&&!coById(cur))h+='<option value="'+esc(cur)+'" selected>'+esc(d.contractor||cur)+'</option>';
  return h;
}
function ctrInfoHtml(d){
  var o=ctrOf(d);
  if(d.contractorId)return ctrKv(o)+'<span class="hint">Τα στοιχεία του αναδόχου είναι μόνο για ανάγνωση εδώ. Αλλάζουν μόνο από την καρτέλα «Ανάδοχοι».</span>';
  if(o.name||o.vat||o.addr||o.contact||o.phone||o.email)return '<span class="hint">Η σύμβαση έχει ανάδοχο ως ελεύθερο κείμενο (παλιά καταχώρηση). Επίλεξε ανάδοχο από τη λίστα για να τον αντικαταστήσεις ή δημιούργησέ τον από αυτά τα στοιχεία.</span>'+ctrKv(o)+'<button class="btn small" type="button" data-act="coaddlegacy">Δημιουργία αναδόχου από αυτά τα στοιχεία</button>';
  return '<span class="hint">'+((S.contractors||[]).length?'Δεν έχει επιλεγεί ανάδοχος. Αν δεν υπάρχει στη λίστα, πάτησε «+ Νέος ανάδοχος».':'Δεν υπάρχουν ακόμα ανάδοχοι. Πάτησε «+ Νέος ανάδοχος» για να προσθέσεις.')+'</span>';
}
function rcChk(id,on){return '<div class="sec"><label style="display:flex;gap:8px;align-items:center;font-weight:600;cursor:pointer"><input type="checkbox" id="'+id+'"'+(on?' checked':'')+'> <span>Συμπερίληψη στο Πλαίσιο Συμφιλίωσης</span></label><span class="hint">Αν επιλεγεί, εμφανίζεται στον σχετικό πίνακα της καρτέλας «Πλαίσιο Συμφιλίωσης».</span></div>'}
function ctField(f,d,step){
  if(f.sel)return '<label class="f">'+(step?'<span class="big-q">'+f.q+' <small>(προαιρετικό)</small></span>':f.l)+'<span class="ctrsel"><select id="c_contractorId">'+ctrSelOpts(d)+'</select><button type="button" class="btn small" data-act="coaddfromct">+ Νέος ανάδοχος</button></span><span id="cCtrInfo">'+ctrInfoHtml(d)+'</span></label>';
  if(step)return '<label class="f"><span class="big-q">'+f.q+(f.req?'':' <small>(προαιρετικό)</small>')+'</span>'+ctInput(f,d[f.k],"c_"+f.k)+'</label>';
  return '<label class="f">'+f.l+(f.req?' *':'')+(f.hint?'<small>'+esc(f.hint)+'</small>':'')+ctInput(f,d[f.k],"c_"+f.k)+'</label>';
}
function cwBase(){
  var tn=S.cw&&S.cw.kind==="tn",b=(tn?TN_BASE:CT_BASE).slice();
  if(ownOn()){
    /* the coordinator of a contract is the owner of the record and is chosen from the users; a tender gets a person responsible */
    if(tn)b.push(ownField("tenders"));
    else b=b.map(function(f){return f.k==="coordinator"?ownField("contracts"):f});
  }
  return b.concat(cfDescs(tn?"tenders":"contracts"));
}
function mc(v){return v===""||v==null?"—":money(v)}
function dayTextEl(d){if(d==null)return "";if(d<0){var n=-d;return "πριν από "+n+(n==1?" ημέρα":" ημέρες")}if(d==0)return "σήμερα";return "σε "+d+(d==1?" ημέρα":" ημέρες")}
function addMonths(s,k){var d=parseIso(s);if(!d)return "";var day=d.getDate();d=new Date(d.getFullYear(),d.getMonth()+k,1);var dim=new Date(d.getFullYear(),d.getMonth()+1,0).getDate();d.setDate(Math.min(day,dim));return iso(d)}
function ctEnd(from,months){return addDays(addMonths(from,Math.round(Number(months))),-1)}
/* Years = whole years in the duration (minimum 1). Extra months go to year 1. 62 months -> 5 years: 14+12+12+12+12 */
function buildYears(from,months,old){
  var m=Math.round(Number(months));
  if(!parseIso(from)||!(m>0))return [];
  var n=Math.max(1,Math.floor(m/12)),first=m<12?m:12+(m%12),out=[],s=from;
  for(var i=0;i<n;i++){
    var len=i===0?first:12,e=addDays(addMonths(s,len),-1),o=old&&old[i];
    out.push({from:s,to:e,cost:o&&o.cost!=null?o.cost:"",remind:o&&o.remind?+o.remind:defRemind()});
    s=addDays(e,1);
  }
  var fin=ctEnd(from,m);if(fin>=out[out.length-1].from)out[out.length-1].to=fin;
  return out;
}
/* Additional / optional services of a contract: each has a yearly amount (€, excl. VAT); only the total contract cost includes it (not the cost of each year) */
function exOk(e){var n=Number(e&&e.amount);return e&&e.amount!==""&&e.amount!=null&&isFinite(n)&&n>0}
function exClean(d){return (d.extras||[]).filter(exOk).map(function(e){return {id:e.id||uid(),desc:String(e.desc||"").trim(),amount:r2(Number(e.amount)),article:String(e.article||"")}})}
function exSum(c){return r2((c.extras||[]).reduce(function(a,e){return a+(exOk(e)?Number(e.amount):0)},0))}
function ctYearCost(c,i){var y=(c.years||[])[i]||{};return y.cost===""||y.cost==null?"":r2(Number(y.cost)||0)}
function ctTotal(c){return r2((Number(c.cost)||0)+exSum(c)*(c.years||[]).length)}
function exText(c){return (c.extras||[]).filter(exOk).map(function(e){return (e.desc||"—")+" ("+Number(e.amount).toFixed(2)+" €/έτος"+(e.article?" ["+artLabel(e.article)+"]":"")+")"}).join("; ")}
function ctSum(ys){return (ys||[]).reduce(function(a,y){var v=Number(y.cost);return a+(y.cost===""||y.cost==null||!isFinite(v)?0:v)},0)}
function ctInfo(c){
  var t=todayIso(),ys=c.years||[],from=c.dateFrom||(ys[0]&&ys[0].from)||"",to=c.dateTo||(ys.length?ys[ys.length-1].to:"");
  var de=daysLeft(to),i;
  if(de==null)return {k:"ok",t:"Χωρίς ημερομηνία",sub:"",d:null,yr:null};
  if(c.archived&&de<0)return {k:"mute",t:"Αρχειοθετήθηκε",sub:"Αρχειοθετήθηκε"+(c.archivedAt?" "+fmtDate(c.archivedAt):""),d:de,yr:null,archived:true};
  if(de<0)return {k:"bad",t:"Έληξε",sub:"Η σύμβαση έληξε "+dayTextEl(de),d:de,yr:null};
  if(from&&t<from){var ds=daysLeft(from);return {k:"ok",t:"Δεν ξεκίνησε",sub:"Ξεκινά "+dayTextEl(ds),d:ds,yr:null}}
  for(i=0;i<ys.length;i++){
    var d=daysLeft(ys[i].to);
    if(d!=null&&d>=0&&d<=(+ys[i].remind||30)){var last=i===ys.length-1;return {k:"warn",t:"Λήγει σύντομα",sub:(last?"Λήξη σύμβασης ":"Λήξη έτους "+(i+1)+" ")+dayTextEl(d),d:d,yr:i+1,last:last}}
  }
  var ci=-1;for(i=0;i<ys.length;i++){if(t>=ys[i].from&&t<=ys[i].to){ci=i;break}}
  return {k:"ok",t:"Σε ισχύ",sub:ci>=0?"Έτος "+(ci+1)+" από "+ys.length:"",d:de,yr:ci>=0?ci+1:null};
}
/* archived (expired) contracts are kept for reference only: no alerts, digest items or milestone notifications */
function ctExpired(c){var ys=c.years||[],to=c.dateTo||(ys.length?ys[ys.length-1].to:""),de=daysLeft(to);return de!=null&&de<0}
function attn(cat){return listOf(cat).filter(function(i){var s=cat==="ct"?ctInfo(i):status(i);return s.k!=="ok"&&!s.archived}).length}
function crossAlert(cat){
  var o=cat==="sw"?"ct":"sw",n=attn(o)+msAttn(o);if(!n)return "";
  return '<div class="alert"><span>'+(o==="ct"?'Συμβάσεις: '+n+' χρειάζονται προσοχή':'Λογισμικά: '+n+' need attention')+'</span><button type="button" data-act="gocat" data-cat="'+o+'">'+(o==="ct"?'Προβολή':'View')+'</button></div>';
}
function remOpts(v,list,suffix){
  var h=list.map(function(n){return '<option value="'+n+'"'+(+v===n?" selected":"")+'>'+n+suffix+'</option>'}).join("");
  if(list.indexOf(+v)<0&&+v)h+='<option value="'+(+v)+'" selected>'+(+v)+suffix+'</option>';
  return h;
}

/* ---------- list ---------- */
function ctFiltered(){
  var q=S.q.toLowerCase();
  return sortList("ct",S.contracts.filter(function(c){
    var k=ctInfo(c).k;
    if(S.filter==="expired"&&k!=="bad")return false;
    if(S.filter==="due"&&k!=="warn")return false;
    if(S.filter==="active"&&k!=="ok")return false;
    if(S.filter==="archived"&&!ctInfo(c).archived)return false;
    if(!q)return true;
    return [c.title,c.tender,c.description,ctrOf(c).name,ctrOf(c).vat,ctrOf(c).contact,ctrOf(c).phone,ctrOf(c).email,c.repName,c.repPhone,c.repEmail,c.coordinator].join(" ").toLowerCase().indexOf(q)>=0;
  }));
}
function renderCt(){
  var all=S.contracts,exp=0,due=0,act=0,spend=0,arch=0;
  all.forEach(function(c){var si=ctInfo(c),k=si.k;if(si.archived){arch++;return}if(k==="bad")exp++;else{if(k==="warn")due++;else act++;spend+=ctTotal(c)}});
  $("#stats").innerHTML=
    '<div class="stat"><b>'+all.length+'</b><span>Συμβάσεις</span></div>'+
    '<div class="stat bad"><b>'+exp+'</b><span>Έληξαν</span></div>'+
    '<div class="stat warn"><b>'+due+'</b><span>Λήγουν σύντομα</span></div>'+
    '<div class="stat"><b>'+act+'</b><span>Σε ισχύ</span></div>'+(arch?'<div class="stat"><b>'+arch+'</b><span>Αρχείο</span></div>':'')+
    '<div class="stat"><b class="num" style="font-family:var(--f-display)">'+money(spend).replace(/\.00$/,"")+'</b><span>Κόστος ενεργών</span></div>';
  var lines=[];
  all.forEach(function(c){var s=ctInfo(c);if(s.k!=="ok"&&!s.archived)lines.push({c:c,s:s})});
  lines.sort(function(a,b){return a.s.d-b.s.d});
  var al=lines.slice(0,4).map(function(x){
    return '<div class="alert'+(x.s.k==="bad"?' bad':'')+'"><span><b>'+esc(x.c.title)+'</b> · '+esc(x.s.sub)+'</span><button type="button" data-act="openid" data-cat="ct" data-id="'+esc(x.c.id)+'">Άνοιγμα</button></div>';
  }).join("");
  if(lines.length>4)al+='<div class="alert"><span>+'+(lines.length-4)+' ακόμη</span><button type="button" data-f="due">Προβολή</button></div>';
  $("#alerts").innerHTML=al+msAlertHtml("ct")+crossAlert("ct");
  var chips=[["all","Όλες"],["expired","Έληξαν"],["due","Λήγουν σύντομα"],["active","Σε ισχύ"],["archived","Αρχείο"],["trash","🗑 Κάδος"+(S.trash.ct.length?" ("+S.trash.ct.length+")":"")]];
  $("#chips").innerHTML=chips.map(function(c){return '<button type="button" class="chip" data-f="'+c[0]+'" aria-pressed="'+(S.filter===c[0])+'">'+c[1]+'</button>'}).join("")+'<button type="button" class="chip" data-act="cols">⚙ Στήλες</button>'+(window.RL_CFG?'':'<button type="button" class="chip" data-act="arts">Άρθρα προϋπολογισμού</button>');
  var rows=ctFiltered(),h="";
  if(!all.length){
    h='<div class="empty"><h2>Δεν υπάρχουν συμβάσεις ακόμα</h2><p>Πρόσθεσε την πρώτη σύμβαση πεδίο-πεδίο ή εισήγαγε πολλές μαζί από αρχείο Excel. Τα έτη και οι υπενθυμίσεις δημιουργούνται αυτόματα από τη διάρκεια.</p><div class="actions"><button class="btn primary" type="button" id="emAdd">+ Νέα σύμβαση</button><button class="btn" type="button" id="emImp">Εισαγωγή Excel</button><button class="btn" type="button" id="emSample">Φόρτωση 2 δειγμάτων</button></div></div>';
  }else if(!rows.length){
    h='<div class="empty"><h2>Κανένα αποτέλεσμα</h2><p>Δοκίμασε άλλη αναζήτηση ή φίλτρο.</p></div>';
  }else{
    h=listHtml("ct",rows);
  }
  $("#list").innerHTML=h;
}

/* Archive of expired contracts: the contract stays in the list for reference but sends no notifications */
function ctArchBtn(c){
  if(s_arch(c))return '<button class="btn" type="button" data-act="ctunarch" title="Η σύμβαση ξαναμπαίνει στις ειδοποιήσεις (αν έχει λήξει θα εμφανίζεται ως Έληξε)">Επαναφορά από το Αρχείο</button>';
  return '<button class="btn" type="button" data-act="ctarch"'+(ctExpired(c)?'':' disabled title="Η αρχειοθέτηση ενεργοποιείται μόνο όταν η σύμβαση έχει λήξει"')+'>Αρχειοθέτηση</button>';
}
function s_arch(c){return !!ctInfo(c).archived}
async function ctSetArchive(id,on){
  var c=getItem("ct",id);if(!c)return;
  if(on&&!ctExpired(c)){toast("Η αρχειοθέτηση επιτρέπεται μόνο όταν η σύμβαση έχει λήξει");return}
  var rec=strip(c);rec.archived=!!on;rec.archivedAt=on?todayIso():"";
  if(await save(id,rec,"ct")){toast(on?"Η σύμβαση αρχειοθετήθηκε. Δεν θα στέλνει πλέον ειδοποιήσεις.":"Η σύμβαση επανήλθε από το Αρχείο");showCtDetail(id)}
}
/* ---------- detail ---------- */
function showCtDetail(id){
  var c=getItem("ct",id);if(!c)return;S.open=id;S.openCat="ct";
  var s=ctInfo(c),ys=c.years||[],t=todayIso(),o=ctrOf(c);
  var files=(c.attachments||[]).map(function(a,i){
    return '<li><a href="#" data-blob="'+esc(a.id)+'">'+esc(a.name)+'</a><button type="button" class="btn small danger" data-delfile="'+i+'">Αφαίρεση</button></li>';
  }).join("");
  var yr=ys.map(function(y,i){
    var cur=t>=y.from&&t<=y.to,past=t>y.to;
    return '<tr class="'+(cur?"cur":"")+'"><td>Έτος '+(i+1)+'</td><td class="mono">'+fmtDate(y.from)+'</td><td class="mono">'+fmtDate(y.to)+'</td><td class="num">'+mc(ctYearCost(c,i))+'</td>'+
      '<td><select class="yrRem" data-i="'+i+'" aria-label="Υπενθύμιση έτους '+(i+1)+'">'+remOpts(y.remind,REMIND_CT," ημέρες πριν")+'</select></td>'+
      '<td>'+(cur?'<span class="pill ok">Τρέχον</span>':past?'<span class="hint">Ολοκληρώθηκε</span>':'')+'</td></tr>';
  }).join("");
  openPanel(
   '<div class="ph"><div><h2>'+esc(c.title)+'</h2><span class="pill '+s.k+'">'+s.t+'</span> <span class="hint">'+esc(s.sub)+'</span></div><button class="btn small" type="button" data-act="close">Κλείσιμο</button></div>'+
   '<dl class="kv wl">'+
   '<dt>ΑΡΙΘΜΟΣ ΔΙΑΓΩΝΙΣΜΟΥ</dt><dd>'+esc(c.tender||"—")+'</dd>'+
   '<dt>ΠΛΑΙΣΙΟ ΣΥΜΦΙΛΙΩΣΗΣ</dt><dd>'+(c.rcInclude?"Συμπεριλαμβάνεται":"Δεν συμπεριλαμβάνεται")+'</dd>'+
   '<dt>ΠΕΡΙΓΡΑΦΗ</dt><dd>'+esc(c.description||"—")+'</dd>'+
   '<dt>ΑΝΑΔΟΧΟΣ</dt><dd>'+esc(o.name||"—")+(o.linked?' <button class="btn small" type="button" data-act="gocontractor" data-id="'+esc(o.id)+'">Καρτέλα αναδόχου</button>':'')+'</dd>'+
   (o.vat?'<dt>ΑΦΜ ΑΝΑΔΟΧΟΥ</dt><dd>'+esc(o.vat)+'</dd>':'')+
   '<dt>ΔΙΕΥΘΥΝΣΗ ΑΝΑΔΟΧΟΥ</dt><dd>'+esc(o.addr||"—")+'</dd>'+
   '<dt>ΑΤΟΜΟ ΕΠΙΚΟΙΝΩΝΙΑΣ</dt><dd>'+esc(o.contact||"—")+'</dd>'+
   '<dt>ΤΗΛΕΦΩΝΟ ΑΝΑΔΟΧΟΥ</dt><dd>'+(o.phone?'<a href="tel:'+esc(String(o.phone).split(/[,;]/)[0].replace(/[^0-9+]/g,""))+'">'+esc(o.phone)+'</a>':"—")+'</dd>'+
   '<dt>EMAIL ΑΝΑΔΟΧΟΥ</dt><dd>'+esc(o.email||"—")+'</dd>'+
   '<dt>ΑΝΤΙΠΡΟΣΩΠΟΣ ΑΝΑΔΟΧΟΥ (ΣΥΜΒΑΣΗΣ)</dt><dd>'+esc(c.repName||"—")+'</dd>'+
   '<dt>ΤΗΛΕΦΩΝΟ ΑΝΤΙΠΡΟΣΩΠΟΥ</dt><dd>'+(c.repPhone?'<a href="tel:'+esc(String(c.repPhone).split(/[,;]/)[0].replace(/[^0-9+]/g,""))+'">'+esc(c.repPhone)+'</a>':"—")+'</dd>'+
   '<dt>EMAIL ΑΝΤΙΠΡΟΣΩΠΟΥ</dt><dd>'+esc(c.repEmail||"—")+'</dd>'+
   '<dt>ΣΥΝΤΟΝΙΣΤΗΣ ΣΥΜΒΑΣΗΣ</dt><dd>'+esc(c.coordinator||"—")+'</dd>'+
   '<dt>ΔΙΑΡΚΕΙΑ (ΜΗΝΕΣ)</dt><dd class="num">'+esc(c.months||"—")+'</dd>'+
   '<dt>ΗΜΕΡ. ΕΝΑΡΞΗΣ</dt><dd class="mono">'+fmtDate(c.dateFrom)+'</dd>'+
   '<dt>ΗΜΕΡ. ΛΗΞΗΣ</dt><dd class="mono">'+fmtDate(c.dateTo)+'</dd>'+
   '<dt>ΚΟΣΤΟΣ</dt><dd class="num">'+mc(ctTotal(c))+'</dd>'+
   '<dt>EMAIL ΕΙΔΟΠΟΙΗΣΕΩΝ</dt><dd>'+esc(c.emails||"—")+'</dd></dl>'+
   '<div class="sec"><h3>Έτη και υπενθυμίσεις</h3><div class="tbl"><table><thead><tr><th>Έτος</th><th>ΗΜΕΡ. ΕΝΑΡΞΗΣ</th><th>ΗΜΕΡ. ΛΗΞΗΣ</th><th>ΚΟΣΤΟΣ</th><th>Υπενθύμιση</th><th></th></tr></thead><tbody>'+yr+'</tbody></table></div>'+
   '<span class="hint">Η υπενθύμιση κάθε έτους εμφανίζεται στην κορυφή και στο παράθυρο ειδοποιήσεων από την επιλεγμένη ημερομηνία μέχρι τη λήξη του έτους.</span></div>'+
   '<div class="sec"><h3>Συνημμένα</h3>'+(files?'<ul class="files">'+files+'</ul>':'<span class="hint">Δεν υπάρχουν συνημμένα (συμβάσεις, τιμολόγια, αποδείξεις).</span>')+
   '<div><button class="btn" type="button" data-act="attach"'+(S.assets?'':' disabled')+'>+ Προσθήκη αρχείων</button> <span class="hint">'+(S.assets?'PDF, εικόνες, CSV, κείμενο, Word, Excel, PowerPoint, HTML, XML, email (eml/msg), άδειες (lic), συμπιεσμένα (zip/7z/rar) κ.ά. · μέγιστο μέγεθος αρχείου '+attMB()+' MB. Τα αρχεία HTML κατεβαίνουν, δεν ανοίγουν μέσα στην εφαρμογή.':'Η μεταφόρτωση δεν είναι διαθέσιμη εδώ.')+'</span></div></div>'+
   bpDetail(c,1)+exDetail(c)+cfDetail(c,"contracts")+amDetail(c)+tnRelated(c)+msSection("ct",c)+
   '<div class="sec"><div class="actions"><button class="btn" type="button" data-act="edit">Επεξεργασία</button><button class="btn" type="button" data-act="ctamend">Τροποποίηση σύμβασης</button>'+ctArchBtn(c)+'<button class="btn danger" type="button" data-act="ctdel">Διαγραφή</button></div><div id="delbox"></div></div>'
  ,"detail",true);
}

/* ---------- add / edit ---------- */
function ctInput(f,v,id){
  v=v==null?"":v;
  if(f.owner)return ownSelect(id,v,f.coll,!!(S.cw&&S.cw.id&&!S.cw.promoteFrom));
  if(f.ctl)return ctlSelect(id,v);
  if(f.cf)return cfInput(f,v,id);
  if(f.ta)return '<textarea id="'+id+'" placeholder="'+esc(f.ph||"")+'">'+esc(v)+'</textarea>';
  var t=f.date?"date":f.num?"number":"text";
  var ex=f.k==="months"?' step="1" min="1" inputmode="numeric"':f.num?' step="0.01" min="0" inputmode="decimal"':'';
  return '<input id="'+id+'" type="'+t+'"'+ex+' value="'+esc(v)+'" placeholder="'+esc(f.ph||"")+'" autocomplete="off">';
}
function ctStart(id){
  var c=id?getItem("ct",id):null;
  S.cw={id:id||null,mode:c?"full":"step",i:0,err:"",d:c?JSON.parse(JSON.stringify(c)):{months:"",dateFrom:todayIso(),years:[]}};
  ctDraw();
}
/* ---------- contract amendments (Τροποποίηση Σύμβασης, v3.16.0) ----------
   The amendment form is the full contract form plus a description; every changed / added field shows its previous value,
   and the history (what changed, from what to what, the cost before and after) is stored on the contract (append-only). */
var AM_EX="π.χ. ΤΕΑΑ, ΚΕΑΑ, Συμπληρωματικός Προϋπολογισμός";
function amSnap(r){return {title:r.title||"",tender:r.tender||"",months:r.months,dateFrom:r.dateFrom||"",dateTo:r.dateTo||"",cost:Number(r.cost)||0,years:(r.years||[]).map(function(y){return {from:y.from||"",to:y.to||"",cost:y.cost===""||y.cost==null?"":Number(y.cost)}}),budget:(r.budget||[]).map(function(p){return {year:+p.year||1,amount:Number(p.amount)||0,article:String(p.article||"")}}),extras:(r.extras||[]).map(function(e){return {desc:e.desc||"",amount:Number(e.amount)||0,article:String(e.article||"")}})}}
function amArt(code){var a=code?artFind(code,articles()):null;return a?a.code+(a.desc?" – "+a.desc:""):(code?String(code):"χωρίς άρθρο")}
/* the comparable fields of a contract record: [{k,l,v}] with v the text shown to the user */
function amFields(r){
  var out=[];
  cwBase().forEach(function(f){
    var v;
    if(f.sel)v=r.contractor||"";else if(f.ctl)v=ctlName(r.contractId);else if(f.cf)v=(r.custom||{})[f.id];else v=r[f.k];
    if(v==null||v==="")v="";
    else if(f.date)v=fmtDate(v);else if(f.k==="cost")v=money(v);
    out.push({k:f.k,l:f.l.replace(/\s*\(€\)$/,""),v:String(v).trim()||"—"});
  });
  (r.years||[]).forEach(function(y,i){out.push({k:"y"+i,l:"Έτος "+(i+1)+" της σύμβασης",v:fmtDate(y.from)+" – "+fmtDate(y.to)+" · κόστος "+(y.cost===""||y.cost==null?"—":money(y.cost))})});
  var bp=(r.budget||[]).filter(function(p){return p.amount!==""&&p.amount!=null&&isFinite(Number(p.amount))&&Number(p.amount)!==0});
  out.push({k:"bp",l:"Επιμέρους ποσά ανά άρθρο",v:bp.length?bp.map(function(p){return "έτος "+(+p.year||1)+" · "+amArt(p.article)+" · "+money(p.amount)}).join("  |  "):"—"});
  if(S.cw.kind==="tn")return out;
  out.push({k:"rcInclude",l:"Συμπερίληψη στο Πλαίσιο Συμφιλίωσης",v:r.rcInclude?"Ναι":"Όχι"});
  var ex=(r.extras||[]).filter(function(e){return e&&(e.desc||Number(e.amount))});
  out.push({k:"ex",l:"Επιπρόσθετες / Προαιρετικές Υπηρεσίες",v:ex.length?ex.map(function(e){return (e.desc||"—")+" · "+money(e.amount)+"/έτος · "+amArt(e.article)}).join("  |  "):"—"});
  return out;
}
function amDiff(a,b){
  var am={},bm={},ks=[];
  a.forEach(function(x){am[x.k]=x});b.forEach(function(x){bm[x.k]=x;ks.push(x.k)});a.forEach(function(x){if(ks.indexOf(x.k)<0)ks.push(x.k)});
  var out=[];
  ks.forEach(function(k){var o=am[k],n=bm[k],ov=o?o.v:"—",nv=n?n.v:"—";if(ov!==nv)out.push({k:k,label:(n||o).l,old:ov,new:nv})});
  return out;
}
function ctAmend(id){
  var c=id?getItem("ct",id):null;if(!c)return;
  var d0=JSON.parse(JSON.stringify(c));cfLoad(d0,"contracts");
  S.cw={id:id,mode:"full",i:0,err:"",d:JSON.parse(JSON.stringify(c)),am:{base:ctRecord(d0,"ct"),desc:"",date:todayIso()}};
  ctDraw();
}
function amBlock(){
  var a=S.cw.am;
  return '<div class="sec amhead"><h3>Στοιχεία τροποποίησης</h3><label class="f">ΠΕΡΙΓΡΑΦΗ ΤΡΟΠΟΠΟΙΗΣΗΣ *<small>'+AM_EX+'</small><input id="am_desc" type="text" maxlength="300" autocomplete="off" value="'+esc(a.desc)+'"></label>'+
   '<label class="f">ΗΜΕΡΟΜΗΝΙΑ ΤΡΟΠΟΠΟΙΗΣΗΣ<input id="am_date" type="date" value="'+esc(a.date)+'"></label>'+
   '<p class="hint">Επεξεργάσου τα πεδία '+(S.cw.kind==="tn"?"του διαγωνισμού":"της σύμβασης")+' κανονικά. Για κάθε πεδίο που αλλάζει ή προστίθεται εμφανίζεται η προηγούμενη τιμή του και, στο τέλος της φόρμας, συγκεντρωτική λίστα των αλλαγών. Η τροποποίηση καταγράφεται στο ιστορικό '+(S.cw.kind==="tn"?"του διαγωνισμού":"της σύμβασης")+' και δεν διαγράφεται.</p></div>';
}
function amSummaryHtml(){
  var w=S.cw,dd=Object.assign({},w.d);if((dd.years||[]).some(function(y){return y.cost!==""&&y.cost!=null}))dd.cost=r2(ctSum(dd.years));
  var ch=amDiff(amFields(w.am.base),amFields(ctRecord(dd,w.kind||"ct")));
  if(!ch.length)return '<h3>Αλλαγές σε σχέση με την τρέχουσα καταχώρηση</h3><p class="hint">Δεν έχει γίνει καμία αλλαγή ακόμα.</p>';
  return '<h3>Αλλαγές σε σχέση με την τρέχουσα καταχώρηση ('+ch.length+')</h3><div class="tbl"><table><thead><tr><th>Πεδίο</th><th>Προηγούμενη τιμή</th><th>Νέα τιμή</th></tr></thead><tbody>'+ch.map(function(x){return '<tr><td>'+esc(x.label)+'</td><td>'+esc(x.old)+'</td><td>'+esc(x.new)+'</td></tr>'}).join("")+'</tbody></table></div>';
}
/* previous-value notes under the changed fields + the summary; called on every input / change while the amendment form is open */
function amLive(){
  var w=S.cw;if(!w||!w.am||w.mode!=="full")return;
  ctCollect();
  var dd=Object.assign({},w.d);if((dd.years||[]).some(function(y){return y.cost!==""&&y.cost!=null}))dd.cost=r2(ctSum(dd.years));  /* same rule as on save */
  var rec=ctRecord(dd,w.kind||"ct"),nf=amFields(rec),of=amFields(w.am.base),om={},nm={};
  of.forEach(function(x){om[x.k]=x.v});nf.forEach(function(x){nm[x.k]=x.v});
  cwBase().concat([{k:"rcInclude"}]).forEach(function(f){
    var el=document.getElementById("c_"+f.k);if(!el)return;var lab=el.closest("label")||el.parentNode,n=lab.querySelector(".amprev");
    if(om[f.k]!==nm[f.k]){if(!n){n=document.createElement("span");n.className="amprev";lab.appendChild(n)}n.textContent="Προηγούμενη τιμή: "+(om[f.k]==="—"?"— (νέα καταχώρηση)":om[f.k])}
    else if(n)n.remove();
  });
  var s=document.getElementById("amSummary");if(s)s.innerHTML=amSummaryHtml();
}
function amDetail(c,kind){
  var l=c.amendments||[];if(!l.length)return "";
  return '<div class="sec"><h3>'+(kind==="tn"?"Τροποποιήσεις διαγωνισμού":"Τροποποιήσεις σύμβασης")+' ('+l.length+')</h3>'+l.slice().reverse().map(function(a){
    var d=r2((Number(a.costAfter)||0)-(Number(a.costBefore)||0));
    return '<div class="amh"><div><b>'+fmtDate(a.date)+'</b> · '+esc(a.description)+'</div>'+
     '<div class="hint">Κόστος: '+mc(a.costBefore)+' → '+mc(a.costAfter)+(d?' ('+(d>0?'+':'−')+money(Math.abs(d))+')':' (αμετάβλητο)')+'</div>'+
     (a.changes&&a.changes.length?'<ul class="amch">'+a.changes.map(function(x){return '<li><b>'+esc(x.label)+'</b>: <span class="amold">'+esc(x.old)+'</span> → '+esc(x.new)+'</li>'}).join("")+'</ul>':'')+'</div>';
  }).join("")+'</div>';
}
/* contract form: the additional / optional services block */
function exBlock(d){
  var rows=(d.extras||[]).map(function(e,i){
    return '<div class="bp ex">'+
      '<input class="exd" id="ex_desc_'+i+'" type="text" placeholder="Περιγραφή υπηρεσίας" value="'+esc(e.desc)+'" autocomplete="off">'+
      '<input id="ex_amt_'+i+'" type="number" step="0.01" min="0" inputmode="decimal" placeholder="Ετήσιο ποσό (€)" value="'+esc(e.amount)+'">'+
      '<select id="ex_art_'+i+'" aria-label="Άρθρο προϋπολογισμού">'+artOpts(e.article,1)+'</select>'+
      '<button type="button" class="btn small danger" data-act="exdel" data-i="'+i+'" title="Αφαίρεση">✕</button></div>';
  }).join("");
  return '<div class="sec"><h3>Επιπρόσθετες / Προαιρετικές Υπηρεσίες</h3><p class="hint">Για κάθε Επιπρόσθετη / Προαιρετική Υπηρεσία γράψε περιγραφή, το ποσό που αφορά ανά έτος της σύμβασης (χωρίς ΦΠΑ) και το σχετικό άρθρο του προϋπολογισμού που αφορά. Το ποσό προστίθεται μόνο στο συνολικό κόστος της σύμβασης και περνά στον Προϋπολογισμό στο άρθρο της, κατανεμημένο ανά μήνα σε όλα τα έτη της σύμβασης.</p><div class="bpb">'+rows+'<div><button type="button" class="btn small" data-act="exadd">+ Υπηρεσία</button></div></div>'+
    '<p class="hint">Ετήσιο σύνολο υπηρεσιών: <b id="cExSum">'+mc(exSum(d))+'</b> · Συνολικό κόστος σύμβασης με Επιπρόσθετες / Προαιρετικές Υπηρεσίες: <b id="cTotal">'+mc(ctTotal(d))+'</b></p></div>';
}
function exCollect(d){(d.extras||[]).forEach(function(e,i){var t=$("#ex_desc_"+i),a=$("#ex_amt_"+i),r=$("#ex_art_"+i);if(t)e.desc=t.value;if(a)e.amount=a.value;if(r)e.article=r.value})}
function exTotals(){
  var w=S.cw;if(!w||w.kind==="tn")return;var d=w.d;exCollect(d);
  var yc=(d.years||[]).some(function(y){return y.cost!==""&&y.cost!=null}),base=(yc||d.cost==null||String(d.cost).trim()==="")?ctSum(d.years):Number(d.cost);/* saving fills the cost from the sum of the years */
  var a=$("#cExSum"),t=$("#cTotal");if(a)a.textContent=mc(exSum(d));if(t)t.textContent=mc(r2((Number(base)||0)+exSum(d)*(d.years||[]).length));
}
function exErr(d){
  var l=d.extras||[];
  for(var i=0;i<l.length;i++){
    var e=l[i],blankA=e.amount===""||e.amount==null,blankD=!String(e.desc||"").trim();
    if(blankA&&blankD)continue;
    if(blankD)return "Υπηρεσία "+(i+1)+": συμπλήρωσε περιγραφή.";
    if(blankA||!isFinite(Number(e.amount))||Number(e.amount)<=0)return "Υπηρεσία "+(i+1)+": το ετήσιο ποσό πρέπει να είναι αριθμός μεγαλύτερος από 0.";
  }
  return "";
}
function exDetail(c){
  var l=(c.extras||[]).filter(exOk);if(!l.length)return "";
  var n=(c.years||[]).length;
  return '<div class="sec"><h3>Επιπρόσθετες / Προαιρετικές Υπηρεσίες</h3><ul class="files">'+l.map(function(e){
    return '<li><span>'+esc(e.desc||"—")+' <span class="hint">'+esc(e.article?artLabel(e.article):"(χωρίς άρθρο)")+'</span></span><span class="num">'+mc(e.amount)+' / έτος</span></li>';
  }).join("")+'</ul><span class="hint">Ετήσιο σύνολο υπηρεσιών '+mc(exSum(c))+' × '+n+' '+(n===1?'έτος':'έτη')+' = '+mc(r2(exSum(c)*n))+'. Το συνολικό ΚΟΣΤΟΣ της σύμβασης περιλαμβάνει τις υπηρεσίες· το κόστος κάθε έτους δεν τις περιλαμβάνει.</span></div>';
}
function ctCollect(){
  var d=S.cw.d;
  cwBase().forEach(function(f){var el=$("#c_"+f.k);if(el)d[f.k]=el.value});
  (d.years||[]).forEach(function(y,i){
    var a=$("#cy_from_"+i),b=$("#cy_to_"+i),c=$("#cy_cost_"+i),r=$("#cy_rem_"+i);
    if(a)y.from=a.value;if(b)y.to=b.value;if(c)y.cost=c.value;if(r)y.remind=+r.value;
  });
  bpCollect(d);
  (d.years||[]).forEach(function(y,i){if(bpHas(d,i+1))y.cost=bpSum(d.budget,i+1)});
  exCollect(d);
  var rcx=$("#c_rcInclude");if(rcx)d.rcInclude=rcx.checked;
  if(S.cw.am){var ad=$("#am_desc"),at=$("#am_date");if(ad)S.cw.am.desc=ad.value;if(at)S.cw.am.date=at.value}
}
function ctRegen(){var d=S.cw.d,g=buildYears(d.dateFrom,d.months,d.years);if(!g.length)return;d.years=g;d.dateTo=g[g.length-1].to}
function ctApplyEnd(){var d=S.cw.d,ys=d.years;if(ys&&ys.length&&parseIso(d.dateTo)&&d.dateTo>=ys[ys.length-1].from)ys[ys.length-1].to=d.dateTo}
function ctRefresh(skipTo){
  var el=$("#cYears");if(el)el.innerHTML=ctYearsTable();
  exTotals();
  var dt=$("#c_dateTo");if(dt&&!skipTo)dt.value=S.cw.d.dateTo||"";
}
function ctYearsTable(){
  var tn=S.cw.kind==="tn",ys=S.cw.d.years||[];
  if(!ys.length)return '<p class="hint">Συμπλήρωσε τη διάρκεια (μήνες) και την ημερομηνία έναρξης για να δημιουργηθούν τα έτη.</p>';
  return '<div class="tbl"><table><thead><tr><th>Έτος</th><th>ΗΜΕΡ. ΕΝΑΡΞΗΣ</th><th>ΗΜΕΡ. ΛΗΞΗΣ</th><th>ΚΟΣΤΟΣ (€)</th>'+(tn?'':'<th>Υπενθύμιση</th>')+'</tr></thead><tbody>'+
   ys.map(function(y,i){
     var hp=bpHas(S.cw.d,i+1);
     return '<tr><td>Έτος '+(i+1)+'</td><td><input id="cy_from_'+i+'" type="date" value="'+esc(y.from)+'"></td><td><input id="cy_to_'+i+'" type="date" value="'+esc(y.to)+'"></td>'+
       '<td><input id="cy_cost_'+i+'" type="number" step="0.01" min="0" inputmode="decimal" value="'+esc(hp?bpSum(S.cw.d.budget,i+1):y.cost)+'"'+(hp?' readonly title="Άθροισμα επιμέρους ποσών"':'')+'></td>'+
       (tn?'':'<td><select id="cy_rem_'+i+'">'+remOpts(y.remind,REMIND_CT," ημέρες πριν")+'</select></td>')+'</tr>'+
       '<tr class="bpr"><td></td><td colspan="'+(tn?3:4)+'"><span class="hint">Επιμέρους ποσά έτους '+(i+1)+(hp?'':' (προαιρετικό)')+'</span>'+bpBlock(S.cw.d,i+1,1,ys.length)+'</td></tr>';
   }).join("")+'</tbody></table></div><p class="hint">Άθροισμα κόστους ετών: <b id="cSum">'+mc(ctSum(ys))+'</b></p>';
}
function ctDraw(){
  var w=S.cw,d=w.d,tn=w.kind==="tn",B=cwBase(),h;
  if(ownOn()&&d.ownerId===undefined)d.ownerId=d._owner||(w.id?"":ownMe());cfLoad(d,tn?"tenders":"contracts");
  var ttl=w.promoteFrom?"Promote στις Συμβάσεις":tn?(w.am?"Τροποποίηση διαγωνισμού":w.id?"Επεξεργασία διαγωνισμού":"Νέος διαγωνισμός"):(w.am?"Τροποποίηση σύμβασης":w.id?"Επεξεργασία σύμβασης":"Νέα σύμβαση");
  var head='<div class="ph"><h2>'+ttl+'</h2><button class="btn small" type="button" data-act="close">Άκυρο</button></div>'+
    (w.promoteFrom?'<p class="hint">Τα πεδία μεταφέρθηκαν από τον διαγωνισμό «'+esc(w.promoteTitle||"")+'». Έλεγξε και διόρθωσέ τα (π.χ. συμπλήρωσε ανάδοχο και συντονιστή, υπενθυμίσεις, email) πριν την αποθήκευση. Τα συνημμένα του διαγωνισμού αντιγράφονται στη σύμβαση. Η συμπερίληψη του διαγωνισμού στον Προϋπολογισμό θα αφαιρεθεί, γιατί θα γίνεται πλέον μέσω της νέας σύμβασης.</p>':'');
  var saveL=w.promoteFrom?"Αποθήκευση σύμβασης και προώθηση":"Αποθήκευση";
  if(w.mode==="full"){
    h=head+(w.am?amBlock():'')+'<div style="display:grid;gap:12px">'+B.map(function(f){return ctField(f,d,false)}).join("")+'</div>'+
      '<div class="sec"><h3>'+(tn?"Έτη διαγωνισμού":"Έτη σύμβασης")+'</h3><p class="hint">Δημιουργούνται αυτόματα από τη διάρκεια. Οι επιπλέον μήνες πέρα από τα πλήρη έτη προστίθενται στο 1ο έτος.'+(tn?' Συμπλήρωσε για κάθε έτος τα επιμέρους ποσά με το σχετικό άρθρο προϋπολογισμού· περνούν στον Προϋπολογισμό όσο ο διαγωνισμός είναι ενεργός.':'')+'</p><div id="cYears">'+ctYearsTable()+'</div>'+
      '<div><button class="btn small" type="button" data-act="ctsum">Συμπλήρωση ΚΟΣΤΟΥΣ από το άθροισμα ετών</button></div></div>'+(tn?'':'<div id="cExtras">'+exBlock(d)+'</div>')+(tn?'':rcChk("c_rcInclude",d.rcInclude))+
      (w.am?'<div class="sec amsum" id="amSummary">'+amSummaryHtml()+'</div>':'')+'<div class="err" id="werr">'+esc(w.err)+'</div><div class="actions"><button class="btn primary" type="button" data-act="ctsave">'+(w.am?'Αποθήκευση τροποποίησης':saveL)+'</button>'+(w.id||w.promoteFrom?'':'<button class="btn" type="button" data-act="ctstep">Βήμα-βήμα</button>')+'</div>';
    openPanel(h,"wiz",true);return;
  }
  var total=B.length+1,i=w.i,last=i===total-1,body;
  if(i<B.length){var f=B[i];body=ctField(f,d,true)}
  else body='<div><span class="big-q">'+(tn?"Έτη και κόστη":"Έτη, κόστη και υπενθυμίσεις")+'</span><p class="hint">'+(tn?"Συμπλήρωσε το κόστος κάθε έτους ή τα επιμέρους ποσά του με το σχετικό άρθρο.":"Συμπλήρωσε το κόστος κάθε έτους και διάλεξε πότε θέλεις υπενθύμιση πριν τη λήξη του.")+'</p></div><div id="cYears">'+ctYearsTable()+'</div>'+(tn?'':'<div id="cExtras">'+exBlock(d)+'</div>')+(tn?'':rcChk("c_rcInclude",d.rcInclude));
  h=head+'<div class="steps" aria-hidden="true"><i style="width:'+Math.round((i+1)/total*100)+'%"></i></div><div class="hint">Βήμα '+(i+1)+' από '+total+'</div>'+body+
    '<div class="err" id="werr">'+esc(w.err)+'</div>'+
    '<div class="actions">'+(i>0?'<button class="btn" type="button" data-act="ctback">Πίσω</button>':'')+'<button class="btn primary" type="button" data-act="'+(last?'ctsave':'ctnext')+'">'+(last?saveL:'Επόμενο')+'</button></div>'+
    '<div><button class="btn small" type="button" data-act="ctfull">Πλήρης φόρμα</button></div>';
  openPanel(h,"wiz",last);
}
function ctValidateBase(keys){
  var d=S.cw.d;
  for(var i=0;i<keys.length;i++){
    var f=cwBase().filter(function(x){return x.k===keys[i]})[0];if(!f)continue;
    var v=d[f.k],blank=v==null||String(v).trim()==="";
    if(f.cf){var ce=cfErr(f,v);if(ce)return ce}
    if(f.req&&blank)return f.l+": υποχρεωτικό πεδίο.";
    if(f.k==="months"&&!blank){var m=Number(v);if(!isFinite(m)||m<1||Math.floor(m)!==m)return "Η διάρκεια πρέπει να είναι ακέραιος αριθμός μηνών, π.χ. 62."}
    if(f.date&&!blank&&!parseIso(v))return f.l+": μη έγκυρη ημερομηνία.";
    if(f.email&&!blank&&emailsErr(v,1))return f.l+": "+emailsErr(v,1);
    if(f.phone&&!blank&&!/^\+?[0-9][0-9 ()\-./,;]{4,}$/.test(String(v).trim()))return f.l+": μη έγκυρο τηλέφωνο (ψηφία, κενά, + ( ) - . ; ,).";
    if(S.cw.kind==="tn"&&f.k==="tender"&&!blank){var dp=tnDup(v,S.cw.id);if(dp)return "Ο αριθμός διαγωνισμού «"+String(v).trim()+"» υπάρχει ήδη στον διαγωνισμό «"+dp.title+"». Κάθε διαγωνισμός πρέπει να έχει διαφορετικό αριθμό."}
    if(S.cw.kind!=="tn"&&f.k==="tender"&&!blank){var cd=ctDup(v,S.cw.id),cs=S.cw.id?getItem("ct",S.cw.id):null;if(cd&&!(cs&&tnKey(cs.tender)===tnKey(v)))return ctDupMsg(v,cd)}
    if(f.k==="cost"&&!blank&&(!isFinite(Number(v))||Number(v)<0))return "Το κόστος πρέπει να είναι αριθμός, π.χ. 12000.50.";
  }
  if(keys.indexOf("dateTo")>=0&&d.dateFrom&&d.dateTo&&d.dateTo<d.dateFrom)return "Η ημερομηνία λήξης πρέπει να είναι μετά την ημερομηνία έναρξης.";
  return "";
}
function ctNext(){
  ctCollect();var w=S.cw,f=cwBase()[w.i];
  var e=ctValidateBase([f.k]);
  if(e){w.err=e;var x=$("#werr");if(x)x.textContent=e;return}
  if(f.k==="months"||f.k==="dateFrom")ctRegen();
  if(f.k==="dateTo")ctApplyEnd();
  w.err="";w.i++;ctDraw();
}
function ctRecord(d,kind){
  var tn=kind==="tn";
  var ys=(d.years||[]).map(function(y){var o={from:y.from,to:y.to,cost:(y.cost===""||y.cost==null)?"":Number(y.cost)};if(!tn)o.remind=+y.remind||30;return o});
  var blank=d.cost==null||String(d.cost).trim()==="";
  var base={title:String(d.title||"").trim(),tender:String(d.tender||"").trim(),description:String(d.description||"").trim(),months:Number(d.months),dateFrom:d.dateFrom,dateTo:d.dateTo,cost:blank?ctSum(ys):Number(d.cost),years:ys,budget:bpClean(d),attachments:d.attachments||[],createdAt:d.createdAt||Date.now(),sample:!!d.sample};
  if(ownOn()&&d.ownerId!==undefined&&Number(d.ownerId)>0)base._owner=Number(d.ownerId);
  if(tn){base.status=d.status||"active";base.statusAt=d.statusAt||"";base.promotedTo=d.promotedTo||"";base.contractId=String(d.contractId||"");base.autoCreated=!!d.autoCreated;base.autoAt=d.autoCreated?(d.autoAt||""):"";base.amendments=Array.isArray(d.amendments)?d.amendments:[];cfApply(base,d,"tenders");return base}
  base.rcInclude=!!d.rcInclude;base.extras=exClean(d);base.amendments=Array.isArray(d.amendments)?d.amendments:[];base.archived=!!d.archived;base.archivedAt=d.archived?(d.archivedAt||""):"";
  var cr=coById(d.contractorId);base.contractorId=String(d.contractorId||"");base.contractor=cr?cr.name:String(d.contractor||"").trim();["contractorVat","contractorAddress","contractorContact","contractorPhone","contractorEmail"].forEach(function(k){base[k]=base.contractorId?"":String(d[k]||"").trim()});["repName","repPhone","repEmail"].forEach(function(k){base[k]=String(d[k]||"").trim()});base.coordinator=String(d.coordinator||"").trim();base.emails=String(d.emails||"").trim();base.milestones=d.milestones||[];
  cfApply(base,d,"contracts");return base;
}
async function ctSave(){
  ctCollect();var w=S.cw,d=w.d;
  var e=ctValidateBase(cwBase().map(function(f){return f.k}));
  if(!e)e=bpErr(d,1);
  if(!e&&w.kind!=="tn")e=exErr(d);
  if(!e){
    if(!(d.years||[]).length)d.years=buildYears(d.dateFrom,d.months);
    for(var i=0;i<d.years.length&&!e;i++){
      var y=d.years[i],n="Έτος "+(i+1)+": ";
      if(!parseIso(y.from)||!parseIso(y.to))e=n+"συμπλήρωσε έγκυρες ημερομηνίες.";
      else if(y.to<y.from)e=n+"η λήξη είναι πριν την έναρξη.";
      else if(y.cost!==""&&y.cost!=null&&(!isFinite(Number(y.cost))||Number(y.cost)<0))e=n+"το κόστος πρέπει να είναι αριθμός.";
    }
  }
  if(e){w.err=e;var x=$("#werr");if(x)x.textContent=e;return}
  /* on every save the contract cost is filled from the sum of the years (same as the "Συμπλήρωση ΚΟΣΤΟΥΣ από το άθροισμα ετών" button) when at least one year has a cost */
  if((d.years||[]).some(function(y){return y.cost!==""&&y.cost!=null}))d.cost=r2(ctSum(d.years));
  var tn=w.kind==="tn",rec=ctRecord(d,w.kind),id=w.id||uid();
  if(ownOn()&&!ownWarn(tn?"tenders":"contracts",d.ownerId,(w.id&&getItem(tn?"tn":"ct",w.id)||{})._owner))return;
  if(w.am){
    var ad=String(w.am.desc||"").trim(),ach=amDiff(amFields(w.am.base),amFields(rec)),ae="";
    if(!ad)ae="Η περιγραφή της τροποποίησης είναι υποχρεωτική ("+AM_EX+").";
    else if(!parseIso(w.am.date))ae="Η ημερομηνία τροποποίησης δεν είναι έγκυρη.";
    else if(!ach.length)ae="Δεν έγινε καμία αλλαγή.";
    if(ae){w.err=ae;var ax=$("#werr");if(ax)ax.textContent=ae;return}
    rec.amendments=(w.am.base.amendments||[]).concat([{id:uid(),date:w.am.date,description:ad,at:Date.now(),changes:ach.map(function(x){return {label:x.label,old:x.old,new:x.new}}),costBefore:ctTotal(w.am.base),costAfter:ctTotal(rec),before:amSnap(w.am.base)}]);
  }
  if(w.promoteFrom){
    if(await tnPromoteDo(w.promoteFrom,id,rec)){closePanel();toast("Ο διαγωνισμός προωθήθηκε στις Συμβάσεις");S.cat="ct";S.filter="all";S.q="";$("#q").value="";try{localStorage.setItem("rl.cat","ct")}catch(e){}render();showCtDetail(id)}
    return;
  }
  if(await save(id,rec,tn?"tn":"ct")){closePanel();toast(w.id?"Αποθηκεύτηκε":"Προστέθηκε: "+rec.title);if(!w.id||w.am)(tn?showTnDetail:showCtDetail)(id)}
}
/* ---------- tenders (Διαγωνισμοί): same form as the contracts, without reminders ---------- */
function tnActive(t){return (t.status||"active")==="active"}
/* A tender number is compared without case and spaces ("12 / 2024" = "12/2024"); returns the other live tender that already uses it. */
function tnKey(s){return String(s==null?"":s).replace(/\s+/g,"").toUpperCase()}
function tnDup(num,exceptId){var k=tnKey(num);if(!k)return null;return (S.tenders||[]).filter(function(t){return t.id!==exceptId&&tnKey(t.tender)===k})[0]||null}
/* Same rule for contracts (v3.15.0): another live contract with the same tender number blocks a new contract; an existing one is only checked when its number was changed. */
function ctDup(num,exceptId){var k=tnKey(num);if(!k)return null;return (S.contracts||[]).filter(function(c){return c.id!==exceptId&&tnKey(c.tender)===k})[0]||null}
function ctDupMsg(num,dp){return "Υπάρχει ήδη Σύμβαση καταχωρημένη με τον ίδιο αριθμό διαγωνισμού «"+String(num).trim()+"»: «"+dp.title+"». Δεν μπορεί να καταχωρηθεί δεύτερη σύμβαση με τον ίδιο αριθμό."}
function tnInfo(t){
  var s=t.status||"active";
  if(s==="pending")return {k:"warn",t:"Σε αναμονή έγκρισης",sub:t.autoCreated?"Αυτόματη δημιουργία":""};
  if(s==="cancelled")return {k:"bad",t:"Ακυρώθηκε",sub:t.statusAt?fmtDate(t.statusAt):""};
  if(s==="promoted")return {k:"mute",t:"Προωθήθηκε σε Σύμβαση",sub:t.statusAt?fmtDate(t.statusAt):""};
  return {k:"ok",t:"Ενεργός",sub:""};
}
function tnStart(id){
  var t=id?getItem("tn",id):null;
  S.cw={id:id||null,kind:"tn",mode:t?"full":"step",i:0,err:"",d:t?JSON.parse(JSON.stringify(t)):{months:"",dateFrom:todayIso(),years:[],status:"active"}};
  ctDraw();
}
/* Promote: open the contract form pre-filled from the tender; nothing changes until the contract is saved. */
function tnPromoteStart(id){
  var t=getItem("tn",id);if(!t||!tnActive(t))return;
  var d=JSON.parse(JSON.stringify(t));
  d.years=(d.years||[]).map(function(y){return Object.assign({},y,{remind:30})});
  ["status","statusAt","promotedTo","amendments","contractId","autoCreated","autoAt"].forEach(function(k){delete d[k]});
  d.contractorId="";d.repName="";d.repPhone="";d.repEmail="";d.contractor="";d.contractorVat="";d.contractorAddress="";d.contractorContact="";d.contractorPhone="";d.contractorEmail="";d.coordinator="";d.emails="";d.milestones=[];d.createdAt=Date.now();d.sample=false;
  S.cw={id:null,kind:"ct",promoteFrom:id,promoteTitle:t.title,mode:"full",i:0,err:"",d:d};
  ctDraw();
}
async function tnPromoteDo(tid,cid,rec){
  var t=getItem("tn",tid);if(!t)return false;
  if(window.RL_PROMOTE){try{await window.RL_PROMOTE(tid,cid,rec)}catch(e){toast(e&&e.status===409?"Ο διαγωνισμός δεν είναι πλέον ενεργός ή η σύμβαση υπάρχει ήδη":"Η προώθηση απέτυχε");return false}return true}
  if(!(await save(cid,rec,"ct")))return false;
  var tr=strip(t);tr.status="promoted";tr.promotedTo=cid;tr.statusAt=todayIso();
  if(!(await save(tid,tr,"tn"))){
    if(S.db&&S.uid){try{await col("contracts").doc(cid).delete()}catch(e){}}else{S.contracts=S.contracts.filter(function(x){return x.id!==cid});render()}
    return false;
  }
  return true;
}
async function tnSetStatus(id,st){
  var t=getItem("tn",id);if(!t)return;
  var rec=strip(t);rec.status=st;rec.statusAt=st==="cancelled"?todayIso():"";rec.promotedTo="";
  if(await save(id,rec,"tn")){toast(t.status==="pending"?(st==="active"?"Ο διαγωνισμός εγκρίθηκε και είναι πλέον ενεργός":"Ο διαγωνισμός απορρίφθηκε και αποθηκεύτηκε για αναφορά"):st==="cancelled"?"Ο διαγωνισμός ακυρώθηκε και αποθηκεύτηκε για αναφορά. Αφαιρέθηκε από τον Προϋπολογισμό.":"Ο διαγωνισμός είναι πάλι ενεργός");showTnDetail(id)}
}
function tnFiltered(){
  var q=S.q.toLowerCase();
  return sortList("tn",S.tenders.filter(function(c){
    var s=c.status||"active";
    if(S.filter==="active"&&s!=="active")return false;
    if(S.filter==="cancelled"&&s!=="cancelled")return false;
    if(S.filter==="promoted"&&s!=="promoted")return false;
    if(S.filter==="pending"&&s!=="pending")return false;
    if(!q)return true;
    return [c.title,c.tender,c.description].join(" ").toLowerCase().indexOf(q)>=0;
  }));
}
function arRows(){
  var q=S.q.toLowerCase();
  return articles().filter(function(a){return !q||[a.code,a.desc,a.cat,a.catDesc].join(" ").toLowerCase().indexOf(q)>=0});
}
function renderAr(){
  var all=articles(),cats={},used=0,split=0;
  all.forEach(function(a){cats[a.cat]=1;if(artUsage(a.code))used++;if(a.split)split++});
  $("#stats").innerHTML='<div class="stat"><b>'+all.length+'</b><span>Άρθρα</span></div><div class="stat"><b>'+Object.keys(cats).length+'</b><span>Κατηγορίες</span></div><div class="stat"><b>'+used+'</b><span>Σε χρήση σε εγγραφές</span></div><div class="stat"><b>'+split+'</b><span>Με ανάλυση ανά έτος (ΝΑΙ)</span></div>';
  $("#alerts").innerHTML="";
  var edit="";
  if(!window.RL_CFG||window.RL_CFG.canArticles)edit='<button type="button" class="btn primary" data-act="arts">Επεξεργασία άρθρων</button>';
  $("#chips").innerHTML=edit;
  var rows=arRows(),h;
  if(!all.length)h='<div class="empty"><h2>Δεν υπάρχουν άρθρα</h2><p>Τα άρθρα προϋπολογισμού ορίζονται από τον διαχειριστή.</p></div>';
  else if(!rows.length)h='<div class="empty"><h2>Κανένα αποτέλεσμα</h2><p>Δοκίμασε άλλη αναζήτηση.</p></div>';
  else h='<div class="tbl"><table class="art arview"><thead><tr><th>Κωδικός</th><th>Περιγραφή άρθρου</th><th>Κατηγορία</th><th>Περιγραφή κατηγορίας</th><th>Ανάλυση ανά έτος</th><th class="num">Εγγραφές</th></tr></thead><tbody>'+
    rows.map(function(a){return '<tr><td class="mono"><b>'+esc(a.code)+'</b></td><td>'+esc(a.desc)+'</td><td>'+esc(a.cat)+'</td><td>'+esc(a.catDesc||"")+'</td><td>'+(a.split?'ΝΑΙ':'ΌΧΙ')+'</td><td class="num">'+artUsage(a.code)+'</td></tr>'}).join("")+'</tbody></table></div>';
  $("#list").innerHTML=h;
}
function renderTn(){
  var all=S.tenders,n={active:0,pending:0,cancelled:0,promoted:0},est=0;
  all.forEach(function(t){var s=t.status||"active";n[s]=(n[s]||0)+1;if(s==="active")est+=Number(t.cost)||0});
  $("#stats").innerHTML=
    '<div class="stat"><b>'+all.length+'</b><span>Διαγωνισμοί</span></div>'+
    '<div class="stat"><b>'+n.active+'</b><span>Ενεργοί</span></div>'+
    (n.pending?'<div class="stat warn"><b>'+n.pending+'</b><span>Σε αναμονή έγκρισης</span></div>':'')+
    '<div class="stat"><b>'+n.promoted+'</b><span>Προωθήθηκαν σε Σύμβαση</span></div>'+
    '<div class="stat bad"><b>'+n.cancelled+'</b><span>Ακυρώθηκαν</span></div>'+
    '<div class="stat"><b class="num" style="font-family:var(--f-display)">'+money(est).replace(/\.00$/,"")+'</b><span>Εκτιμώμενο κόστος ενεργών</span></div>';
  $("#alerts").innerHTML="";
  var chips=[["all","Όλοι"],["active","Ενεργοί"],["pending","Σε αναμονή έγκρισης"+(n.pending?" ("+n.pending+")":"")],["promoted","Προωθήθηκαν"],["cancelled","Ακυρώθηκαν"],["trash","🗑 Κάδος"+(S.trash.tn.length?" ("+S.trash.tn.length+")":"")]];
  $("#chips").innerHTML=chips.map(function(c){return '<button type="button" class="chip" data-f="'+c[0]+'" aria-pressed="'+(S.filter===c[0])+'">'+c[1]+'</button>'}).join("")+'<button type="button" class="chip" data-act="cols">⚙ Στήλες</button>'+(window.RL_CFG?'':'<button type="button" class="chip" data-act="arts">Άρθρα προϋπολογισμού</button>');
  var rows=tnFiltered(),h="";
  if(!all.length)h='<div class="empty"><h2>Δεν υπάρχουν διαγωνισμοί ακόμα</h2><p>Κατέγραψε τους νέους διαγωνισμούς που σκοπεύει να διενεργήσει ο Οργανισμός, με εκτιμώμενες ημερομηνίες, κόστος και επιμέρους ποσά ανά άρθρο προϋπολογισμού. Όταν ο διαγωνισμός προχωρήσει, προωθείται σε Σύμβαση.</p><div class="actions"><button class="btn primary" type="button" id="emAdd">+ Νέος διαγωνισμός</button></div></div>';
  else if(!rows.length)h='<div class="empty"><h2>Κανένα αποτέλεσμα</h2><p>Δοκίμασε άλλη αναζήτηση ή φίλτρο.</p></div>';
  else h=listHtml("tn",rows);
  $("#list").innerHTML=h;
}
function showTnDetail(id){
  var c=getItem("tn",id);if(!c)return;S.open=id;S.openCat="tn";
  var s=tnInfo(c),st=c.status||"active",ys=c.years||[],t=todayIso();
  var files=(c.attachments||[]).map(function(a,i){
    return '<li><a href="#" data-blob="'+esc(a.id)+'">'+esc(a.name)+'</a><button type="button" class="btn small danger" data-delfile="'+i+'">Αφαίρεση</button></li>';
  }).join("");
  var yr=ys.map(function(y,i){return '<tr><td>Έτος '+(i+1)+'</td><td class="mono">'+fmtDate(y.from)+'</td><td class="mono">'+fmtDate(y.to)+'</td><td class="num">'+mc(y.cost)+'</td></tr>'}).join("");
  var note="";
  if(st==="pending")note='<p class="hint">Ο διαγωνισμός περιμένει έγκριση (Pending Approval)'+(c.autoCreated?' και δημιουργήθηκε αυτόματα από τη σύμβαση':'')+'. Δεν περιλαμβάνεται στον Προϋπολογισμό ούτε στο Πλαίσιο Συμφιλίωσης μέχρι να εγκριθεί. Έλεγξε και διόρθωσε τα στοιχεία με «Επεξεργασία» και πάτησε «Έγκριση».</p>';
  else if(st==="active")note='<p class="hint">Ο διαγωνισμός είναι ενεργός: τα ποσά του περιλαμβάνονται στον Προϋπολογισμό.</p>';
  else if(st==="cancelled")note='<p class="hint">Ακυρώθηκε'+(c.statusAt?" στις "+fmtDate(c.statusAt):"")+' και διατηρείται για αναφορά. Δεν περιλαμβάνεται στον Προϋπολογισμό.</p>';
  else{var pc=c.promotedTo?getItem("ct",c.promotedTo):null;note='<p class="hint">Προωθήθηκε σε Σύμβαση'+(c.statusAt?" στις "+fmtDate(c.statusAt):"")+' και διατηρείται για αναφορά. Η συμπερίληψη στον Προϋπολογισμό γίνεται πλέον μέσω της σύμβασης. '+(pc?'<button class="btn small" type="button" data-act="gocontract" data-id="'+esc(pc.id)+'">Άνοιγμα σύμβασης «'+esc(pc.title)+'»</button>':'(Η σύμβαση δεν βρέθηκε· ίσως έχει διαγραφεί.)')+'</p>'}
  var act='';
  if(st==="pending")act='<button class="btn primary" type="button" data-act="tnapprove">Έγκριση</button><button class="btn" type="button" data-act="tnreject">Απόρριψη και αποθήκευση για αναφορά</button>';
  else if(st==="active")act='<button class="btn primary" type="button" data-act="tnpromote">Promote στις Συμβάσεις και αποθήκευση για αναφορά</button><button class="btn" type="button" data-act="tncancel">Ακύρωση και αποθήκευση για αναφορά</button><button class="btn" type="button" data-act="tnamend">Τροποποίηση Διαγωνισμού</button>';
  else if(st==="cancelled")act='<button class="btn" type="button" data-act="tnreopen">Επανενεργοποίηση</button>';
  openPanel(
   '<div class="ph"><div><h2>'+esc(c.title)+'</h2><span class="pill '+s.k+'">'+s.t+'</span> <span class="hint">'+esc(s.sub)+'</span></div><button class="btn small" type="button" data-act="close">Κλείσιμο</button></div>'+note+
   '<dl class="kv wl">'+
   ownRow(c,"tenders")+'<dt>ΑΡΙΘΜΟΣ ΔΙΑΓΩΝΙΣΜΟΥ</dt><dd>'+esc(c.tender||"—")+'</dd>'+tnLinkRow(c)+
   '<dt>ΠΕΡΙΓΡΑΦΗ</dt><dd>'+esc(c.description||"—")+'</dd>'+
   '<dt>ΔΙΑΡΚΕΙΑ (ΜΗΝΕΣ)</dt><dd class="num">'+esc(c.months||"—")+'</dd>'+
   '<dt>ΕΚΤΙΜΩΜΕΝΗ ΗΜΕΡ. ΕΝΑΡΞΗΣ</dt><dd class="mono">'+fmtDate(c.dateFrom)+'</dd>'+
   '<dt>ΕΚΤΙΜΩΜΕΝΗ ΗΜΕΡ. ΛΗΞΗΣ</dt><dd class="mono">'+fmtDate(c.dateTo)+'</dd>'+
   '<dt>ΕΚΤΙΜΩΜΕΝΟ ΚΟΣΤΟΣ</dt><dd class="num">'+mc(c.cost)+'</dd></dl>'+
   '<div class="sec"><h3>Έτη</h3><div class="tbl"><table><thead><tr><th>Έτος</th><th>ΗΜΕΡ. ΕΝΑΡΞΗΣ</th><th>ΗΜΕΡ. ΛΗΞΗΣ</th><th>ΚΟΣΤΟΣ</th></tr></thead><tbody>'+yr+'</tbody></table></div></div>'+
   '<div class="sec"><h3>Συνημμένα</h3>'+(files?'<ul class="files">'+files+'</ul>':'<span class="hint">Δεν υπάρχουν συνημμένα (προδιαγραφές, μελέτες, προσφορές).</span>')+
   '<div><button class="btn" type="button" data-act="attach"'+(S.assets?'':' disabled')+'>+ Προσθήκη αρχείων</button> <span class="hint">'+(S.assets?'PDF, εικόνες, CSV, κείμενο, Word, Excel, PowerPoint, HTML, XML, email (eml/msg), άδειες (lic), συμπιεσμένα (zip/7z/rar) κ.ά. · μέγιστο μέγεθος αρχείου '+attMB()+' MB. Τα αρχεία HTML κατεβαίνουν, δεν ανοίγουν μέσα στην εφαρμογή.':'Η μεταφόρτωση δεν είναι διαθέσιμη εδώ.')+'</span></div></div>'+
   bpDetail(c,1)+cfDetail(c,"tenders")+amDetail(c,"tn")+
   '<div class="sec"><div class="actions">'+act+'<button class="btn" type="button" data-act="edit">Επεξεργασία</button><button class="btn danger" type="button" data-act="tndel">Διαγραφή</button></div><div id="delbox"></div></div>'
  ,"detail",true);
}

/* =============== CONTRACTORS (Ανάδοχοι) =============== */
var CO_BASE=[
 {k:"name",l:"ΟΝΟΜΑ",req:1,ph:"π.χ. Παράδειγμα Α.Ε."},
 {k:"address",l:"ΔΙΕΥΘΥΝΣΗ (ΟΔΟΣ, ΑΡΙΘΜΟΣ)"},
 {k:"address2",l:"ΔΙΕΥΘΥΝΣΗ (ΣΥΝΕΧΕΙΑ)"},
 {k:"postal",l:"Τ.Κ."},
 {k:"city",l:"ΠΟΛΗ"},
 {k:"country",l:"ΧΩΡΑ"},
 {k:"contact",l:"ΑΤΟΜΟ ΕΠΙΚΟΙΝΩΝΙΑΣ"},
 {k:"phone",l:"ΤΗΛΕΦΩΝΟ",phone:1,ph:"π.χ. 22 123456, 99 123456"},
 {k:"email",l:"EMAIL",email:1,hint:"Για περισσότερα email χρησιμοποίησε κόμμα (,) ή ερωτηματικό (;)",ph:"name@example.com"}
];
function coAddr(c){return [c.address,c.address2,[c.postal,c.city].filter(Boolean).join(" "),c.country].filter(function(x){return x&&String(x).trim()}).join(", ")}
function coKey(s){return String(s==null?"":s).normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/\s+/g," ").trim().toUpperCase()}
function coById(id){return id?((S.contractors||[]).filter(function(x){return x.id===id})[0]||null):null}
/* The contractor of a contract: the registered contractor when linked, otherwise the older free-text fields of the contract. */
function ctrOf(c){
  var r=coById(c.contractorId);
  if(r)return {linked:true,id:r.id,name:r.name||"",vat:"",addr:coAddr(r),contact:r.contact||"",phone:r.phone||"",email:r.email||""};
  return {linked:false,id:c.contractorId||"",name:c.contractor||"",vat:c.contractorVat||"",addr:c.contractorAddress||"",contact:c.contractorContact||"",phone:c.contractorPhone||"",email:c.contractorEmail||""};
}
/* a contractor with the same name or VAT number (compared without case and extra spaces) */
function coDup(name,vat,exceptId){
  var nk=coKey(name);
  return (S.contractors||[]).filter(function(x){return x.id!==exceptId&&nk&&coKey(x.name)===nk})[0]||null;
}
/* active contract = in force, expiring soon or not started yet (not expired) */
function coActive(c){var t=ctInfo(c).t;return t==="Σε ισχύ"||t==="Λήγει σύντομα"||t==="Δεν ξεκίνησε"}
function coContracts(id){return S.contracts.filter(function(c){return c.contractorId===id})}
function coStats(id){
  var n=0,seen={},list=[];
  coContracts(id).forEach(function(c){if(!coActive(c))return;n++;var k=tnKey(c.tender);if(k&&!seen[k]){seen[k]=1;list.push(String(c.tender).trim())}});
  return {n:n,tenders:list};
}
function coFiltered(){
  var q=S.q.toLowerCase();
  return sortList("co",(S.contractors||[]).filter(function(c){
    var n=coStats(c.id).n;
    if(S.filter==="withact"&&!n)return false;
    if(S.filter==="noact"&&n)return false;
    if(!q)return true;
    return [c.name,coAddr(c),c.contact,c.phone,c.email].join(" ").toLowerCase().indexOf(q)>=0;
  }));
}
function coLegacy(){return S.contracts.filter(function(c){return !c.contractorId&&String(c.contractor||"").trim()})}
function renderCo(){
  var all=S.contractors||[],withAct=0,acts=0,tset={};
  all.forEach(function(c){var s=coStats(c.id);if(s.n)withAct++;acts+=s.n;s.tenders.forEach(function(t){tset[tnKey(t)]=1})});
  $("#stats").innerHTML=
    '<div class="stat"><b>'+all.length+'</b><span>Ανάδοχοι</span></div>'+
    '<div class="stat"><b>'+withAct+'</b><span>Με ενεργές συμβάσεις</span></div>'+
    '<div class="stat"><b>'+acts+'</b><span>Ενεργές συμβάσεις</span></div>'+
    '<div class="stat"><b>'+Object.keys(tset).length+'</b><span>Διαγωνισμοί ενεργών συμβάσεων</span></div>';
  var lg=coLegacy();
  $("#alerts").innerHTML=lg.length?'<div class="alert"><span><b>'+lg.length+'</b> '+(lg.length===1?'σύμβαση έχει':'συμβάσεις έχουν')+' ανάδοχο ως ελεύθερο κείμενο, χωρίς σύνδεση με τη λίστα αναδόχων.</span><button type="button" data-act="comigrate">Δημιουργία αναδόχων από τις συμβάσεις</button></div>':"";
  var chips=[["all","Όλοι"],["withact","Με ενεργές συμβάσεις"],["noact","Χωρίς ενεργές συμβάσεις"],["trash","🗑 Κάδος"+(S.trash.co.length?" ("+S.trash.co.length+")":"")]];
  $("#chips").innerHTML=chips.map(function(c){return '<button type="button" class="chip" data-f="'+c[0]+'" aria-pressed="'+(S.filter===c[0])+'">'+c[1]+'</button>'}).join("")+'<button type="button" class="chip" data-act="cols">⚙ Στήλες</button>';
  var rows=coFiltered(),h="";
  if(!all.length)h='<div class="empty"><h2>Δεν υπάρχουν ανάδοχοι ακόμα</h2><p>Κατέγραψε εδώ τους αναδόχους (όνομα, διεύθυνση, άτομο επικοινωνίας, email, τηλέφωνο). Στις Συμβάσεις ο ανάδοχος επιλέγεται από αυτή τη λίστα και τα στοιχεία του αλλάζουν μόνο από εδώ.</p><div class="actions"><button class="btn primary" type="button" id="emAdd">+ Νέος ανάδοχος</button></div></div>';
  else if(!rows.length)h='<div class="empty"><h2>Κανένα αποτέλεσμα</h2><p>Δοκίμασε άλλη αναζήτηση ή φίλτρο.</p></div>';
  else h=listHtml("co",rows);
  $("#list").innerHTML=h;
}
function ctrKv(o){
  var tel=o.phone?'<a href="tel:'+esc(String(o.phone).split(/[,;]/)[0].replace(/[^0-9+]/g,""))+'">'+esc(o.phone)+'</a>':"—";
  return '<dl class="kv wl ctrinfo"><dt>ΟΝΟΜΑ</dt><dd>'+esc(o.name||"—")+'</dd>'+(o.vat?'<dt>ΑΦΜ</dt><dd>'+esc(o.vat)+'</dd>':'')+'<dt>ΔΙΕΥΘΥΝΣΗ</dt><dd>'+esc(o.addr||"—")+'</dd><dt>ΑΤΟΜΟ ΕΠΙΚΟΙΝΩΝΙΑΣ</dt><dd>'+esc(o.contact||"—")+'</dd><dt>ΤΗΛΕΦΩΝΟ</dt><dd>'+tel+'</dd><dt>EMAIL</dt><dd>'+esc(o.email||"—")+'</dd></dl>';
}
function showCoDetail(id){
  var c=coById(id);if(!c)return;S.open=id;S.openCat="co";
  var st=coStats(id),cts=coContracts(id);
  var rows=cts.map(function(x){var s=ctInfo(x);return '<tr><td>'+esc(x.title)+'</td><td>'+esc(x.tender||"—")+'</td><td><span class="pill '+s.k+'">'+s.t+'</span></td><td class="mono">'+fmtDate(x.dateTo)+'</td><td><button class="btn small" type="button" data-act="gocontract" data-id="'+esc(x.id)+'">Άνοιγμα</button></td></tr>'}).join("");
  openPanel(
   '<div class="ph"><div><h2>'+esc(c.name)+'</h2><span class="hint">Ανάδοχος</span></div><button class="btn small" type="button" data-act="close">Κλείσιμο</button></div>'+
   '<dl class="kv wl">'+
   '<dt>ΔΙΕΥΘΥΝΣΗ</dt><dd>'+esc([c.address,c.address2].filter(Boolean).join(", ")||"—")+'</dd>'+
   '<dt>Τ.Κ. / ΠΟΛΗ</dt><dd>'+esc([c.postal,c.city].filter(Boolean).join(" ")||"—")+'</dd>'+
   '<dt>ΧΩΡΑ</dt><dd>'+esc(c.country||"—")+'</dd>'+
   '<dt>ΑΤΟΜΟ ΕΠΙΚΟΙΝΩΝΙΑΣ</dt><dd>'+esc(c.contact||"—")+'</dd>'+
   '<dt>ΤΗΛΕΦΩΝΟ</dt><dd>'+(c.phone?'<a href="tel:'+esc(String(c.phone).split(/[,;]/)[0].replace(/[^0-9+]/g,""))+'">'+esc(c.phone)+'</a>':"—")+'</dd>'+
   '<dt>EMAIL</dt><dd>'+esc(c.email||"—")+'</dd>'+
   '<dt>ΕΝΕΡΓΕΣ ΣΥΜΒΑΣΕΙΣ</dt><dd class="num">'+st.n+'</dd>'+
   '<dt>ΑΡ. ΔΙΑΓΩΝΙΣΜΟΥ ΕΝΕΡΓΩΝ ΣΥΜΒΑΣΕΩΝ</dt><dd>'+(st.tenders.length?esc(st.tenders.join(", ")):"—")+'</dd></dl>'+
   cfDetail(c,"contractors")+'<div class="sec"><h3>Συμβάσεις του αναδόχου</h3>'+(rows?'<div class="tbl"><table><thead><tr><th>ΣΥΜΒΑΣΗ</th><th>ΑΡ. ΔΙΑΓΩΝΙΣΜΟΥ</th><th>ΚΑΤΑΣΤΑΣΗ</th><th>ΛΗΞΗ</th><th></th></tr></thead><tbody>'+rows+'</tbody></table></div><span class="hint">Ενεργές είναι οι συμβάσεις που δεν έχουν λήξει.</span>':'<span class="hint">Καμία σύμβαση δεν χρησιμοποιεί ακόμα αυτόν τον ανάδοχο.</span>')+'</div>'+
   '<div class="sec"><div class="actions"><button class="btn" type="button" data-act="edit">Επεξεργασία</button><button class="btn danger" type="button" data-act="codel">Διαγραφή</button></div><div id="delbox"></div></div>'
  ,"detail",true);
}
function coStart(id,opt){
  var c=id?coById(id):null;opt=opt||{};
  S.co={id:id||null,err:"",fromContract:!!opt.fromContract,prevDirty:!!opt.prevDirty,d:c?JSON.parse(JSON.stringify(c)):Object.assign({},opt.prefill||{})};
  coDraw();S.dirty=false;
}
function coCollect(){var d=S.co.d;coF().forEach(function(f){var el=$("#co_"+f.k);if(el)d[f.k]=el.value})}
function coDraw(){
  var w=S.co,d=w.d;cfLoad(d,"contractors");
  openPanel('<div class="ph"><h2>'+(w.id?"Επεξεργασία αναδόχου":"Νέος ανάδοχος")+'</h2><button class="btn small" type="button" data-act="cocancel">Άκυρο</button></div>'+
   (w.fromContract?'<p class="hint">Μετά την αποθήκευση επιστρέφεις στη σύμβαση και ο ανάδοχος επιλέγεται αυτόματα. Τα στοιχεία της σύμβασης που έχεις ήδη συμπληρώσει διατηρούνται.</p>':'')+
   '<div style="display:grid;gap:12px">'+coF().map(function(f){return '<label class="f">'+f.l+(f.req?' *':'')+(f.hint?'<small>'+esc(f.hint)+'</small>':'')+ctInput(f,d[f.k],"co_"+f.k)+'</label>'}).join("")+'</div>'+
   '<div class="err" id="werr">'+esc(w.err)+'</div><div class="actions"><button class="btn primary" type="button" data-act="cosave">Αποθήκευση</button></div>',"wiz",true);
}
function coCancel(){
  var w=S.co;if(!w)return;
  if(S.dirty&&!window.confirm("Να κλείσει η φόρμα; Ό,τι έχεις συμπληρώσει και δεν έχει αποθηκευτεί θα χαθεί."))return;
  S.co=null;
  if(w.fromContract&&S.cw){S.dirty=w.prevDirty;ctDraw();return}
  closePanel();
}
async function coSave(){
  coCollect();var w=S.co,d=w.d,e="",name=String(d.name||"").trim();
  if(!name)e="ΟΝΟΜΑ: υποχρεωτικό πεδίο.";
  coF().forEach(function(f){var v=d[f.k];if(e||v==null||String(v).trim()==="")return;
    if(f.cf){var ce=cfErr(f,v);if(ce){e=ce;return}}
    if(f.email&&emailsErr(v,1))e=f.l+": "+emailsErr(v,1);
    if(f.phone&&!/^\+?[0-9][0-9 ()\-./,;]{4,}$/.test(String(v).trim()))e=f.l+": μη έγκυρο τηλέφωνο (ψηφία, κενά, + ( ) - . ; ,).";
  });
  if(!e){var dp=coDup(name,"",w.id);if(dp)e="Υπάρχει ήδη ανάδοχος με το όνομα «"+dp.name+"». Επίλεξέ τον από τη λίστα αντί να τον προσθέσεις ξανά."}
  if(e){w.err=e;var x=$("#werr");if(x)x.textContent=e;return}
  var rec={};CO_BASE.forEach(function(f){rec[f.k]=String(d[f.k]==null?"":d[f.k]).trim()});rec.createdAt=d.createdAt||Date.now();rec.sample=!!d.sample;cfApply(rec,d,"contractors");
  var id=w.id||uid();
  if(await save(id,rec,"co")){
    var back=w.fromContract&&S.cw;S.co=null;
    if(back){S.cw.d.contractorId=id;S.cw.d.contractor=rec.name;S.dirty=true;toast("Προστέθηκε ανάδοχος: "+rec.name);ctDraw();return}
    closePanel();toast(w.id?"Αποθηκεύτηκε":"Προστέθηκε: "+rec.name);showCoDetail(id);
  }
}
/* contracts whose contractor is still free text: register the contractors (same name = one contractor) and link the contracts */
async function coMigrate(){
  var legacy=coLegacy();if(!legacy.length){toast("Δεν υπάρχουν συμβάσεις με ανάδοχο ως ελεύθερο κείμενο");return}
  var groups={},order=[];
  legacy.forEach(function(c){var k=coKey(c.contractor);if(!groups[k]){groups[k]=[];order.push(k)}groups[k].push(c)});
  if(!window.confirm("Θα δημιουργηθούν ή θα συνδεθούν "+order.length+" ανάδοχοι για "+legacy.length+" συμβάσεις (ίδιο όνομα = ένας ανάδοχος). Τα στοιχεία (διεύθυνση, επικοινωνία) περνούν από τη σύμβαση στον ανάδοχο. Συνέχεια;"))return;
  var made=0,linked=0;
  for(var i=0;i<order.length;i++){
    var cs=groups[order[i]],ex=(S.contractors||[]).filter(function(x){return coKey(x.name)===order[i]})[0],id,name;
    if(ex){id=ex.id;name=ex.name}
    else{
      var src=cs.filter(function(c){return c.contractorVat||c.contractorAddress||c.contractorContact||c.contractorPhone||c.contractorEmail})[0]||cs[0];
      name=String(cs[0].contractor).trim();
      var rec={name:name,address:String(src.contractorAddress||"").trim(),address2:"",postal:"",city:"",region:"",country:"",contact:String(src.contractorContact||"").trim(),phone:String(src.contractorPhone||"").trim(),email:String(src.contractorEmail||"").trim(),createdAt:Date.now(),sample:false};
      id=uid();
      if(!(await save(id,rec,"co")))continue;
      made++;
      if(!coById(id)){S.contractors.push(Object.assign({id:id},rec))}
    }
    for(var j=0;j<cs.length;j++){
      var r=strip(cs[j]);r.contractorId=id;r.contractor=name;["contractorVat","contractorAddress","contractorContact","contractorPhone","contractorEmail"].forEach(function(k){r[k]=""});
      if(await save(cs[j].id,r,"ct"))linked++;
    }
  }
  toast("Δημιουργήθηκαν "+made+" ανάδοχοι και συνδέθηκαν "+linked+" συμβάσεις");render();
}
function coHead0(){return ["ΟΝΟΜΑ","ΔΙΕΥΘΥΝΣΗ","ΔΙΕΥΘΥΝΣΗ (ΣΥΝΕΧΕΙΑ)","Τ.Κ.","ΠΟΛΗ","ΧΩΡΑ","ΑΤΟΜΟ ΕΠΙΚΟΙΝΩΝΙΑΣ","EMAIL","ΤΗΛΕΦΩΝΟ","ΕΝΕΡΓΕΣ ΣΥΜΒΑΣΕΙΣ","ΑΡ. ΔΙΑΓΩΝΙΣΜΟΥ ΕΝΕΡΓΩΝ ΣΥΜΒΑΣΕΩΝ"]}
function coRowsOut0(){
  return (S.contractors||[]).slice().sort(function(a,b){return String(a.name).localeCompare(String(b.name),"el",{sensitivity:"base"})}).map(function(c){
    var s=coStats(c.id);return [c.name,c.address||"",c.address2||"",c.postal||"",c.city||"",c.country||"",c.contact||"",c.email||"",c.phone||"",s.n,s.tenders.join(", ")];
  });
}
function coExportXlsx(){if(needX())return;if(!(S.contractors||[]).length){toast("Δεν υπάρχουν ανάδοχοι για εξαγωγή");return}offer("contractors-"+todayIso()+".xlsx",ctWb(coHead(),coRowsOut(),"Ανάδοχοι"))}
function coExportCsv(){
  if(!(S.contractors||[]).length){toast("Δεν υπάρχουν ανάδοχοι για εξαγωγή");return}
  var q=function(v){v=String(v==null?"":v);return /[",\n;]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v};
  offer("contractors-"+todayIso()+".csv","﻿"+[coHead()].concat(coRowsOut()).map(function(r){return r.map(q).join(",")}).join("\r\n"));
}
function coShowExport(){
  openPanel('<div class="ph"><h2>Εξαγωγή αναδόχων</h2><button class="btn small" type="button" data-act="close">Κλείσιμο</button></div>'+
   '<div class="sec"><h3>Εξαγωγή όλων των αναδόχων</h3><p class="hint">Περιλαμβάνει όλα τα στοιχεία κάθε αναδόχου, τον αριθμό των ενεργών συμβάσεών του και τους αριθμούς διαγωνισμού (π.χ. ΟΑΠ/ΠΜΕ/01/21/01) των ενεργών συμβάσεών του.</p><div class="actions"><button class="btn primary" type="button" data-act="xlsx">Excel (.xlsx)</button><button class="btn" type="button" data-act="csv">CSV</button></div></div>',"export");
}

/* ---------- Excel import ---------- */
function nh(s){return String(s==null?"":s).normalize("NFD").replace(/[̀-ͯ]/g,"").toUpperCase().replace(/[\s.\-–()_:,;]/g,"")}
var CT_ALIAS={repName:["ΑΝΤΙΠΡΟΣΩΠΟΣΑΝΑΔΟΧΟΥΣΥΜΒΑΣΗΣ","ΑΝΤΙΠΡΟΣΩΠΟΣΑΝΑΔΟΧΟΥ","ΑΝΤΙΠΡΟΣΩΠΟΣ"],repPhone:["ΤΗΛΕΦΩΝΟΑΝΤΙΠΡΟΣΩΠΟΥ"],repEmail:["EMAILΑΝΤΙΠΡΟΣΩΠΟΥ"],title:["ΣΥΜΒΑΣΗ","CONTRACT"],tender:["ΑΡΙΘΜΟΣΔΙΑΓΩΝΙΣΜΟΥ","ΑΡΔΙΑΓΩΝΙΣΜΟΥ","TENDER"],description:["ΠΕΡΙΓΡΑΦΗ","DESCRIPTION"],contractor:["ΑΝΑΔΟΧΟΣ","CONTRACTOR"],contractorVat:["ΑΦΜΑΝΑΔΟΧΟΥ","ΑΦΜ"],contractorAddress:["ΔΙΕΥΘΥΝΣΗΑΝΑΔΟΧΟΥ"],contractorContact:["ΑΤΟΜΟΕΠΙΚΟΙΝΩΝΙΑΣΑΝΑΔΟΧΟΥ","ΑΤΟΜΟΕΠΙΚΟΙΝΩΝΙΑΣ"],contractorPhone:["ΤΗΛΕΦΩΝΟΑΝΑΔΟΧΟΥ","ΤΗΛΕΦΩΝΟ"],contractorEmail:["EMAILΑΝΑΔΟΧΟΥ"],
 coordinator:["ΣΥΝΤΟΝΙΣΤΗΣΣΥΜΒΑΣΗΣ","ΣΥΝΤΟΝΙΣΤΗΣ"],months:["ΔΙΑΡΚΕΙΑΣΥΜΒΑΣΗΣΜΗΝΕΣ","ΔΙΑΡΚΕΙΑΜΗΝΕΣ","ΔΙΑΡΚΕΙΑ","ΜΗΝΕΣ"],dateFrom:["ΗΜΕΡΕΝΑΡΞΗΣ","ΕΝΑΡΞΗ"],dateTo:["ΗΜΕΡΛΗΞΗΣ","ΛΗΞΗ"],cost:["ΚΟΣΤΟΣ","ΣΥΝΟΛΙΚΟΚΟΣΤΟΣ"],emails:["EMAILΕΙΔΟΠΟΙΗΣΕΩΝ","EMAILΕΙΔΟΠΟΙΗΣΗΣ","EMAILS","EMAIL","NOTIFICATIONEMAILS"]};
function numOf(v){
  if(v===""||v==null)return "";
  if(typeof v==="number")return v;
  var s=String(v).replace(/[€\s]/g,"");
  if(s.indexOf(",")>=0&&s.indexOf(".")>=0)s=s.replace(/\./g,"").replace(",",".");
  else if(s.indexOf(",")>=0)s=s.replace(",",".");
  return Number(s);
}
/* import: a row whose tender number is already used by a contract (or by an earlier row of the same file) is skipped with a message */
function parseCtSheet(buf){
  var rows=parseCtSheet0(buf),seen={};
  rows.forEach(function(r){var k=tnKey(r.rec.tender);if(!k)return;var dp=ctDup(r.rec.tender,"");if(dp)r.errs.push("υπάρχει ήδη Σύμβαση με τον ίδιο αριθμό διαγωνισμού («"+dp.title+"»)");else if(seen[k])r.errs.push("ο ίδιος αριθμός διαγωνισμού υπάρχει και σε προηγούμενη γραμμή του αρχείου");else if(!r.errs.length)seen[k]=1});
  return rows;
}
function parseCtSheet0(buf){
  var wb=XLSX.read(buf,{type:"array",cellDates:true}),ws=wb.Sheets[wb.SheetNames[0]];
  var rows=XLSX.utils.sheet_to_json(ws,{defval:"",raw:true});
  return rows.map(function(r,idx){
    var base={},yrs={};
    Object.keys(r).forEach(function(k){
      var h=nh(k),v=r[k],m=/^ΕΤΟΣ(\d+)(ΗΜΕΡΕΝΑΡΞΗΣ|ΗΜΕΡΛΗΞΗΣ|ΚΟΣΤΟΣ|ΥΠΕΝΘΥΜΙΣΗ.*)$/.exec(h);
      if(m){var n=+m[1],p=m[2];yrs[n]=yrs[n]||{};
        if(p==="ΗΜΕΡΕΝΑΡΞΗΣ")yrs[n].from=toIsoDate(v);else if(p==="ΗΜΕΡΛΗΞΗΣ")yrs[n].to=toIsoDate(v);else if(p==="ΚΟΣΤΟΣ")yrs[n].cost=v;else yrs[n].remind=v;
        return}
      Object.keys(CT_ALIAS).forEach(function(key){if(CT_ALIAS[key].indexOf(h)>=0&&v!==""&&base[key]===undefined)base[key]=v});
    });
    var from=toIsoDate(base.dateFrom),to=toIsoDate(base.dateTo),months=numOf(base.months);
    if((months===""||!(months>0))&&from&&to){var a=parseIso(from),b=parseIso(to);if(a&&b)months=Math.round(((b-a)/864e5+1)/30.4375)}
    if(!to&&from&&months>0)to=ctEnd(from,months);
    var g=buildYears(from,months);
    if(g.length&&to&&to>=g[g.length-1].from)g[g.length-1].to=to;
    Object.keys(yrs).map(Number).sort(function(x,y){return x-y}).forEach(function(n){
      var y=yrs[n],i=n-1;
      if(i>=g.length){if(!y.from||!y.to)return;g.push({from:y.from,to:y.to,cost:"",remind:defRemind()});i=g.length-1}
      if(y.from)g[i].from=y.from;if(y.to)g[i].to=y.to;
      if(y.cost!==undefined&&y.cost!=="")g[i].cost=numOf(y.cost);
      var rm=Number(y.remind);if(rm>0)g[i].remind=rm;
    });
    var cost=numOf(base.cost);
    var rec={title:String(base.title||"").trim(),tender:String(base.tender==null?"":base.tender).trim(),description:String(base.description||"").trim(),contractor:String(base.contractor||"").trim(),contractorVat:String(base.contractorVat||"").trim(),contractorAddress:String(base.contractorAddress||"").trim(),contractorContact:String(base.contractorContact||"").trim(),contractorPhone:String(base.contractorPhone||"").trim(),contractorEmail:String(base.contractorEmail||"").trim(),coordinator:String(base.coordinator||"").trim(),repName:String(base.repName||"").trim(),repPhone:String(base.repPhone||"").trim(),repEmail:String(base.repEmail||"").trim(),contractorId:"",
      months:months===""?0:months,dateFrom:from,dateTo:to,cost:cost===""?ctSum(g):cost,years:g,emails:String(base.emails||"").trim(),attachments:[],createdAt:Date.now(),sample:false};
    var cm=rec.contractor?(S.contractors||[]).filter(function(x){return coKey(x.name)===coKey(rec.contractor)})[0]:null;
    if(cm){rec.contractorId=cm.id;rec.contractor=cm.name;["contractorVat","contractorAddress","contractorContact","contractorPhone","contractorEmail"].forEach(function(k){rec[k]=""})}
    var errs=[];
    if(!rec.title)errs.push("λείπει η σύμβαση");
    if(emailsErr(rec.emails,1))errs.push(emailsErr(rec.emails,1));
    if(rec.contractorEmail&&emailsErr(rec.contractorEmail,1))errs.push("EMAIL ΑΝΑΔΟΧΟΥ: "+emailsErr(rec.contractorEmail,1));
    if(rec.repEmail&&emailsErr(rec.repEmail,1))errs.push("EMAIL ΑΝΤΙΠΡΟΣΩΠΟΥ: "+emailsErr(rec.repEmail,1));
    if(!from)errs.push("ΗΜΕΡ. ΕΝΑΡΞΗΣ λείπει/άκυρη");
    if(!(rec.months>0))errs.push("άκυρη διάρκεια");
    if(from&&to&&to<from)errs.push("λήξη πριν την έναρξη");
    if(!isFinite(rec.cost))errs.push("άκυρο κόστος");
    g.forEach(function(y,i){if(!isFinite(Number(y.cost)))errs.push("άκυρο κόστος έτους "+(i+1))});
    return {n:idx+2,rec:rec,errs:errs};
  });
}
function showCtImport(rows){
  S.imp=rows;S.impCat="ct";
  var good=rows.filter(function(r){return !r.errs.length}).length;
  var tr=rows.slice(0,200).map(function(r){
    var x=r.rec;
    return '<tr class="'+(r.errs.length?"badrow":"")+'"><td>'+r.n+'</td><td>'+esc(x.title)+'</td><td>'+esc(x.tender)+'</td><td>'+esc(x.contractor)+'</td><td>'+esc(x.months)+'</td><td>'+fmtDate(x.dateFrom)+'</td><td>'+fmtDate(x.dateTo)+'</td><td class="num">'+(isFinite(x.cost)?money(x.cost):"—")+'</td><td>'+x.years.length+'</td><td>'+(r.errs.length?esc(r.errs.join(", ")):"OK")+'</td></tr>';
  }).join("");
  openPanel('<div class="ph"><h2>Προεπισκόπηση εισαγωγής</h2><button class="btn small" type="button" data-act="close">Άκυρο</button></div>'+
   '<p class="hint">Βρέθηκαν '+rows.length+' γραμμές, '+good+' έτοιμες για εισαγωγή. Οι γραμμές με πρόβλημα παραλείπονται. Οι νέες συμβάσεις προστίθενται στις υπάρχουσες.</p>'+
   '<div class="tbl"><table><thead><tr><th>Γραμμή</th><th>ΣΥΜΒΑΣΗ</th><th>ΑΡ. ΔΙΑΓΩΝΙΣΜΟΥ</th><th>ΑΝΑΔΟΧΟΣ</th><th>ΜΗΝΕΣ</th><th>ΕΝΑΡΞΗ</th><th>ΛΗΞΗ</th><th>ΚΟΣΤΟΣ</th><th>ΕΤΗ</th><th>Έλεγχος</th></tr></thead><tbody>'+tr+'</tbody></table></div>'+
   '<div class="actions"><button class="btn primary" type="button" data-act="doimport"'+(good?'':' disabled')+'>Εισαγωγή '+good+' γραμμών</button></div>',"imp",true);
}

/* ---------- export ---------- */
function ctHead0(n){
  var h=["ΣΥΜΒΑΣΗ","ΑΡΙΘΜΟΣ ΔΙΑΓΩΝΙΣΜΟΥ","ΠΕΡΙΓΡΑΦΗ","ΑΝΑΔΟΧΟΣ","ΣΥΝΤΟΝΙΣΤΗΣ ΣΥΜΒΑΣΗΣ","ΔΙΑΡΚΕΙΑ ΣΥΜΒΑΣΗΣ (ΜΗΝΕΣ)","ΗΜΕΡ. ΕΝΑΡΞΗΣ","ΗΜΕΡ. ΛΗΞΗΣ","ΚΟΣΤΟΣ"];
  for(var i=1;i<=n;i++)h.push("ΕΤΟΣ "+i+" - ΗΜΕΡ.ΕΝΑΡΞΗΣ","ΕΤΟΣ "+i+" - ΗΜΕΡ.ΛΗΞΗΣ","ΕΤΟΣ "+i+" - ΚΟΣΤΟΣ","ΕΤΟΣ "+i+" - ΥΠΕΝΘΥΜΙΣΗ (ΗΜΕΡΕΣ ΠΡΙΝ)");
  h.push("ΣΥΝΗΜΜΕΝΑ","EMAIL ΕΙΔΟΠΟΙΗΣΕΩΝ","ΕΠΙΜΕΡΟΥΣ ΠΟΣΑ","MILESTONES","ΚΑΤΑΣΤΑΣΗ","ΑΦΜ ΑΝΑΔΟΧΟΥ","ΔΙΕΥΘΥΝΣΗ ΑΝΑΔΟΧΟΥ","ΑΤΟΜΟ ΕΠΙΚΟΙΝΩΝΙΑΣ ΑΝΑΔΟΧΟΥ","ΤΗΛΕΦΩΝΟ ΑΝΑΔΟΧΟΥ","EMAIL ΑΝΑΔΟΧΟΥ","ΑΝΤΙΠΡΟΣΩΠΟΣ ΑΝΑΔΟΧΟΥ (ΣΥΜΒΑΣΗΣ)","ΤΗΛΕΦΩΝΟ ΑΝΤΙΠΡΟΣΩΠΟΥ","EMAIL ΑΝΤΙΠΡΟΣΩΠΟΥ","ΕΠΙΠΡΟΣΘΕΤΕΣ/ΠΡΟΑΙΡΕΤΙΚΕΣ ΥΠΗΡΕΣΙΕΣ","ΕΤΗΣΙΟ ΠΟΣΟ ΥΠΗΡΕΣΙΩΝ");return h;
}
function ctMaxYears(){return S.contracts.reduce(function(a,c){return Math.max(a,(c.years||[]).length)},1)}
function ctRowsOut0(n){
  return S.contracts.slice().sort(function(a,b){return (a.dateTo||"").localeCompare(b.dateTo||"")}).map(function(c){
    var o=ctrOf(c),r=[c.title,c.tender,c.description,o.name,c.coordinator,c.months,c.dateFrom,c.dateTo,ctTotal(c)],ys=c.years||[];
    for(var i=0;i<n;i++){var y=ys[i]||{};r.push(y.from||"",y.to||"",i<ys.length?ctYearCost(c,i):"",y.remind||"")}
    r.push((c.attachments||[]).map(function(a){return a.name}).join("; "),c.emails||"",bpText(c),msText(c),ctInfo(c).t,o.vat,o.addr,o.contact,o.phone,o.email,c.repName||"",c.repPhone||"",c.repEmail||"",exText(c),exSum(c)||"");
    return r;
  });
}
function ctWb(head,rows,sheet){
  var ws=XLSX.utils.aoa_to_sheet([head].concat(rows));
  ws["!cols"]=head.map(function(h){return {wch:Math.max(14,Math.min(36,h.length+2))}});
  var wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,sheet||"Συμβάσεις");
  return XLSX.write(wb,{bookType:"xlsx",type:"array"});
}
function ctExportXlsx(){if(needX())return;if(!S.contracts.length){toast("Δεν υπάρχουν συμβάσεις για εξαγωγή");return}var n=ctMaxYears();offer("contracts-"+todayIso()+".xlsx",ctWb(ctHead(n),ctRowsOut(n)))}
function ctExportCsv(){
  if(!S.contracts.length){toast("Δεν υπάρχουν συμβάσεις για εξαγωγή");return}
  var n=ctMaxYears(),q=function(v){v=String(v==null?"":v);return /[",\n;]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v};
  offer("contracts-"+todayIso()+".csv","﻿"+[ctHead(n)].concat(ctRowsOut(n)).map(function(r){return r.map(q).join(",")}).join("\r\n"));
}
function tnMaxYears(){return S.tenders.reduce(function(a,c){return Math.max(a,(c.years||[]).length)},1)}
function tnHead0(n){
  var h=["ΟΝΟΜΑ ΔΙΑΓΩΝΙΣΜΟΥ","ΑΡΙΘΜΟΣ ΔΙΑΓΩΝΙΣΜΟΥ","ΠΕΡΙΓΡΑΦΗ","ΔΙΑΡΚΕΙΑ (ΜΗΝΕΣ)","ΕΚΤΙΜ. ΗΜΕΡ. ΕΝΑΡΞΗΣ","ΕΚΤΙΜ. ΗΜΕΡ. ΛΗΞΗΣ","ΕΚΤΙΜΩΜΕΝΟ ΚΟΣΤΟΣ"];
  for(var i=1;i<=n;i++)h.push("ΕΤΟΣ "+i+" - ΗΜΕΡ.ΕΝΑΡΞΗΣ","ΕΤΟΣ "+i+" - ΗΜΕΡ.ΛΗΞΗΣ","ΕΤΟΣ "+i+" - ΚΟΣΤΟΣ");
  h.push("ΣΥΝΗΜΜΕΝΑ","ΕΠΙΜΕΡΟΥΣ ΠΟΣΑ","ΚΑΤΑΣΤΑΣΗ");return h;
}
function tnRowsOut0(n){
  return S.tenders.slice().sort(function(a,b){return (a.dateFrom||"").localeCompare(b.dateFrom||"")}).map(function(c){
    var r=[c.title,c.tender,c.description,c.months,c.dateFrom,c.dateTo,c.cost],ys=c.years||[];
    for(var i=0;i<n;i++){var y=ys[i]||{};r.push(y.from||"",y.to||"",y.cost===undefined?"":y.cost)}
    r.push((c.attachments||[]).map(function(a){return a.name}).join("; "),bpText(c),tnInfo(c).t);
    return r;
  });
}
function tnExportXlsx(){if(needX())return;if(!S.tenders.length){toast("Δεν υπάρχουν διαγωνισμοί για εξαγωγή");return}var n=tnMaxYears();offer("tenders-"+todayIso()+".xlsx",ctWb(tnHead(n),tnRowsOut(n),"Διαγωνισμοί"))}
function tnExportCsv(){
  if(!S.tenders.length){toast("Δεν υπάρχουν διαγωνισμοί για εξαγωγή");return}
  var n=tnMaxYears(),q=function(v){v=String(v==null?"":v);return /[",\n;]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v};
  offer("tenders-"+todayIso()+".csv","\ufeff"+[tnHead(n)].concat(tnRowsOut(n)).map(function(r){return r.map(q).join(",")}).join("\r\n"));
}
function tnShowExport(){
  openPanel('<div class="ph"><h2>Εξαγωγή διαγωνισμών</h2><button class="btn small" type="button" data-act="close">Κλείσιμο</button></div>'+
   '<div class="sec"><h3>Εξαγωγή όλων των διαγωνισμών</h3><p class="hint">Περιλαμβάνει όλα τα πεδία, τα στοιχεία κάθε έτους, τα επιμέρους ποσά, τα ονόματα των συνημμένων και την κατάσταση (ενεργός, ακυρώθηκε, προωθήθηκε).</p><div class="actions"><button class="btn primary" type="button" data-act="xlsx">Excel (.xlsx)</button><button class="btn" type="button" data-act="csv">CSV</button></div></div>',"export");
}
function ctTemplate(){if(needX())return;
  var ex=["Παράδειγμα σύμβασης","12/2026","Περιγραφή","Εταιρεία Α","Όνομα Επώνυμο",24,"2026-01-01","2027-12-31",24000,"2026-01-01","2026-12-31",12000,30,"2027-01-01","2027-12-31",12000,30,"","a@example.com, b@example.com","","",""];
  offer("contracts-template.xlsx",ctWb(ctHead(2),[ex]));
}
function ctShowExport(){
  openPanel('<div class="ph"><h2>Εξαγωγή και εισαγωγή</h2><button class="btn small" type="button" data-act="close">Κλείσιμο</button></div>'+
   '<div class="sec"><h3>Εξαγωγή όλων των συμβάσεων</h3><p class="hint">Περιλαμβάνει όλα τα πεδία, τα στοιχεία κάθε έτους, την υπενθύμιση ανά έτος, τα ονόματα των συνημμένων και την κατάσταση. Οι στήλες ΕΤΟΣ προσαρμόζονται στη μεγαλύτερη σύμβαση.</p><div class="actions"><button class="btn primary" type="button" data-act="xlsx">Excel (.xlsx)</button><button class="btn" type="button" data-act="csv">CSV</button></div></div>'+
   '<div class="sec"><h3>Εισαγωγή από Excel</h3><p class="hint">Στήλες: ΣΥΜΒΑΣΗ, ΑΡΙΘΜΟΣ ΔΙΑΓΩΝΙΣΜΟΥ, ΠΕΡΙΓΡΑΦΗ, ΑΝΑΔΟΧΟΣ, ΣΥΝΤΟΝΙΣΤΗΣ ΣΥΜΒΑΣΗΣ, ΔΙΑΡΚΕΙΑ ΣΥΜΒΑΣΗΣ (ΜΗΝΕΣ), ΗΜΕΡ. ΕΝΑΡΞΗΣ, ΗΜΕΡ. ΛΗΞΗΣ, ΚΟΣΤΟΣ και προαιρετικά ΑΦΜ ΑΝΑΔΟΧΟΥ, ΔΙΕΥΘΥΝΣΗ ΑΝΑΔΟΧΟΥ, ΑΤΟΜΟ ΕΠΙΚΟΙΝΩΝΙΑΣ ΑΝΑΔΟΧΟΥ, ΤΗΛΕΦΩΝΟ ΑΝΑΔΟΧΟΥ, EMAIL ΑΝΑΔΟΧΟΥ, ΕΤΟΣ 1 - ΗΜΕΡ.ΕΝΑΡΞΗΣ, ΗΜΕΡ.ΛΗΞΗΣ, ΚΟΣΤΟΣ κ.ο.κ. Αν λείπουν οι στήλες των ετών, δημιουργούνται αυτόματα από τη διάρκεια. Ημερομηνίες: ηη/μμ/εεεε ή εεεε-μμ-ηη.</p><div class="actions"><button class="btn" type="button" data-act="tpl">Λήψη προτύπου</button><button class="btn" type="button" data-act="pick">Επιλογή αρχείου Excel…</button></div></div>',"export");
}

/* ---------- samples ---------- */
async function ctSample(){
  var t=todayIso();
  var a=addMonths(t,-20),b=addMonths(addDays(t,21),-24);
  var ya=buildYears(a,62),yb=buildYears(b,24);
  ya.forEach(function(y,i){y.cost=[18000,15000,15000,15000,15000][i]||0});
  yb.forEach(function(y){y.cost=9000});
  var mk=function(o,ys){var c=Object.assign({tender:"",description:"",coordinator:"",attachments:[],createdAt:Date.now(),sample:true,years:ys,dateTo:ys[ys.length-1].to,cost:ctSum(ys)},o);return c};
  await save(uid(),mk({title:"Συντήρηση πληροφοριακών συστημάτων",tender:"12/2024",description:"Υποστήριξη και συντήρηση εξοπλισμού",contractor:"Παράδειγμα Α.Ε.",coordinator:"Όνομα Επώνυμο",months:62,dateFrom:a},ya),"ct");
  await save(uid(),mk({title:"Υπηρεσίες φιλοξενίας δεδομένων",tender:"05/2025",description:"Φιλοξενία και αντίγραφα ασφαλείας",contractor:"Παράδειγμα Ε.Π.Ε.",coordinator:"Όνομα Επώνυμο",months:24,dateFrom:b},yb),"ct");
}

/* ---------- on-open reminder popup (both categories) ---------- */
/*GUIDE-START*/var GUIDE_HTML="<p class=\"hint\">Οδηγός χρήσης του PROCURE360 · ισχύει για την έκδοση 3.21.0. Πάτησε σε ένα θέμα για να πας κατευθείαν σε αυτό.<\/p>\n<div class=\"gtoc\">\n<button type=\"button\" class=\"chip\" data-act=\"gsec\" data-id=\"intro\">Επισκόπηση<\/button>\n<button type=\"button\" class=\"chip\" data-act=\"gsec\" data-id=\"start\">Πρώτα βήματα<\/button>\n<button type=\"button\" class=\"chip\" data-act=\"gsec\" data-id=\"sw\">Λογισμικά<\/button>\n<button type=\"button\" class=\"chip\" data-act=\"gsec\" data-id=\"ct\">Συμβάσεις<\/button>\n<button type=\"button\" class=\"chip\" data-act=\"gsec\" data-id=\"tn\">Διαγωνισμοί<\/button>\n<button type=\"button\" class=\"chip\" data-act=\"gsec\" data-id=\"pv\">Γενικές Πρόνοιες<\/button>\n<button type=\"button\" class=\"chip\" data-act=\"gsec\" data-id=\"own\">Ιδιοκτήτες εγγραφών<\/button>\n<button type=\"button\" class=\"chip\" data-act=\"gsec\" data-id=\"bd\">Προϋπολογισμός<\/button>\n<button type=\"button\" class=\"chip\" data-act=\"gsec\" data-id=\"rc\">Πλαίσιο Συμφιλίωσης<\/button>\n<button type=\"button\" class=\"chip\" data-act=\"gsec\" data-id=\"ar\">Άρθρα<\/button>\n<button type=\"button\" class=\"chip\" data-act=\"gsec\" data-id=\"co\">Ανάδοχοι<\/button>\n<button type=\"button\" class=\"chip\" data-act=\"gsec\" data-id=\"ms\">Milestones<\/button>\n<button type=\"button\" class=\"chip\" data-act=\"gsec\" data-id=\"att\">Συνημμένα<\/button>\n<button type=\"button\" class=\"chip\" data-act=\"gsec\" data-id=\"trash\">Κάδος και αναίρεση<\/button>\n<button type=\"button\" class=\"chip\" data-act=\"gsec\" data-id=\"rem\">Υπενθυμίσεις<\/button>\n<button type=\"button\" class=\"chip\" data-act=\"gsec\" data-id=\"xl\">Excel<\/button>\n<button type=\"button\" class=\"chip\" data-act=\"gsec\" data-id=\"cfg\">Ρυθμίσεις εφαρμογής<\/button>\n<button type=\"button\" class=\"chip\" data-act=\"gsec\" data-id=\"set\">Ρυθμίσεις και δικαιώματα<\/button>\n<button type=\"button\" class=\"chip\" data-act=\"gsec\" data-id=\"data\">Δεδομένα και αντίγραφα<\/button>\n<button type=\"button\" class=\"chip\" data-act=\"gsec\" data-id=\"sec\">Ασφάλεια και ίχνη ελέγχου<\/button>\n<button type=\"button\" class=\"chip\" data-act=\"gsec\" data-id=\"faq\">Συχνές ερωτήσεις<\/button>\n<button type=\"button\" class=\"chip\" data-act=\"gsec\" data-id=\"new\">Τι νέο υπάρχει<\/button>\n<\/div>\n\n<h3 id=\"g-intro\">Επισκόπηση<\/h3>\n<p>Το PROCURE360 συνδέει σε ένα σημείο τις αγορές λογισμικού, τις συμβάσεις, τους μελλοντικούς διαγωνισμούς και τον προγραμματισμό του προϋπολογισμού. Έχει πέντε καρτέλες:<\/p>\n<ul>\n<li><b>Λογισμικά:<\/b> συνδρομές λογισμικού με ημερομηνία λήξης και ανανέωση.<\/li>\n<li><b>Συμβάσεις:<\/b> συμβάσεις πολλών ετών, με κόστος και υπενθύμιση ανά έτος και milestones.<\/li>\n<li><b>Ανάδοχοι:<\/b> η λίστα των αναδόχων, από την οποία επιλέγονται στις Συμβάσεις.<\/li>\n<li><b>Διαγωνισμοί:<\/b> νέοι διαγωνισμοί που προτίθεται να διενεργήσει ο Οργανισμός, με εκτιμώμενα ποσά.<\/li>\n<li><b>Προϋπολογισμός:<\/b> πίνακες ανά άρθρο, που συμπληρώνονται αυτόματα από τα ποσά των τριών προηγούμενων καρτελών.<\/li>\n<li><b>Άρθρα:<\/b> η λίστα των άρθρων προϋπολογισμού του Οργανισμού.<\/li>\n<\/ul>\n<p>Οι εγγραφές των τριών πρώτων καρτελών κρατούν ποσά <b>χωρίς ΦΠΑ<\/b>. Ο Προϋπολογισμός προσθέτει ΦΠΑ (προεπιλογή 19%, αλλάζει από τις Ρυθμίσεις).<\/p>\n\n<h3 id=\"g-start\">Πρώτα βήματα<\/h3>\n<ul>\n<li>Διάλεξε καρτέλα και πάτησε το πράσινο κουμπί πάνω δεξιά («+ Add software», «+ Νέα σύμβαση», «+ Νέος διαγωνισμός»).<\/li>\n<li>Η φόρμα ανοίγει <b>βήμα-βήμα<\/b> (μία ερώτηση κάθε φορά). Με το «Πλήρης φόρμα» βλέπεις όλα τα πεδία μαζί.<\/li>\n<li>Οι φόρμες (Λογισμικά, Συμβάσεις, Διαγωνισμοί) ανοίγουν σε <b>πλήρη οθόνη<\/b> και <b>δεν κλείνουν κατά λάθος<\/b>: ούτε με κλικ έξω από τη φόρμα ούτε με το Backspace. Το Esc και το «Άκυρο» ρωτούν πρώτα αν θέλεις να χάσεις ό,τι έχεις γράψει. Αν δοκιμάσεις να φύγεις από τη σελίδα με μισοσυμπληρωμένη φόρμα, ο browser ζητά επιβεβαίωση.<\/li>\n<li>Η αναζήτηση πάνω από τη λίστα φιλτράρει με ό,τι πληκτρολογείς. Τα κουμπιά φίλτρου (chips) περιορίζουν ανά κατάσταση. Πεδίο αναζήτησης υπάρχει <b>σε κάθε σελίδα<\/b>: στις λίστες ψάχνει στις εγγραφές, στον <b>Προϋπολογισμό<\/b> στα άρθρα και τις γραμμές δαπανών (τα «Σύνολα» κάθε πίνακα αφορούν τις γραμμές που εμφανίζονται), στις <b>Ρυθμίσεις<\/b> εμφανίζει μόνο τις ενότητες που περιέχουν το κείμενο, και ο <b>Οδηγός<\/b> έχει δικό του πεδίο αναζήτησης στην κορυφή.<\/li>\n<li>Με το «⚙ Στήλες» διαλέγεις ποιες στήλες φαίνονται, με ποια σειρά και ποια ταξινομεί τη λίστα.<\/li>\n<li>Στο WordPress βλέπεις μόνο τις καρτέλες και τις ενέργειες που σου επιτρέπει ο ρόλος σου. Αν λείπει κάποιο κουμπί, ζήτα το δικαίωμα από τον διαχειριστή.<\/li>\n<\/ul>\n\n<h3 id=\"g-sw\">Λογισμικά<\/h3>\n<p><b>Πεδία:<\/b> Software Name, Description, Vendor, Website, Username, Date From, Date To, Cost excl. VAT (€), Notification emails (για περισσότερα από ένα χρησιμοποίησε κόμμα (,) ή ερωτηματικό (;)) και η υπενθύμιση (7, 14, 30, 60 ή 90 ημέρες πριν τη λήξη). Δεν αποθηκεύονται κωδικοί πρόσβασης.<\/p>\n<p><b>Κατάσταση:<\/b> «Active», «Due soon» (μέσα στις ημέρες υπενθύμισης) ή «Expired».<\/p>\n<p><b>Ανανέωση:<\/b> άνοιξε την εγγραφή και πάτησε «Renew…». Δίνεις νέες ημερομηνίες και κόστος, και η προηγούμενη περίοδος κρατιέται στο ιστορικό ανανεώσεων.<\/p>\n<p><b>Σημείωμα ανανέωσης:<\/b> άνοιξε την εγγραφή και πάτησε «Ετοιμασία Σημειώματος». Ανοίγει φόρμα με προσυμπληρωμένα στοιχεία: ημερομηνία σήμερα, όνομα και περιγραφή του λογισμικού, <b>επόμενη περίοδος ανανέωσης<\/b> (από την επομένη της λήξης, για ένα έτος), κόστος και άρθρο προϋπολογισμού (το πρώτο άρθρο των επιμέρους ποσών, αν υπάρχει). Διόρθωσέ τα αν χρειάζεται και πάτα «Δημιουργία Σημειώματος (.docx)»: κατεβαίνει αρχείο Word με τη μορφοποίηση του προτύπου. Η δαπάνη δεν καταχωρείται εκεί· η ανανέωση γίνεται από το «Renew…». Οι υπογραφές και ο «ΑΡ. ΦΑΚ» μένουν όπως είναι στο πρότυπο.<\/p>\n<p><b>Επιμέρους ποσά και άρθρα:<\/b> στην ενότητα «Cost breakdown» της εγγραφής πατάς «+ Add partial amount» και χωρίζεις το κόστος σε μέρη, διαλέγοντας για κάθε μέρος το άρθρο προϋπολογισμού. Έτσι περνά στον Προϋπολογισμό. Αν δεν δώσεις επιμέρους ποσά, μπαίνει ολόκληρο το κόστος χωρίς άρθρο.<\/p>\n\n<h3 id=\"g-ct\">Συμβάσεις<\/h3>\n<p><b>Πεδία:<\/b> Σύμβαση, Αριθμός διαγωνισμού, Περιγραφή, Ανάδοχος, Συντονιστής, Διάρκεια (μήνες), Ημερομηνία έναρξης και λήξης, Κόστος, Emails ειδοποιήσεων (για περισσότερα από ένα χρησιμοποίησε κόμμα (,) ή ερωτηματικό (;)).<\/p>\n<p><b>Μοναδικός αριθμός διαγωνισμού:<\/b> δεν επιτρέπεται δεύτερη σύμβαση με τον ίδιο αριθμό διαγωνισμού. Αν προσπαθήσεις να καταχωρήσεις (ή να εισαγάγεις από Excel, ή να προωθήσεις από Διαγωνισμό, ή να επαναφέρεις από τον κάδο) σύμβαση με αριθμό που ήδη έχει άλλη σύμβαση, εμφανίζεται μήνυμα «Υπάρχει ήδη Σύμβαση καταχωρημένη με τον ίδιο αριθμό διαγωνισμού» με τον τίτλο της υπάρχουσας και η σύμβαση δεν αποθηκεύεται. Η σύγκριση αγνοεί κενά και κεφαλαία/πεζά (το «12 / 2024» είναι ίδιο με το «12/2024»). Παλιές συμβάσεις που ήδη έχουν κοινό αριθμό μπορούν να επεξεργαστούν κανονικά όσο δεν αλλάζεις τον αριθμό τους. Συμβάσεις χωρίς αριθμό διαγωνισμού δεν ελέγχονται.<\/p>\n<p><b>Ανάδοχος:<\/b> επιλέγεται από λίστα (drop-down) με τους αναδόχους της καρτέλας «Ανάδοχοι». Αν ο ανάδοχος δεν υπάρχει, πατάς «+ Νέος ανάδοχος»: ανοίγει η φόρμα αναδόχου και μετά την αποθήκευση επιστρέφεις στη σύμβαση με τον ανάδοχο επιλεγμένο, χωρίς να χαθεί ό,τι είχες συμπληρώσει. Τα στοιχεία του αναδόχου (διεύθυνση, άτομο επικοινωνίας, τηλέφωνο, email) εμφανίζονται στη σύμβαση <b>μόνο για ανάγνωση<\/b>· αλλάζουν αποκλειστικά από την καρτέλα «Ανάδοχοι».<\/p>\n<p><b>Αντιπρόσωπος αναδόχου για τη σύμβαση:<\/b> επειδή το άτομο επικοινωνίας μπορεί να διαφέρει ανά σύμβαση, κάθε σύμβαση έχει δικά της πεδία Ονοματεπώνυμο, Τηλέφωνο και Email αντιπροσώπου (προαιρετικά· τηλέφωνο και email μπορεί να είναι περισσότερα, χωρισμένα με κόμμα ή ερωτηματικό). Περιλαμβάνονται στην αναζήτηση και στο Excel (εξαγωγή και εισαγωγή). Το email είναι πληροφοριακό: οι ειδοποιήσεις στέλνονται μόνο στα «Email ειδοποιήσεων».<\/p>\n<p><b>Παλιές συμβάσεις:<\/b> συμβάσεις που είχαν ανάδοχο ως ελεύθερο κείμενο διατηρούν τα παλιά τους στοιχεία μέχρι να επιλέξεις ανάδοχο. Στην καρτέλα «Ανάδοχοι» το κουμπί «Δημιουργία αναδόχων από τις συμβάσεις» τους δημιουργεί αυτόματα (ίδιο όνομα = ένας ανάδοχος) και συνδέει τις συμβάσεις.<\/p>\n<p><b>Έτη σύμβασης:<\/b> δημιουργούνται αυτόματα από τη διάρκεια και την ημερομηνία έναρξης. Οι επιπλέον μήνες πέρα από τα πλήρη έτη προστίθενται στο 1ο έτος. Για κάθε έτος βάζεις κόστος και υπενθύμιση (14, 30, 60, 90, 120 ή 180 ημέρες πριν τη λήξη του έτους).<\/p>\n<p><b>Επιμέρους ποσά:<\/b> κάτω από κάθε έτος πατάς «+ Επιμέρους ποσό», επιλέγεις άρθρο προϋπολογισμού και γράφεις το ποσό. Το κόστος του έτους γίνεται το άθροισμα των ποσών. Δες την ενότητα «Προϋπολογισμός» για το πώς περνούν.<\/p>\n<p><b>Αρχειοθέτηση (Archive):<\/b> όταν μια σύμβαση έχει λήξει, στο κάτω μέρος των λεπτομερειών της εμφανίζεται το κουμπί «Αρχειοθέτηση» (είναι ανενεργό όσο η σύμβαση δεν έχει λήξει). Η αρχειοθετημένη σύμβαση <b>δεν στέλνει πλέον καμία ειδοποίηση<\/b> (ούτε email λήξης, ούτε υπενθυμίσεις ετών/milestones, ούτε εμφανίζεται στο «Needs your attention» και στις ειδοποιήσεις της κορυφής) και δεν μετράει στους μετρητές «Έληξαν». Παραμένει στις Συμβάσεις για αναφορά: τη βρίσκεις στο φίλτρο «Αρχείο» και στο «Όλες», με κατάσταση «Αρχειοθετήθηκε». Με το κουμπί «Επαναφορά από το Αρχείο» γυρίζει στην κανονική της κατάσταση. Αν παρατείνεις τη λήξη μιας αρχειοθετημένης σύμβασης, γίνεται αυτόματα ξανά ενεργή.<\/p>\n<p><b>Κόστος σύμβασης:<\/b> σε κάθε αποθήκευση το ΚΟΣΤΟΣ της σύμβασης συμπληρώνεται αυτόματα από το άθροισμα των ετών (όπως το κουμπί «Συμπλήρωση ΚΟΣΤΟΥΣ από το άθροισμα ετών», που μπορείς να πατήσεις και χειροκίνητα). Αν κανένα έτος δεν έχει κόστος, το ΚΟΣΤΟΣ μένει όπως το έγραψες.<\/p>\n<p><b>Επιπρόσθετες / Προαιρετικές Υπηρεσίες:<\/b> στη φόρμα της σύμβασης, κάτω από τα έτη, πατάς «+ Υπηρεσία» για κάθε επιπρόσθετη ή προαιρετική υπηρεσία που περιλαμβάνεται στη σύμβαση (όσες χρειάζονται). Για κάθε μία γράφεις περιγραφή, το <b>ποσό που αφορά ένα έτος της σύμβασης<\/b> (χωρίς ΦΠΑ) και το άρθρο προϋπολογισμού. Το ποσό <b>προστίθεται μόνο στο συνολικό κόστος<\/b> της σύμβασης (π.χ. 2 έτη × 1.500 € υπηρεσίες = +3.000 €), όχι στο κόστος κάθε έτους· η φόρμα δείχνει ζωντανά το ετήσιο σύνολο των υπηρεσιών και το συνολικό κόστος με τις υπηρεσίες. Τα ποσά των ετών δεν αλλάζουν.<\/p>\n<p><b>Στον Προϋπολογισμό:<\/b> κάθε υπηρεσία περνά στο άρθρο που όρισες, για κάθε έτος της σύμβασης, <b>κατανεμημένη ανά μήνα<\/b> στα ημερολογιακά έτη που καλύπτει (π.χ. 1.200 € για 01/07–30/06: 6 μήνες στο πρώτο ημερολογιακό έτος και 6 στο επόμενο), πάντα με ΦΠΑ όπως τα υπόλοιπα ποσά, ανεξάρτητα από την επιλογή «Ανάλυση ανά έτος» του άρθρου. Στη στήλη «Πώς προκύπτει» φαίνεται η περιγραφή της υπηρεσίας και το έτος της σύμβασης. Ένα άρθρο που χρησιμοποιείται σε υπηρεσίες μετράει στη χρήση του και δεν διαγράφεται εύκολα. Οι υπηρεσίες εμφανίζονται και στο Excel των συμβάσεων (δύο νέες στήλες· το ΚΟΣΤΟΣ περιλαμβάνει τις υπηρεσίες) και δεν περιλαμβάνονται στην εισαγωγή από Excel.<\/p>\n<p><b>Τροποποίηση σύμβασης:<\/b> στις λεπτομέρειες μιας σύμβασης πατάς «Τροποποίηση σύμβασης». Ανοίγει η φόρμα της σύμβασης και, για κάθε πεδίο που αλλάζεις ή προσθέτεις, εμφανίζεται από κάτω η <b>προηγούμενη τιμή<\/b> («Προηγούμενη τιμή: …», ή «— (νέα καταχώρηση)» αν το πεδίο ήταν κενό). Πάνω στη φόρμα συμπληρώνεις υποχρεωτικά την <b>περιγραφή της τροποποίησης<\/b> (π.χ. ΤΕΑΑ, ΚΕΑΑ, Συμπληρωματικός Προϋπολογισμός) και την ημερομηνία της. Μια περίληψη «Πεδίο / Προηγούμενη τιμή / Νέα τιμή» ενημερώνεται όσο πληκτρολογείς· αν δεν έχει αλλάξει τίποτα, η αποθήκευση δεν γίνεται. Στις λεπτομέρειες εμφανίζεται το ιστορικό «Τροποποιήσεις σύμβασης»: κάθε τροποποίηση με ημερομηνία, περιγραφή, κόστος πριν και μετά, και τις αλλαγές «από → σε». Το ιστορικό μόνο προστίθεται· δεν σβήνεται ούτε αλλάζει (στο WordPress το διασφαλίζει ο server και κάθε τροποποίηση γράφεται στο αρχείο δραστηριότητας). Η κανονική «Επεξεργασία» δεν δημιουργεί τροποποίηση.<\/p>\n<p><b>Κατάσταση:<\/b> «Δεν ξεκίνησε», «Ενεργή», «Λήγει σύντομα» (λήξη έτους ή σύμβασης μέσα στις ημέρες υπενθύμισης) ή «Έληξε».<\/p>\n\n<h3 id=\"g-tn\">Διαγωνισμοί<\/h3>\n<p>Εδώ καταγράφονται οι νέοι διαγωνισμοί που σκοπεύει να διενεργήσει ο Οργανισμός.<\/p>\n<p><b>Πεδία:<\/b> Όνομα διαγωνισμού, Αριθμός διαγωνισμού (<b>μοναδικός<\/b>: δεν μπορούν δύο διαγωνισμοί να έχουν τον ίδιο αριθμό, ανεξάρτητα από κεφαλαία/πεζά και κενά, π.χ. «12 / 2027» = «12/2027»· αριθμός διαγωνισμού που βρίσκεται μόνο στον Κάδο μπορεί να ξαναχρησιμοποιηθεί, αλλά τότε η επαναφορά του από τον Κάδο απορρίπτεται όσο ο αριθμός χρησιμοποιείται), Περιγραφή, Διάρκεια (μήνες), Εκτιμώμενη ημερομηνία έναρξης και λήξης, Εκτιμώμενο κόστος. Τα <b>Έτη<\/b> δημιουργούνται αυτόματα από τη διάρκεια, όπως στις Συμβάσεις, αλλά χωρίς υπενθύμιση. Σε κάθε έτος βάζεις επιμέρους ποσά με το σχετικό άρθρο. Τα συνημμένα προστίθενται στο παράθυρο της εγγραφής.<\/p>\n<p><b>Προϋπολογισμός:<\/b> όσο ο διαγωνισμός είναι <b>ενεργός<\/b>, τα ποσά του περιλαμβάνονται στον Προϋπολογισμό με σημείωση «Εκτιμώμενος διαγωνισμός».<\/p>\n<p><b>Δύο επιλογές μέσα στον διαγωνισμό:<\/b><\/p>\n<ul>\n<li><b>Ακύρωση και αποθήκευση για αναφορά:<\/b> ο διαγωνισμός μένει στη λίστα ως «Ακυρώθηκε» και αφαιρείται από τον Προϋπολογισμό. Μπορείς να τον επανενεργοποιήσεις με το «Επανενεργοποίηση».<\/li>\n<li><b>Promote στις Συμβάσεις και αποθήκευση για αναφορά:<\/b> ανοίγει η φόρμα Σύμβασης προσυμπληρωμένη από τον διαγωνισμό. Συμπληρώνεις τα υπόλοιπα (π.χ. ανάδοχος, συντονιστής, υπενθυμίσεις) και διορθώνεις ό,τι χρειάζεται, και η σύμβαση δημιουργείται μόνο όταν πατήσεις την αποθήκευση. Ο διαγωνισμός μένει ως «Προωθήθηκε σε Σύμβαση», με σύνδεσμο προς τη σύμβαση, και αφαιρείται από τον Προϋπολογισμό. Από εδώ και πέρα τα ποσά μπαίνουν στον Προϋπολογισμό μέσω της σύμβασης. Τα συνημμένα του διαγωνισμού αντιγράφονται στη σύμβαση.<\/li>\n<\/ul>\n<p><b>Τροποποίηση Διαγωνισμού (3.20.0):<\/b> ένας <b>ενεργός<\/b> διαγωνισμός έχει και το κουμπί «Τροποποίηση Διαγωνισμού». Ανοίγει η ίδια φόρμα με την επεξεργασία, με περιγραφή και ημερομηνία της τροποποίησης (υποχρεωτική περιγραφή). Για κάθε πεδίο που αλλάζει ή προστίθεται εμφανίζεται η <b>προηγούμενη τιμή<\/b>, και οι τροποποιήσεις καταγράφονται στο ιστορικό του διαγωνισμού (δεν σβήνονται).<\/p>\n<p><b>Σχετιζόμενη σύμβαση (3.20.0):<\/b> κάθε διαγωνισμός συνδέεται με τη σύμβαση στην οποία αναφέρεται. Στους διαγωνισμούς που δημιουργούνται χειροκίνητα υπάρχει πεδίο επιλογής «Σχετιζόμενη σύμβαση»· η καρτέλα της σύμβασης δείχνει τους σχετιζόμενους διαγωνισμούς.<\/p>\n<p><b>Αυτόματοι διαγωνισμοί (3.20.0):<\/b> κάθε 5 Ιανουαρίου δημιουργείται, για κάθε σύμβαση που λήγει στο τρέχον έτος +1, +2 ή +3 και δεν έχει ήδη σχετιζόμενο διαγωνισμό, ένας διαγωνισμός σε κατάσταση <b>«Σε αναμονή έγκρισης»<\/b> (Όνομα, Περιγραφή, Διάρκεια, Έτη όπως στη σύμβαση· έναρξη = η επόμενη ημέρα από τη λήξη της σύμβασης· λήξη αυτόματα· εκτιμώμενο κόστος = Κόστος σύμβασης × 10%). Ο διαγωνισμός δεν μετράει στον Προϋπολογισμό μέχρι να εγκριθεί (κουμπιά «Έγκριση» / «Απόρριψη»). Στο WordPress τρέχει στον διακομιστή· στις αυτόνομες εκδόσεις τρέχει όταν ανοίξει η εφαρμογή την 5η Ιανουαρίου ή αργότερα. Στις Ρυθμίσεις υπάρχει κουμπί «Δημιουργία τώρα» για διαχειριστές.<\/p>\n<p>Ένας ακυρωμένος ή προωθημένος διαγωνισμός δεν προωθείται ξανά. Στο WordPress το Promote απαιτεί δικαίωμα επεξεργασίας διαγωνισμών και δημιουργίας συμβάσεων.<\/p>\n\n<h3 id=\"g-pv\">Γενικές Πρόνοιες<\/h3>\n<p>Εδώ καταγράφονται γενικές πρόνοιες για σκοπούς προϋπολογισμού. Με «+ Νέα Γενική Πρόνοια» συμπληρώνεις:<\/p>\n<ul>\n<li><b>Περιγραφή<\/b> και προαιρετικές σημειώσεις.<\/li>\n<li><b>Σχετικό άρθρο<\/b> προϋπολογισμού (υποχρεωτικό).<\/li>\n<li><b>Ποσά για τα επόμενα 3 έτη<\/b> μετά το έτος καταχώρησης: αν καταχωρείς το 2026, δίνονται ποσά για 2027, 2028 και 2029. Τα ποσά δίνονται <b>χωρίς ΦΠΑ<\/b>· πρέπει να συμπληρώσεις τουλάχιστον ένα. Τα έτη μένουν σταθερά όπως ορίστηκαν κατά την καταχώρηση.<\/li>\n<li><b>Συνημμένα:<\/b> μετά την πρώτη αποθήκευση ανοίγουν οι λεπτομέρειες της πρόνοιας, όπου προσθέτεις ή αφαιρείς αρχεία («+ Προσθήκη αρχείων»).<\/li>\n<\/ul>\n<p><b>Στον Προϋπολογισμό:<\/b> το ποσό κάθε έτους περνά στο σχετικό άρθρο, ολόκληρο στο ημερολογιακό έτος του, με προσθήκη ΦΠΑ (όπως ορίζεται στις Ρυθμίσεις), σε δική του γραμμή με δικό της χρώμα. Πρόνοια στον Κάδο δεν υπολογίζεται. Η αναζήτηση, η διαγραφή στον Κάδο και η επαναφορά λειτουργούν όπως στις άλλες καρτέλες. Στο WordPress η ενότητα έχει δικά της δικαιώματα στο Application Management (module «provisions»).<\/p>\n\n<h3 id=\"g-own\">Ιδιοκτήτες και ορατότητα εγγραφών (WordPress)<\/h3>\n<p>Στα <b>Λογισμικά, Συμβάσεις, Διαγωνισμούς και Γενικές Πρόνοιες<\/b> κάθε εγγραφή έχει <b>ιδιοκτήτη<\/b>. Στις Συμβάσεις ο ιδιοκτήτης είναι ο <b>Συντονιστής<\/b> (επιλέγεται από λίστα χρηστών WordPress με πρόσβαση στην εφαρμογή). Στις άλλες τρεις καρτέλες είναι ο <b>Υπεύθυνος<\/b>· από προεπιλογή είναι όποιος δημιουργεί την εγγραφή, και μπορεί να οριστεί άλλος.<\/p>\n<ul>\n<li><b>Ποιος βλέπει τι:<\/b> όποιος έχει το δικαίωμα <b>«Βλέπει όλες τις εγγραφές» (view_all)<\/b> στην ενότητα βλέπει όλες τις εγγραφές. Όποιος δεν το έχει βλέπει και αλλάζει <b>μόνο τις δικές του<\/b>. Οι ξένες εγγραφές δεν φτάνουν καν στον browser· ισχύει και για αναζήτηση, εξαγωγή, συνημμένα και προειδοποιήσεις διπλότυπων.<\/li>\n<li><b>Προειδοποίηση:<\/b> αν στη δημιουργία ορίσεις ως ιδιοκτήτη άλλον χρήστη, εμφανίζεται προειδοποίηση «Θα πάψετε να βλέπετε αυτή την εγγραφή» πριν την αποθήκευση.<\/li>\n<li><b>Αλλαγή ιδιοκτήτη:<\/b> σε υπάρχουσα εγγραφή μπορεί να την αλλάξει μόνο όποιος έχει «Βλέπει όλες τις εγγραφές». Οι υπόλοιποι ορίζουν ιδιοκτήτη μόνο στη δημιουργία.<\/li>\n<li><b>Προϋπολογισμός και Πλαίσιο Συμφιλίωσης<\/b> αθροίζουν όλες τις εγγραφές, γι' αυτό <b>κρύβονται<\/b> από όσους δεν έχουν «Βλέπει όλες τις εγγραφές».<\/li>\n<li><b>Διαγωνισμοί:<\/b> οι αυτόματοι διαγωνισμοί της 5ης Ιανουαρίου παίρνουν τον ιδιοκτήτη της σύμβασης. Όταν ένας διαγωνισμός προωθείται σε σύμβαση, ο ιδιοκτήτης του γίνεται Συντονιστής της σύμβασης.<\/li>\n<li><b>Υπενθυμίσεις:<\/b> το email υπενθύμισης στέλνεται και στον ιδιοκτήτη της εγγραφής, επιπλέον των υπαρχόντων παραληπτών.<\/li>\n<li><b>Excel:<\/b> στην εισαγωγή συμβάσεων το όνομα Συντονιστή αντιστοιχίζεται σε χρήστη· αν δεν βρεθεί, ιδιοκτήτης γίνεται όποιος κάνει την εισαγωγή (εμφανίζεται μήνυμα με το πλήθος).<\/li>\n<li><b>Κοινά για όλους:<\/b> Ανάδοχοι, Άρθρα και Ρυθμίσεις δεν έχουν ιδιοκτήτη.<\/li>\n<\/ul>\n<p><b>Για διαχειριστές:<\/b> το «view_all» δίνεται ανά ρόλο, ανά χρήστη και ανά ενότητα στο Application Management. Στην αναβάθμιση σε 3.21.0 όλοι οι ρόλοι και οι χρήστες που έχουν «view» παίρνουν αυτόματα και «view_all», άρα <b>τίποτα δεν αλλάζει<\/b> μέχρι να το αφαιρέσεις. Ρόλοι που δημιουργούνται αργότερα δεν το έχουν και βλέπουν μόνο τις δικές τους εγγραφές.<\/p>\n<p><b>Παλιές εγγραφές:<\/b> στα Λογισμικά, Διαγωνισμούς και Γενικές Πρόνοιες ιδιοκτήτης ορίζεται ο δημιουργός. Στις Συμβάσεις το κείμενο του Συντονιστή δεν αντιστοιχεί αυτόματα σε χρήστη: στις <b>⚙ Ρυθμίσεις<\/b> υπάρχει κάρτα «Ιδιοκτήτες εγγραφών» που προτείνει αντιστοίχιση όπου βρει μοναδικό χρήστη και δείχνει όσες δεν αντιστοιχίστηκαν. Εγγραφές χωρίς ιδιοκτήτη τις βλέπουν μόνο όσοι έχουν «Βλέπει όλες τις εγγραφές». Οι εκδόσεις HTML και Windows δεν έχουν χρήστες και δεν επηρεάζονται.<\/p>\n\n<h3 id=\"g-bd\">Προϋπολογισμός<\/h3>\n<p>Η καρτέλα δεν έχει δικά της δεδομένα. Συμπληρώνεται αυτόματα από τα επιμέρους ποσά των Λογισμικών, των Συμβάσεων και των <b>ενεργών<\/b> Διαγωνισμών.<\/p>\n<ul>\n<li>Πάνω φαίνεται το σύνολο κάθε έτους, με το έτος τονισμένο.<\/li>\n<li><b>Χρώματα γραμμών:<\/b> κάθε γραμμή χρωματίζεται με ανοιχτή απόχρωση του χρώματος της καρτέλας από την οποία προέρχεται: τιρκουάζ για Λογισμικά, μπλε για Συμβάσεις, μωβ για Διαγωνισμούς. Το υπόμνημα είναι πάνω από τους πίνακες.<\/li>\n<li>Επιπλέον: Με το «Άρθρο» διαλέγεις ένα άρθρο ή όλα. Κάθε άρθρο έχει δικό του πίνακα με στήλες Α/Α, Λεπτομέρειες Δαπάνης (το όνομα της σύμβασης, του διαγωνισμού ή του λογισμικού), Τρόπος Υπολογισμού και ένα ποσό ανά έτος.<\/li>\n<li><b>ΦΠΑ:<\/b> στις εγγραφές τα ποσά είναι χωρίς ΦΠΑ. Ο Προϋπολογισμός προσθέτει ΦΠΑ, προεπιλογή 19% (στήλες «€ με ΦΠΑ»). Ο Τρόπος Υπολογισμού δείχνει καθαρό ποσό + ΦΠΑ = σύνολο.<\/li>\n<li><b>Ανάλυση ανά έτος = ΝΑΙ:<\/b> το ποσό μοιράζεται ανά μήνα στα ημερολογιακά έτη της περιόδου (ένας μερικός μήνας μετράει ανάλογα με τις ημέρες). Παράδειγμα: 1.200 € καθαρά με περίοδο από 1/4 για 12 μήνες γίνονται 1.428 € με ΦΠΑ, δηλαδή 1.071 € στο πρώτο έτος και 357 € στο επόμενο.<\/li>\n<li><b>Ανάλυση ανά έτος = ΌΧΙ:<\/b> ολόκληρο το ποσό μπαίνει στο έτος έναρξης.<\/li>\n<li>Ποσά χωρίς άρθρο εμφανίζονται στον πίνακα «Χωρίς άρθρο». Αν μια εγγραφή δεν έχει ημερομηνία έναρξης, εμφανίζεται προειδοποίηση ότι δεν περιλαμβάνεται.<\/li>\n<li><b>Εξαγωγή Excel:<\/b> δημιουργεί φύλλο σύνοψης και ένα φύλλο ανά άρθρο, με τύπους αθροίσματος.<\/li>\n<li>Εγγραφές στον Κάδο, ακυρωμένοι και προωθημένοι διαγωνισμοί δεν υπολογίζονται.<\/li>\n<\/ul>\n<p><b>Άρθρα προϋπολογισμού:<\/b> δες και την καρτέλα «Άρθρα». Η λίστα (Κωδικός, Περιγραφή, Κατηγορία, Περιγραφή κατηγορίας, Ανάλυση ανά έτος ΝΑΙ/ΌΧΙ) είναι πίνακας με «+ Προσθήκη νέου άρθρου» και «Διαγραφή». Η επεξεργασία γίνεται μέσα στην ίδια την εφαρμογή, από το κουμπί «Επεξεργασία άρθρων» της καρτέλας «Άρθρα» (ή «Άρθρα προϋπολογισμού» στον Προϋπολογισμό), σε όλες τις εκδόσεις. Άρθρο που χρησιμοποιείται σε εγγραφές δεν διαγράφεται και δεν αλλάζει κωδικό.<\/p>\n\n<h3 id=\"g-rc\">Πλαίσιο Συμφιλίωσης<\/h3>\n<p>Η καρτέλα δεν έχει δικά της δεδομένα· υπολογίζεται αυτόματα και δείχνει <b>έναν πίνακα ακριβώς στη μορφή του προτύπου Excel<\/b>: στήλες Κεφάλαιο, Άρθρο, Εγκεκριμένος Π/Υ του τρέχοντος έτους, και για τα τρία επόμενα έτη (Y+1, Y+2, Y+3) «Π/Υ Βάση ΜΔΠ», «Προτεινόμ. Αλλαγή» και «Αναθεωρ. Π/Υ», και τέλος «Επεξηγήσεις για την προτεινόμενη αλλαγή». Οι αριθμοί 1–6 πάνω από τις στήλες δείχνουν ποιες στήλες αθροίζονται στα αναθεωρημένα ποσά (1+2, 3+4, 5+6). Τα έτη προκύπτουν από το τρέχον έτος. Υπάρχει <b>μία γραμμή για κάθε εγγραφή και για κάθε άρθρο<\/b> της (το Κεφάλαιο μένει κενό, στο Άρθρο μπαίνει ο αριθμός του άρθρου). Τα ποσά είναι με ΦΠΑ και κατανεμημένα ανά έτος όπως στον Προϋπολογισμό, και φαίνονται σε ακέραια ευρώ (το ακριβές ποσό φαίνεται όταν πας το ποντίκι πάνω του και στο Excel). Γραμμές υπάρχουν για:<\/p>\n<ul>\n<li><b>Α. Κάθε ενεργό διαγωνισμό<\/b> (όχι τους ακυρωμένους ούτε όσους προωθήθηκαν): τα ποσά του κάθε έτους είναι η «Βάση ΜΔΠ» και η προτεινόμενη αλλαγή είναι 0. Επεξηγήσεις: όνομα διαγωνισμού, περιγραφή, διάρκεια, εκτιμώμενες ημερομηνίες έναρξης και λήξης, εκτιμώμενο κόστος.<\/li>\n<li><b>Β. Κάθε σύμβαση που προήλθε από προώθηση διαγωνισμού<\/b> και το Συνολικό Κόστος της (με πρόσθετες υπηρεσίες, χωρίς ΦΠΑ) διαφέρει από το εκτιμώμενο κόστος του διαγωνισμού <b>πάνω από 4.999 €<\/b> (απόλυτο ποσό, προς τα πάνω ή προς τα κάτω· διαφορά ακριβώς 4.999,00 € δεν αναφέρεται, 4.999,01 € αναφέρεται). Βάση = τα ποσά του διαγωνισμού ανά έτος και άρθρο, Προτεινόμ. Αλλαγή = η διαφορά, Αναθεωρημένο = τα ποσά της σύμβασης. Επεξηγήσεις: σύμβαση, αριθμός διαγωνισμού, περιγραφή, διάρκεια, ημερομηνίες, κόστος.<\/li>\n<li><b>Γ. Κάθε σύμβαση που τροποποιήθηκε<\/b> και άλλαξε το ποσό της: βάση = η σύμβαση όπως ήταν πριν την πρώτη τροποποίηση, αναθεωρημένο = η τρέχουσα.<\/li>\n<li><b>ΣΤ. Κάθε ενεργός διαγωνισμός που τροποποιήθηκε<\/b> και άλλαξε το ποσό του: βάση = ο διαγωνισμός πριν την πρώτη τροποποίηση, αναθεωρημένο = ο τρέχων· στις Επεξηγήσεις αναγράφονται Όνομα, Περιγραφή, Διάρκεια, Εκτιμώμενη έναρξη/λήξη και Εκτιμώμενο κόστος και οι τροποποιήσεις (3.20.0).\n<li><b>Δ. Κάθε σύμβαση με επιλεγμένο το «Συμπερίληψη στο Πλαίσιο Συμφιλίωσης»<\/b> (πεδίο της φόρμας της σύμβασης και της «Τροποποίησης σύμβασης») και <b>Ε. κάθε Γενική Πρόνοια<\/b> με το ίδιο πεδίο. Για τις συμβάσεις τα ποσά είναι η βάση (αλλαγή 0). Επεξήγηση της Γενικής Πρόνοιας: περιγραφή, άρθρο και σημειώσεις.<\/li>\n<\/ul>\n<p>Κάθε ομάδα έχει δικό της χρώμα στο αριστερό άκρο της γραμμής και η πρώτη γραμμή της στήλης «Επεξηγήσεις» γράφει το κριτήριο (Α–Ε). Μια σύμβαση που πληροί περισσότερα από ένα κριτήρια εμφανίζεται σε γραμμές για το καθένα. Ποσά πέρα από το έτος Y+3 δεν εμφανίζονται. Η αναζήτηση φιλτράρει τον πίνακα. Το «Εξαγωγή Excel» δίνει αρχείο με την ίδια μορφοποίηση, πλάτη στηλών και ρυθμίσεις εκτύπωσης με το πρότυπο. Στο WordPress εμφανίζεται σε όποιον βλέπει έστω μία ενότητα.<\/p>\n<h3 id=\"g-ar\">Άρθρα<\/h3>\n<p>Η καρτέλα «Άρθρα» εμφανίζει τα άρθρα προϋπολογισμού του Οργανισμού: Κωδικός, Περιγραφή άρθρου, Κατηγορία, Περιγραφή κατηγορίας, Ανάλυση ανά έτος (ΝΑΙ/ΌΧΙ) και πόσες εγγραφές χρησιμοποιούν κάθε άρθρο. Η αναζήτηση φιλτράρει τη λίστα.<\/p>\n<ul>\n<li>Τη βλέπει όποιος μπορεί να δει τουλάχιστον μία από τις ενότητες (Λογισμικά, Συμβάσεις, Διαγωνισμοί). Δεν έχει δικά της δικαιώματα.<\/li>\n<li><b>Αλλαγή άρθρων:<\/b> από το κουμπί «Επεξεργασία άρθρων» της ίδιας καρτέλας, μέσα στην εφαρμογή. Στο WordPress τα δικαιώματα ορίζονται στο PROCURE360 → Application Management, στην ενότητα «Budget Articles (Άρθρα)»: <b>create<\/b> = προσθήκη νέων άρθρων, <b>edit<\/b> = αλλαγή υπαρχόντων, <b>delete<\/b> = διαγραφή. Δίνονται ανά ρόλο ή ανά χρήστη· από προεπιλογή μόνο ο Administrator τα έχει. Όποιος δεν έχει κανένα βλέπει μόνο τη λίστα, και όποιος έχει μερικά βλέπει τα υπόλοιπα κουμπιά απενεργοποιημένα. Η αποθήκευση γίνεται στον server και ισχύει για όλους.\n<\/ul>\n\n<h3 id=\"g-co\">Ανάδοχοι<\/h3>\n<p><b>Τι είναι:<\/b> η κεντρική λίστα των αναδόχων. Κάθε ανάδοχος καταχωρείται μία φορά και επιλέγεται από τις Συμβάσεις.<\/p>\n<p><b>Πεδία:<\/b> Όνομα (υποχρεωτικό), Διεύθυνση (οδός/αριθμός και συνέχεια), Τ.Κ., Πόλη, Χώρα, Άτομο επικοινωνίας, Τηλέφωνο, Email (για περισσότερα από ένα τηλέφωνο ή email χρησιμοποίησε κόμμα (,) ή ερωτηματικό (;)).<\/p>\n<p><b>Στήλες της λίστας:<\/b> εκτός από τα στοιχεία, η λίστα δείχνει <b>πόσες ενεργές συμβάσεις<\/b> έχει ο ανάδοχος και <b>ποιοι αριθμοί διαγωνισμού<\/b> (π.χ. ΟΑΠ/ΠΜΕ/01/21/01) αφορούν τις ενεργές συμβάσεις του (ο ίδιος αριθμός σε δύο συμβάσεις εμφανίζεται μία φορά). Ενεργή είναι κάθε σύμβαση που δεν έχει λήξει (σε ισχύ, λήγει σύντομα ή δεν έχει ξεκινήσει). Στο παράθυρο του αναδόχου φαίνονται όλες οι συμβάσεις του, με σύνδεσμο για άνοιγμα.<\/p>\n<p><b>Κανόνες:<\/b> δεν επιτρέπονται δύο ανάδοχοι με το ίδιο όνομα (χωρίς διάκριση πεζών/κεφαλαίων και τόνων). Ανάδοχος που χρησιμοποιείται σε σύμβαση δεν διαγράφεται· πρώτα αλλάζεις τον ανάδοχο στις συμβάσεις. Αν μετονομάσεις έναν ανάδοχο, η αλλαγή φαίνεται αυτόματα σε όλες τις συμβάσεις του.<\/p>\n<p><b>Κάδος, Excel:<\/b> η διαγραφή πηγαίνει στον Κάδο (με επαναφορά). Η εξαγωγή Excel/CSV περιλαμβάνει τις ενεργές συμβάσεις και τους αριθμούς διαγωνισμού. Δεν υπάρχει εισαγωγή αναδόχων από Excel· κατά την εισαγωγή συμβάσεων ο ανάδοχος συνδέεται αυτόματα αν το όνομά του υπάρχει στη λίστα.<\/p>\n<p><b>Δικαιώματα (WordPress):<\/b> η ενότητα «Contractors (Ανάδοχοι)» στο Application Management έχει δικά της δικαιώματα προβολής, δημιουργίας, επεξεργασίας, διαγραφής και εξαγωγής.<\/p>\n\n<h3 id=\"g-ms\">Milestones<\/h3>\n<p>Σε μια εγγραφή (Λογισμικό ή Σύμβαση) πρόσθεσε milestones ανά έτος με «+ Προσθήκη milestone»: περιγραφή, ημερομηνία παράδοσης, ειδοποίηση (30 ή 60 ημέρες πριν), σχόλια και συνημμένα. Η ειδοποίηση εμφανίζεται στην οθόνη και στέλνεται με email.<\/p>\n\n<h3 id=\"g-att\">Συνημμένα<\/h3>\n<p>Στο παράθυρο μιας εγγραφής πάτα «+ Προσθήκη αρχείων» (PDF, εικόνες, CSV, κείμενο, Word, Excel, PowerPoint, HTML, XML, email (eml/msg), άδειες (lic), συμπιεσμένα (zip/7z/rar), JSON, RTF, ics/vcf, πιστοποιητικά (cer/crt/p7m/p7s), dwg/dxf κ.ά., <b>έως 20 MB το καθένα<\/b>· δεν υπάρχει όριο στον αριθμό των αρχείων). Για άνοιγμα πάτα στο όνομα του αρχείου. Τα αρχεία <b>HTML<\/b> δεν ανοίγουν μέσα στην εφαρμογή (για λόγους ασφαλείας, γιατί θα μπορούσαν να εκτελέσουν κώδικα): κατεβαίνουν στον υπολογιστή σου και τα ανοίγεις από εκεί. Στο WordPress ελέγχεται και το περιεχόμενο: ένα «.pdf» που δεν είναι PDF, ή ένα πρόγραμμα/script με άλλη επέκταση, απορρίπτεται με σχετικό μήνυμα. Στο WordPress ο server μπορεί να έχει μικρότερο όριο (ρυθμίσεις PHP <code>upload_max_filesize<\/code> και <code>post_max_size<\/code>)· τότε η εφαρμογή δείχνει το πραγματικό όριο δίπλα στο κουμπί και, για μεγαλύτερο αρχείο, ζητά από τον διαχειριστή του hosting να τα αυξήσει σε τουλάχιστον 20M. Το «Αφαίρεση» σβήνει το αρχείο (με αναίρεση για λίγα δευτερόλεπτα). Τα συνημμένα εμφανίζονται ως στήλη «Αρχεία» στη λίστα και ως όνομα στην εξαγωγή.<\/p>\n\n<h3 id=\"g-trash\">Κάδος και αναίρεση<\/h3>\n<ul>\n<li><b>Αναίρεση:<\/b> μετά από διαγραφή εγγραφής, milestone ή συνημμένου εμφανίζεται για 8 δευτερόλεπτα κουμπί «Αναίρεση».<\/li>\n<li><b>Κάδος:<\/b> η διαγραφή μεταφέρει την εγγραφή στον Κάδο (κουμπί «🗑 Κάδος» δίπλα στα φίλτρα). Εκεί γίνεται <b>Επαναφορά<\/b>. Οι εγγραφές του κάδου δεν υπολογίζονται, δεν στέλνουν υπενθυμίσεις και δεν μπαίνουν στις εξαγωγές.<\/li>\n<li><b>Οριστική διαγραφή:<\/b> γίνεται μόνο από τον Κάδο (στο WordPress με ξεχωριστό δικαίωμα) και αυτόματα μετά από 30 ημέρες (ρυθμίζεται στο WordPress: Ρυθμίσεις → PROCURE360 → Παραμονή στον Κάδο· 0 = ποτέ).<\/li>\n<\/ul>\n\n<h3 id=\"g-rem\">Υπενθυμίσεις<\/h3>\n<ul>\n<li>Στο άνοιγμα της εφαρμογής εμφανίζεται παράθυρο «Needs your attention» με ό,τι έληξε ή λήγει σύντομα. Σε κάθε καρτέλα φαίνονται και ειδοποιήσεις για την άλλη καρτέλα.<\/li>\n<li><b>WordPress:<\/b> στέλνονται και email, αυτόματα μία φορά την ημέρα. Παραλήπτες είναι τα email της εγγραφής (ή, αν δεν υπάρχουν, οι γενικοί παραλήπτες των Ρυθμίσεων) και ο ιδιοκτήτης της εγγραφής· το email επαναλαμβάνεται κάθε Ν ημέρες όσο η εγγραφή χρειάζεται ενέργεια. Οι Διαγωνισμοί δεν έχουν υπενθυμίσεις.<\/li>\n<li>Στις εκδόσεις HTML και Windows δεν στέλνονται email, μόνο το παράθυρο στο άνοιγμα. Η έκδοση Windows μπορεί να ανοίγει με την εκκίνηση των Windows.<\/li>\n<\/ul>\n\n<h3 id=\"g-xl\">Excel: εισαγωγή και εξαγωγή<\/h3>\n<ul>\n<li><b>Εισαγωγή:<\/b> κουμπί «Import Excel» (Λογισμικά και Συμβάσεις). Οι στήλες αναγνωρίζονται από τους τίτλους τους, ελληνικούς ή αγγλικούς. Υπάρχει και πρότυπο αρχείου για λήψη. Οι Διαγωνισμοί δεν έχουν εισαγωγή από Excel.<\/li>\n<li><b>Εξαγωγή:<\/b> κουμπί «Export» / «Εξαγωγή» σε Excel ή CSV, με όλα τα πεδία και τα επιμέρους ποσά. Στους Διαγωνισμούς περιλαμβάνεται και η κατάσταση.<\/li>\n<li>Στο WordPress η εξαγωγή χρειάζεται δικαίωμα «export».<\/li>\n<\/ul>\n\n<h3 id=\"g-cfg\">Ρυθμίσεις εφαρμογής (καρτέλα ⚙ Ρυθμίσεις)<\/h3>\n<ul>\n<li><b>Πού είναι:<\/b> η καρτέλα «⚙ Ρυθμίσεις» δίπλα στα Άρθρα. Στο WordPress φαίνεται και αλλάζει μόνο από διαχειριστή (δικαίωμα διαχείρισης)· στις εκδόσεις HTML και Windows είναι ανοιχτή σε όποιον χρησιμοποιεί τον υπολογιστή.<\/li>\n<li><b>Γενικά:<\/b> το ποσοστό ΦΠΑ του Προϋπολογισμού (προεπιλογή 19%, 0–100) και οι προεπιλεγμένες ημέρες υπενθύμισης για τα νέα έτη συμβάσεων (προεπιλογή 30, 1–365). Η αλλαγή του ΦΠΑ επηρεάζει μόνο την εμφάνιση του Προϋπολογισμού, οι εγγραφές κρατούν ποσά χωρίς ΦΠΑ. Οι προεπιλεγμένες ημέρες ισχύουν για νέα έτη συμβάσεων, όχι για τα υπάρχοντα ούτε για τα Λογισμικά.<\/li>\n<li><b>Custom fields (δικά σου πεδία):<\/b> μπορείς να προσθέσεις δικά σου πεδία σε Συμβάσεις, Διαγωνισμούς, Αναδόχους και Λογισμικά (έως 30 ανά καρτέλα). Τύποι: Κείμενο, Αριθμός / Ποσό €, Ημερομηνία, Λίστα επιλογών. Τα πεδία εμφανίζονται στις φόρμες, στις λεπτομέρειες, στις στήλες της λίστας (⚙ Στήλες) και στις εξαγωγές Excel/CSV. Ο τύπος ενός αποθηκευμένου πεδίου δεν αλλάζει. Αν διαγράψεις ένα πεδίο, οι τιμές του κρύβονται και χάνονται όταν ξαναγίνει αποθήκευση της εγγραφής.<\/li>\n<li><b>Πρότυπο Σημειώματος ανανέωσης:<\/b> η κάρτα «Πρότυπο Σημειώματος ανανέωσης» έχει τα κουμπιά <b>Λήψη τρέχοντος προτύπου<\/b>, <b>Ανέβασμα νέου προτύπου (.docx)<\/b> και <b>Επαναφορά στο προεπιλεγμένο<\/b>. Για αλλαγή κειμένου ή μορφοποίησης: κατέβασε το πρότυπο, άλλαξέ το στο Word και ανέβασέ το. Τα πεδία που συμπληρώνονται αυτόματα γράφονται σε αγκύλες και πρέπει να μείνουν όπως είναι: <code>[Σημερινή Ημερομηνία]<\/code>, <code>[Software Name]<\/code>, <code>[Description]<\/code>, <code>[Renewal Date From]<\/code>, <code>[Renewal Date To]<\/code>, <code>[Cost]<\/code>, <code>[Κωδικός Άρθρου]<\/code>, <code>[Περιγραφή Άρθρου]<\/code>. Μετά το ανέβασμα η εφαρμογή λέει ποια πεδία βρέθηκαν. Όριο 2 MB· αρχεία με macros απορρίπτονται. Στο WordPress το πρότυπο αποθηκεύεται στη βάση και το αλλάζει μόνο διαχειριστής (δικαίωμα διαχείρισης ρυθμίσεων)· στο απλό HTML και στα Windows αποθηκεύεται σε αυτόν τον browser/υπολογιστή και <b>δεν<\/b> περιλαμβάνεται στο αντίγραφο ασφαλείας.<\/li>\n<li><b>Αντίγραφο ασφαλείας (Backup):<\/b> το κουμπί «Λήψη αντιγράφου» κατεβάζει ένα αρχείο ZIP με όλα τα δεδομένα (Λογισμικά, Συμβάσεις, Διαγωνισμοί, Ανάδοχοι), τα Άρθρα, τις Ρυθμίσεις και τα συνημμένα. Ο κάδος δεν περιλαμβάνεται. Το αρχείο περιέχει πραγματικά δεδομένα και ονόματα χρηστών· φύλαξέ το με ασφάλεια.<\/li>\n<li><b>Προγραμματισμένο backup (WordPress):<\/b> στην ίδια σελίδα, ο διαχειριστής μπορεί να ενεργοποιήσει αυτόματο backup <b>κάθε εβδομάδα ή κάθε μήνα<\/b> σε φάκελο που ορίζει, π.χ. φάκελο δικτύου (<code>/mnt/backup/procure360<\/code> ή <code>\\\\server\\share\\procure360<\/code>). Ο φάκελος πρέπει να τον βλέπει και να γράφει σε αυτόν ο server του WordPress και να είναι <b>εκτός<\/b> του site. Ορίζεις και πόσα backup κρατούνται (τα παλαιότερα διαγράφονται). Το αρχείο είναι το ίδιο ZIP με το χειροκίνητο και γίνεται Restore με τον ίδιο τρόπο. Το κουμπί «Αποθήκευση και backup τώρα» δοκιμάζει τη διαδρομή. Η εκτέλεση γίνεται από το WP-Cron (όταν το site έχει επισκέψεις), οπότε μπορεί να καθυστερήσει λίγο. Αν αποτύχει, στέλνεται email το πολύ μία φορά την ημέρα. Το πρόγραμμα ΔΕΝ περιλαμβάνεται στο backup, ώστε μια επαναφορά να μην αλλάζει τη διαδρομή.<\/li>\n<li><b>Προγραμματισμένο backup (Windows):<\/b> τρέξε το <code>Schedule-Backup.bat<\/code> (από τον φάκελο που εξήγαγες): ρωτά φάκελο (π.χ. δικτύου), εβδομαδιαίο ή μηνιαίο, ώρα και πόσα να κρατούνται, και φτιάχνει προγραμματισμένη εργασία των Windows. Εκεί το backup είναι zip του φακέλου δεδομένων της εφαρμογής (όπως το Backup.bat), όχι το ZIP της σελίδας Ρυθμίσεων. Τρέχει όσο είσαι συνδεδεμένος στα Windows και ο φάκελος δικτύου είναι προσβάσιμος. Στο απλό αρχείο HTML δεν υπάρχει αυτόματο backup.<\/li>\n<li><b>Επαναφορά (Restore):<\/b> διάλεξε το ZIP, δες την προεπισκόπηση (πόσες εγγραφές θα προστεθούν ή θα ενημερωθούν) και επιβεβαίωσε. Η επαναφορά ενημερώνει ή προσθέτει εγγραφές με βάση το αναγνωριστικό τους και <b>δεν διαγράφει<\/b> τίποτα. Μπορείς να επιλέξεις αν θα επαναφερθούν και οι Ρυθμίσεις και τα Άρθρα. Τα συνημμένα που υπάρχουν ήδη (ίδιο όνομα και μέγεθος) δεν ανεβαίνουν ξανά.<\/li>\n<\/ul>\n\n<h3 id=\"g-set\">Ρυθμίσεις και δικαιώματα (WordPress)<\/h3>\n<ul>\n<li><b>Μενού PROCURE360 (στο WordPress admin):<\/b> όλα βρίσκονται κάτω από ένα μενού. «Ρυθμίσεις»: γενικοί παραλήπτες υπενθυμίσεων, κάθε πόσες ημέρες επαναλαμβάνεται το email, παραμονή στον Κάδο και κουμπί αποστολής υπενθυμίσεων τώρα. Τα άρθρα δεν είναι πια εκεί· επεξεργάζονται μέσα στην εφαρμογή.<\/li>\n<li><b>PROCURE360 → Application Management:<\/b> εκεί ορίζεται ποιος έχει πρόσβαση και με ποιον ρόλο. Κάθε ενότητα (Software, Contracts, Tenders, Contractors, Budget Articles) έχει δικαιώματα προβολής, δημιουργίας, επεξεργασίας, διαγραφής και εξαγωγής. Επιπλέον υπάρχει το «purge» για οριστική διαγραφή από τον Κάδο. Το δικαίωμα προσαρμόζεται και ανά χρήστη. Στα Software, Contracts, Tenders και Γενικές Πρόνοιες υπάρχει και το <b>«view_all»<\/b> (βλέπει όλες τις εγγραφές)· δες «Ιδιοκτήτες και ορατότητα εγγραφών».<\/li>\n<li>Ό,τι γίνεται καταγράφεται στο αρχείο δραστηριότητας του Application Management.<\/li>\n<\/ul>\n\n<h3 id=\"g-data\">Δεδομένα και αντίγραφα ασφαλείας<\/h3>\n<ul>\n<li><b>WordPress:<\/b> τα δεδομένα είναι στη βάση του WordPress και είναι κοινά για όλους τους χρήστες. Τα αντίγραφα γίνονται με το αντίγραφο της βάσης και του φακέλου uploads του site σου. Πριν από αναβάθμιση plugin κάνε αντίγραφο.<\/li>\n<li><b>HTML και Windows:<\/b> τα δεδομένα αποθηκεύονται στον browser του συγκεκριμένου υπολογιστή και δεν μοιράζονται με άλλους. Στα Windows το Backup.bat φτιάχνει zip στα Έγγραφα. Μην καθαρίσεις τα δεδομένα του browser. Εξαγωγή Excel όποτε θες επιπλέον αντίγραφο.<\/li>\n<\/ul>\n\n<h3 id=\"g-sec\">Ασφάλεια και ίχνη ελέγχου (για διαχειριστές WordPress)<\/h3>\n<ul>\n<li><b>Τι καταγράφεται:<\/b> στο αρχείο δραστηριότητας του Application Management φαίνεται πλέον <b>ποιο πεδίο άλλαξε και από τι σε τι<\/b> (π.χ. κόστος 100 → 250). Στα ευαίσθητα πεδία (όνομα χρήστη, email) γράφεται μόνο «changed», όχι η τιμή. Καταγράφονται επίσης οι <b>λήψεις/ανοίγματα συνημμένων<\/b>, τα <b>αρχεία που απορρίφθηκαν<\/b> και οι <b>αιτήσεις που απορρίφθηκαν<\/b> (χωρίς δικαίωμα ή με υπέρβαση ορίου), το πολύ μία φορά το λεπτό για την ίδια ενέργεια.<\/li>\n<li><b>Αλυσίδα που δείχνει αν πείραξε κάποιος το αρχείο:<\/b> προαιρετική. Βάλε στο <code>wp-config.php<\/code> ένα μυστικό κλειδί: <code>define( 'RL_AUDIT_KEY', '… 64 τυχαίοι χαρακτήρες …' );<\/code> και κράτα αντίγραφο σε ασφαλές μέρος εκτός server. Κάθε εγγραφή «δένεται» με την προηγούμενη. Ο έλεγχος γίνεται με <code>wp procure360 audit-verify<\/code>: αναφέρει αν κάποια εγγραφή άλλαξε, διαγράφηκε ή προστέθηκε κρυφά. Χωρίς κλειδί η αλυσίδα δεν γράφεται. Πρόσεξε: αν το Application Management σβήνει παλιές εγγραφές (προεπιλογή 365 ημέρες), ο έλεγχος θα τις δείξει ως «λείπουν»· βάλε διατήρηση 0 ή αρχειοθέτησε.<\/li>\n<li><b>Αντίγραφο σε syslog:<\/b> κάθε εγγραφή στέλνεται και στο syslog του server (facility local6, πρόγραμμα «procure360») για να υπάρχει αντίγραφο εκτός βάσης δεδομένων.<\/li>\n<li><b>Έλεγχος αρχείων:<\/b> το σύστημα ελέγχει πλέον και το <b>περιεχόμενο<\/b> του αρχείου: ένα «.pdf» που δεν είναι PDF, ή εκτελέσιμο/script με άλλη επέκταση, απορρίπτεται. Προαιρετικά μπορεί να γίνεται και έλεγχος με ClamAV (<code>RL_CLAMSCAN_BIN<\/code>) και να αποθηκεύονται τα αρχεία εκτός του web root (<code>RL_FILES_DIR<\/code>). Οι ρυθμίσεις αυτές είναι τεχνικές: δες το αρχείο documentation/08-audit-and-hardening.md.<\/li>\n<li><b>Ποιος αλλάζει τις Ρυθμίσεις:<\/b> στο Application Management υπάρχει η ενότητα «PROCURE360 Settings» με το δικαίωμα «Change settings and schedule backups». Όποιος το έχει (προεπιλογή: Administrator και Super Admin) χρησιμοποιεί την καρτέλα ⚙ Ρυθμίσεις και το προγραμματισμένο backup <b>χωρίς<\/b> να είναι διαχειριστής του WordPress. Οι διαχειριστές του WordPress συνεχίζουν να έχουν πρόσβαση.<\/li>\n<li><b>Excel χωρίς internet:<\/b> η βιβλιοθήκη Excel (SheetJS 0.20.3) περιλαμβάνεται στο πακέτο και φορτώνεται με έλεγχο ακεραιότητας· καμία εξωτερική διεύθυνση δεν χρειάζεται.<\/li>\n<\/ul>\n\n<h3 id=\"g-faq\">Συχνές ερωτήσεις<\/h3>\n<ul>\n<li><b>Γιατί ο Προϋπολογισμός δείχνει μεγαλύτερο ποσό από αυτό που έγραψα;<\/b> Γιατί προσθέτει ΦΠΑ 19%. Οι εγγραφές κρατούν ποσά χωρίς ΦΠΑ.<\/li>\n<li><b>Ο διαγωνισμός δεν φαίνεται στον Προϋπολογισμό.<\/b> Ελέγχεται η κατάστασή του (πρέπει να είναι «Ενεργός») και αν έχει επιμέρους ποσά ή κόστος και ημερομηνία έναρξης.<\/li>\n<li><b>Έσβησα κάτι κατά λάθος.<\/b> Πάτα «Αναίρεση» αμέσως, αλλιώς πήγαινε στον Κάδο και πάτα Επαναφορά.<\/li>\n<li><b>Δεν μπορώ να διαγράψω ένα άρθρο.<\/b> Χρησιμοποιείται σε εγγραφές (live ή στον Κάδο). Άλλαξε πρώτα το άρθρο σε αυτές τις εγγραφές.<\/li>\n<li><b>Δεν βλέπω μια εγγραφή που ξέρω ότι υπάρχει (WordPress).<\/b> Βλέπεις μόνο τις εγγραφές των οποίων είσαι ιδιοκτήτης (Συντονιστής/Υπεύθυνος). Αν χρειάζεσαι πρόσβαση σε όλες, ζήτα το «Βλέπει όλες τις εγγραφές» από τον διαχειριστή.<\/li>\n<li><b>Δεν βλέπω τον Προϋπολογισμό.<\/b> Κρύβεται από όσους δεν έχουν «Βλέπει όλες τις εγγραφές».<\/li>\n<li><b>Δεν βλέπω μια καρτέλα ή ένα κουμπί (WordPress).<\/b> Ο ρόλος σου δεν έχει το σχετικό δικαίωμα· ζήτα το από τον διαχειριστή.<\/li>\n<li><b>Η σελίδα φαίνεται ίδια μετά από αναβάθμιση.<\/b> Κάνε ανανέωση με Ctrl+F5.<\/li>\n<\/ul>\n\n<h3 id=\"g-new\">Τι νέο υπάρχει<\/h3>\n<ul>\n<li><b>3.21.0:<\/b> <b>Ιδιοκτήτες εγγραφών<\/b> (WordPress): στα Λογισμικά, Συμβάσεις, Διαγωνισμούς και Γενικές Πρόνοιες όποιος δεν έχει το δικαίωμα «Βλέπει όλες τις εγγραφές» βλέπει και αλλάζει μόνο τις δικές του. Στις Συμβάσεις ιδιοκτήτης είναι ο Συντονιστής (λίστα χρηστών WordPress), στις υπόλοιπες ο Υπεύθυνος. Προειδοποίηση όταν ορίζεται άλλος ιδιοκτήτης, οθόνη αντιστοίχισης παλιών εγγραφών στις Ρυθμίσεις, υπενθυμίσεις και στον ιδιοκτήτη. Ο Προϋπολογισμός και το Πλαίσιο Συμφιλίωσης κρύβονται από όσους δεν βλέπουν τα πάντα. Στην αναβάθμιση τίποτα δεν αλλάζει μέχρι ο διαχειριστής να αφαιρέσει το «view_all».<\/li>\n<li><b>3.20.0:<\/b> <b>Τροποποίηση Διαγωνισμού<\/b> για ενεργούς διαγωνισμούς, με την προηγούμενη τιμή κάθε αλλαγμένου πεδίου. Στο Πλαίσιο Συμφιλίωσης νέα ομάδα <b>ΣΤ<\/b> για τροποποιημένους διαγωνισμούς με αλλαγή ποσού. <b>Αυτόματοι διαγωνισμοί<\/b> κάθε 5 Ιανουαρίου από τις συμβάσεις που λήγουν σε +1/+2/+3 έτη (κατάσταση «Σε αναμονή έγκρισης», κόστος = 10% της σύμβασης). Κάθε διαγωνισμός συνδέεται με τη <b>σχετιζόμενη σύμβαση<\/b>. Τα συνημμένα κατεβαίνουν με το όνομα του αρχείου.<\/li>\n<li><b>3.19.0:<\/b> Η καρτέλα «Online Renewals» μετονομάστηκε σε <b>«Λογισμικά»<\/b>. Το <b>Πλαίσιο Συμφιλίωσης<\/b> είναι πλέον ένας πίνακας ακριβώς στη μορφή του προτύπου Excel (Κεφάλαιο, Άρθρο, Εγκεκριμένος Π/Υ, Βάση ΜΔΠ / Προτεινόμ. Αλλαγή / Αναθεωρημένο για τρία έτη, Επεξηγήσεις), με μία γραμμή ανά εγγραφή και άρθρο για ενεργούς διαγωνισμούς, συμβάσεις με μεταβολή &gt; 4.999 €, τροποποιημένες συμβάσεις, επιλεγμένες συμβάσεις και Γενικές Πρόνοιες. Η εξαγωγή Excel κρατά τη μορφή του προτύπου.<\/li>\n<li><b>3.18.0:<\/b> Σε κάθε Online Renewal υπάρχει το κουμπί <b>«Ετοιμασία Σημειώματος»<\/b>: δημιουργεί σημείωμα Word (.docx) από πρότυπο. Το πρότυπο βρίσκεται στις <b>⚙ Ρυθμίσεις<\/b>, όπου μπορείς να το κατεβάσεις, να ανεβάσεις τροποποιημένο ή να επαναφέρεις το προεπιλεγμένο.<\/li>\n<li><b>3.17.0:<\/b> Πλαίσιο Συμφιλίωσης: ο πίνακας Α έχει μόνο τους <b>ενεργούς<\/b> διαγωνισμούς· ο πίνακας Β αναφέρει συμβάσεις που από την προώθηση αυξήθηκαν ή μειώθηκαν <b>πάνω από 4.999 €<\/b> (αντί για απόκλιση 20%). Νέο πεδίο <b>«Συμπερίληψη στο Πλαίσιο Συμφιλίωσης»<\/b> στις Συμβάσεις και στις Γενικές Πρόνοιες, με δύο νέους πίνακες (Δ και Ε) για τις επιλεγμένες εγγραφές.<\/li>\n<li><b>3.16.0:<\/b> Νέα καρτέλα <b>Γενικές Πρόνοιες<\/b> (περιγραφή, σχετικό άρθρο, συνημμένα και ποσά για τα επόμενα 3 έτη· περιλαμβάνονται στον Προϋπολογισμό). Νέα καρτέλα <b>Πλαίσιο Συμφιλίωσης<\/b> (όλοι οι διαγωνισμοί· συμβάσεις με απόκλιση πάνω από 20% από τον διαγωνισμό· τροποποιημένες συμβάσεις με αλλαγή ποσού). Στις Συμβάσεις νέα επιλογή <b>Τροποποίηση σύμβασης<\/b> με προηγούμενη τιμή σε κάθε αλλαγμένο πεδίο, περιγραφή τροποποίησης (π.χ. ΤΕΑΑ, ΚΕΑΑ, Συμπληρωματικός Προϋπολογισμός) και ιστορικό που μόνο προστίθεται. Οι Γενικές Πρόνοιες περιλαμβάνονται στο backup/επαναφορά.<\/li>\n<li><b>3.15.0:<\/b> Στις Συμβάσεις δεν επιτρέπεται δεύτερη σύμβαση με τον ίδιο αριθμό διαγωνισμού: εμφανίζεται μήνυμα (φόρμα, εισαγωγή Excel, προώθηση διαγωνισμού, επαναφορά από κάδο, και στον server του WordPress). Πεδίο αναζήτησης σε κάθε σελίδα: νέο φιλτράρισμα στον Προϋπολογισμό, στις Ρυθμίσεις και στον Οδηγό.<\/li>\n<li><b>3.14.0:<\/b> Ίχνη ελέγχου: καταγράφεται ποιο πεδίο άλλαξε (από τι σε τι), οι λήψεις αρχείων και οι απορριφθείσες αιτήσεις· προαιρετική αλυσίδα που ανιχνεύει πείραγμα στο αρχείο δραστηριότητας (WordPress). Τα συνημμένα ελέγχονται και ως προς το περιεχόμενο (προαιρετικά και με ClamAV, και φύλαξη εκτός web root). Νέο δικαίωμα για τις Ρυθμίσεις χωρίς να χρειάζεται διαχειριστής WordPress. Το Excel δουλεύει χωρίς internet (η βιβλιοθήκη περιλαμβάνεται). Δες «Ασφάλεια και ίχνη ελέγχου».<\/li>\n<li><b>3.13.1:<\/b> Όταν ανοίγεις υπάρχουσα εγγραφή (Λογισμικά, Σύμβαση, Διαγωνισμό, Ανάδοχο) ανοίγει σε πλήρη οθόνη, κεντραρισμένη, και όχι σε πλαϊνό πάνελ. Το «Κλείσιμο» και το Escape επιστρέφουν στη λίστα.<\/li>\n<li><b>3.13.0:<\/b> Ρυθμίσεις: προγραμματισμένο backup, εβδομαδιαίο ή μηνιαίο, σε φάκελο που ορίζεις (π.χ. φάκελο δικτύου) με επιλογή πόσα backup κρατούνται. Στο WordPress ρυθμίζεται από τη σελίδα Ρυθμίσεων και τρέχει στον server· στα Windows με το νέο Schedule-Backup.bat.<\/li>\n<li><b>3.12.0:<\/b> Νέα καρτέλα «⚙ Ρυθμίσεις»: ΦΠΑ και προεπιλεγμένες ημέρες υπενθύμισης, δικά σου πεδία (custom fields: κείμενο, αριθμός, ημερομηνία, λίστα επιλογών) σε Συμβάσεις, Διαγωνισμούς, Αναδόχους και Λογισμικά, και Backup / Restore όλων των δεδομένων, των συνημμένων και των ρυθμίσεων σε ένα αρχείο ZIP.<\/li>\n<li><b>3.11.1:<\/b> Συνημμένα: δέχονται πλέον και άλλους τύπους αρχείων, όπως XML, EML, MSG, LIC, JSON, RTF, 7z/RAR/GZ/TAR, ICS/VCF, πιστοποιητικά (CER/CRT/P7M/P7S), TIFF/BMP, DWG/DXF. Τα αρχεία HTML και XML κατεβαίνουν, δεν ανοίγουν μέσα στην εφαρμογή (ασφάλεια).<\/li>\n<li><b>3.11.0:<\/b> Συμβάσεις: κουμπί «Αρχειοθέτηση» για συμβάσεις που έχουν λήξει (ενεργό μόνο όταν η σύμβαση έχει λήξει)· οι αρχειοθετημένες δεν στέλνουν ειδοποιήσεις/υπενθυμίσεις, μένουν στη λίστα για αναφορά (φίλτρο «Αρχείο») και μπορούν να επανέλθουν.<\/li>\n<li><b>3.10.3:<\/b> Στις λεπτομέρειες της σύμβασης αφαιρέθηκε η ένδειξη «(με υπηρεσίες)» δίπλα στο ΚΟΣΤΟΣ.<\/li>\n<li><b>3.10.2:<\/b> Με κάθε αποθήκευση σύμβασης (και διαγωνισμού) το ΚΟΣΤΟΣ συμπληρώνεται από το άθροισμα ετών· η ετικέτα έγινε «Συνολικό κόστος σύμβασης με Επιπρόσθετες / Προαιρετικές Υπηρεσίες».<\/li>\n<li><b>3.10.1:<\/b> Επιπρόσθετες / Προαιρετικές Υπηρεσίες: αφαιρέθηκε το πεδίο «είδος»· το ποσό των υπηρεσιών προστίθεται <b>μόνο στο συνολικό κόστος<\/b> της σύμβασης και όχι στο κόστος κάθε έτους (στη λίστα, στις υπενθυμίσεις και στο Excel). Ο Προϋπολογισμός δεν αλλάζει.<\/li>\n<li><b>3.10.0:<\/b> Συμβάσεις: νέα ενότητα «Επιπρόσθετες / Προαιρετικές Υπηρεσίες» (είδος, περιγραφή, ετήσιο ποσό, άρθρο)· το ποσό προστίθεται στο κόστος κάθε έτους και στο συνολικό κόστος και περνά στον Προϋπολογισμό στο άρθρο του, κατανεμημένο ανά μήνα σε όλα τα έτη της σύμβασης· αντίστοιχες στήλες στο Excel συμβάσεων.<\/li>\n<li><b>3.9.0:<\/b> νέα καρτέλα «Ανάδοχοι» με λίστα αναδόχων (όνομα, διεύθυνση, άτομο επικοινωνίας, τηλέφωνο, email), πλήθος ενεργών συμβάσεων και αριθμοί διαγωνισμού των ενεργών συμβάσεων ανά ανάδοχο· στις Συμβάσεις ο ανάδοχος επιλέγεται από λίστα (με κουμπί «+ Νέος ανάδοχος») και τα στοιχεία του φαίνονται μόνο για ανάγνωση· νέα πεδία αντιπροσώπου αναδόχου ανά σύμβαση· δημιουργία αναδόχων από παλιές συμβάσεις· νέα ενότητα δικαιωμάτων «Contractors».<\/li>\n<li><b>3.8.0:<\/b> οι φόρμες ανοίγουν σε πλήρη οθόνη και δεν κλείνουν κατά λάθος· στοιχεία αναδόχου (ΑΦΜ, διεύθυνση, άτομο επικοινωνίας, τηλέφωνο, email)· υπόδειξη «κόμμα (,) ή ερωτηματικό (;)» στα πεδία email· μοναδικός αριθμός διαγωνισμού (έλεγχος διπλότυπων)· συνημμένα HTML, εμφανές όριο μεγέθους (20 MB ή το όριο του server) και σαφή μηνύματα όταν ένα αρχείο το ξεπερνά.<\/li>\n<li><b>3.7.0:<\/b> νέα ενότητα «Budget Articles (Άρθρα)» στο Application Management με ξεχωριστά δικαιώματα create / edit / delete για την προσθήκη, αλλαγή και διαγραφή άρθρων (ανά ρόλο ή ανά χρήστη).<\/li>\n<li><b>3.6.0:<\/b> τα άρθρα επεξεργάζονται μέσα στην ίδια την εφαρμογή (όχι από τις Ρυθμίσεις του WordPress)· οι Ρυθμίσεις και το Application Management μπήκαν κάτω από ένα ενιαίο μενού «PROCURE360» στο WordPress admin.<\/li>\n<li><b>3.5.0:<\/b> νέα καρτέλα «Άρθρα», το έτος στα σύνολα του Προϋπολογισμού τονίζεται και οι γραμμές των πινάκων χρωματίζονται ανάλογα με την προέλευση (Λογισμικά, Συμβάσεις, Διαγωνισμοί).<\/li>\n<li><b>3.4.1:<\/b> νέα εμφάνιση των τεσσάρων καρτελών: ανάγλυφα κουμπιά με δικό τους χρώμα η καθεμία (Λογισμικά τιρκουάζ, Συμβάσεις μπλε, Διαγωνισμοί μωβ, Προϋπολογισμός πράσινο).<\/li>\n<li><b>3.4.0:<\/b> λογότυπο PROCURE360 στην κεφαλίδα της εφαρμογής και εικονίδιο στον Windows installer και στην καρτέλα του browser.<\/li>\n<li><b>3.3.0:<\/b> ενσωματωμένος οδηγός χρήσης (κουμπί «? Οδηγός»).<\/li>\n<li><b>3.2.0:<\/b> νέο όνομα PROCURE360.<\/li>\n<li><b>3.1.1:<\/b> ο Προϋπολογισμός περιλαμβάνει ΦΠΑ 19%.<\/li>\n<li><b>3.1.0:<\/b> καρτέλα Διαγωνισμοί, με ακύρωση και Promote σε Σύμβαση.<\/li>\n<li><b>3.0.0:<\/b> Κάδος, οριστική διαγραφή με ξεχωριστό δικαίωμα, αναίρεση, προστασία χρησιμοποιούμενων άρθρων.<\/li>\n<li><b>2.5.0:<\/b> άρθρα προϋπολογισμού σε πίνακα, με προσθήκη και διαγραφή.<\/li>\n<li><b>2.4.0:<\/b> καρτέλα Προϋπολογισμός και εξαγωγή Excel.<\/li>\n<li><b>2.3.0:<\/b> επιμέρους ποσά ανά έτος με άρθρο προϋπολογισμού.<\/li>\n<li><b>2.2.0:<\/b> αφαίρεση κωδικού πρόσβασης, πολλά emails, επιλογή και ταξινόμηση στηλών.<\/li>\n<\/ul>";/*GUIDE-END*/
/* search inside the guide (v3.15.0): a section (heading + what follows it) is shown when it contains the text */
function gFilter(q){
  var g=document.querySelector(".guide");if(!g)return;q=String(q||"").trim().toLowerCase();
  var groups=[],cur={nodes:[],head:""};
  [].forEach.call(g.children,function(n){if(n.id==="gNone")return;if(n.tagName==="H3"){groups.push(cur);cur={nodes:[n],head:n.textContent.toLowerCase()}}else cur.nodes.push(n)});groups.push(cur);
  var shown=0;
  groups.forEach(function(gr){var t=gr.nodes.map(function(n){return n.textContent}).join(" ").toLowerCase(),hit=!q||t.indexOf(q)>=0;
    gr.nodes.forEach(function(n){n.style.display=hit?"":"none"});if(hit&&gr.nodes.length)shown++});
  var toc=g.querySelector(".gtoc");if(toc)toc.style.display=q?"none":"";
  var m=document.getElementById("gNone");
  if(q&&!shown){if(!m){m=document.createElement("p");m.id="gNone";m.className="hint";g.appendChild(m)}m.textContent="Δεν βρέθηκε τίποτα στον οδηγό για «"+q+"»."}else if(m)m.remove();
}
function showGuide(sec){
  openPanel('<div class="ph"><h2>Οδηγός χρήσης</h2><button class="btn small" type="button" data-act="close">Κλείσιμο</button></div><input type="search" id="gq" class="gsearch" placeholder="Αναζήτηση στον οδηγό…" aria-label="Αναζήτηση στον οδηγό" autocomplete="off"><div class="guide">'+GUIDE_HTML+'</div>',"guide",true);
  var e=sec&&document.getElementById("g-"+sec);if(e&&e.scrollIntoView)e.scrollIntoView();
}
function showDigest(){
  if(!$("#overlay").hidden)return;
  var list=[];
  S.items.forEach(function(i){var s=status(i);if(s.k!=="ok")list.push({cat:"sw",id:i.id,k:s.k,t:s.t,d:s.d,name:i.name,sub:fmtDate(i.dateTo)+" · "+dayText(s.d)+" · "+money(i.cost)})});
  S.contracts.forEach(function(c){var s=ctInfo(c);if(s.k!=="ok"&&!s.archived)list.push({cat:"ct",id:c.id,k:s.k,t:s.t,d:s.d,name:c.title,sub:s.sub+" · "+mc(ctTotal(c))})});
  ["sw","ct"].forEach(function(cc){msAll(cc).forEach(function(x){list.push({cat:cc,id:x.it.id,k:x.s.k,t:"Milestone",d:x.s.d,name:x.m.description+" · "+msTitle(cc,x.it),sub:fmtDate(x.m.due)+" · "+(cc==="ct"?dayTextEl(x.s.d):dayText(x.s.d))})})});
  if(!list.length)return;
  list.sort(function(a,b){return a.d-b.d});
  var rows=list.map(function(x){
    return '<li><div style="min-width:0"><b>'+esc(x.name)+'</b> <span class="hint">'+(x.cat==="ct"?"Σύμβαση":"Software")+'</span><br><span class="sub hint">'+esc(x.sub)+'</span></div>'+
      '<div class="actions"><span class="pill '+x.k+'">'+x.t+'</span>'+(x.cat==="sw"?'<button class="btn small primary" type="button" data-act="renewid" data-id="'+esc(x.id)+'">Renew</button>':'')+
      '<button class="btn small" type="button" data-act="openid" data-cat="'+x.cat+'" data-id="'+esc(x.id)+'">'+(x.cat==="ct"?"Άνοιγμα":"Open")+'</button></div></li>';
  }).join("");
  openPanel('<div class="ph"><div><h2>Needs your attention</h2><p class="hint" style="margin:4px 0 0">'+list.length+' item'+(list.length>1?'s are':' is')+' expired or close to expiry · Χρειάζονται προσοχή.</p></div><button class="btn small" type="button" data-act="close">Dismiss</button></div><ul class="files digest">'+rows+'</ul>',"digest");
}
function maybeDigest(){
  if(S.digestShown||!S.loaded.sw||!S.loaded.ct)return;
  S.digestShown=true;
  if(attn("sw")+attn("ct")+msAttn("sw")+msAttn("ct")>0)setTimeout(showDigest,500);
}

/* =============== ΤΡΟΠΟΠΟΙΗΣΗ ΔΙΑΓΩΝΙΣΜΟΥ, ΣΥΝΔΕΣΗ ΜΕ ΣΥΜΒΑΣΗ, ΑΥΤΟΜΑΤΟΙ ΔΙΑΓΩΝΙΣΜΟΙ (3.20.0) =============== */
/* link tender -> contract (a drop-down in the tender form; filled automatically for the tenders created from a contract) */
function ctlName(id){var c=id?getItem("ct",id):null;return c?c.title+(c.tender?" ("+c.tender+")":""):""}
function ctlSelect(id,v){
  var list=(S.contracts||[]).slice().sort(function(a,b){return String(a.title).localeCompare(String(b.title),"el",{sensitivity:"base"})});
  return '<select id="'+id+'"><option value="">— Καμία σύνδεση —</option>'+list.map(function(c){return '<option value="'+esc(c.id)+'"'+(c.id===v?' selected':'')+'>'+esc(c.title+(c.tender?" ("+c.tender+")":""))+'</option>'}).join("")+'</select>';
}
function tnLinkRow(c){
  var n=ctlName(c.contractId);
  return '<dt>ΣΧΕΤΙΖΟΜΕΝΗ ΣΥΜΒΑΣΗ</dt><dd>'+(n?esc(n)+' <button class="btn small" type="button" data-act="gocontract" data-id="'+esc(c.contractId)+'">Καρτέλα σύμβασης</button>':'—')+(c.autoCreated?' <span class="hint">· δημιουργήθηκε αυτόματα'+(c.autoAt?' στις '+fmtDate(c.autoAt):'')+'</span>':'')+'</dd>';
}
/* in the contract's detail: the tenders that refer to it */
function tnRelated(c){
  var l=(S.tenders||[]).filter(function(t){return t.contractId===c.id});if(!l.length)return "";
  return '<div class="sec"><h3>Σχετιζόμενοι διαγωνισμοί ('+l.length+')</h3><ul class="files">'+l.map(function(t){var s=tnInfo(t);
    return '<li><span>'+esc(t.title)+' <span class="pill '+s.k+'">'+s.t+'</span> <span class="hint">'+(t.autoCreated?'αυτόματος · ':'')+fmtDate(t.dateFrom)+' – '+fmtDate(t.dateTo)+' · '+mc(t.cost)+'</span></span><button class="btn small" type="button" data-act="gotender" data-id="'+esc(t.id)+'">Άνοιγμα</button></li>'}).join("")+'</ul></div>';
}
/* amendment of an ACTIVE tender: the same form as the tender edit, plus a description; every changed / added field shows its previous value */
function tnAmend(id){
  var c=id?getItem("tn",id):null;if(!c||!tnActive(c))return;
  var d0=JSON.parse(JSON.stringify(c));cfLoad(d0,"tenders");
  S.cw={id:id,kind:"tn",mode:"full",i:0,err:"",d:JSON.parse(JSON.stringify(c)),am:{base:ctRecord(d0,"tn"),desc:"",date:todayIso()}};
  ctDraw();
}
/*AT-CALC-START*/
/* Automatic tenders: on / after 5 January every contract that ends in the current year +1, +2 or +3 (and has no related tender yet) gets a tender in status "pending" (Pending Approval) */
var AT_PCT=0.10;
function atDue(today){return String(today)>=String(today).slice(0,4)+"-01-05"}
function atPlan(contracts,tenders,today){
  var Y=Number(String(today).slice(0,4)),out=[],linked={};
  (tenders||[]).forEach(function(t){if(t.contractId)linked[t.contractId]=1});
  (contracts||[]).forEach(function(c){
    if(c.archived||linked[c.id])return;
    var ys=c.years||[],to=c.dateTo||(ys.length?ys[ys.length-1].to:""),m=Math.round(Number(c.months));
    if(!parseIso(to)||!(m>0))return;
    var ty=Number(to.slice(0,4));if(ty<Y+1||ty>Y+3)return;
    var from=addDays(to,1),yy=buildYears(from,m).map(function(y){return {from:y.from,to:y.to,cost:""}}),bud=[];
    (c.budget||[]).forEach(function(p){var yr=+p.year||1;if(yr>=1&&yr<=yy.length)bud.push({year:yr,article:String(p.article||""),amount:r2((Number(p.amount)||0)*AT_PCT)})});
    yy.forEach(function(y,i){
      var cy=ys[i]&&ys[i].cost;if(cy!==""&&cy!=null&&isFinite(Number(cy)))y.cost=r2(Number(cy)*AT_PCT);
      var mine=bud.filter(function(p){return p.year===i+1});if(mine.length)y.cost=r2(mine.reduce(function(s,p){return s+p.amount},0));
    });
    out.push({key:to+"|"+c.id,rec:{title:c.title,tender:"",description:c.description||"",months:m,dateFrom:from,dateTo:yy.length?yy[yy.length-1].to:"",cost:r2(ctTotal(c)*AT_PCT),years:yy,budget:bud,attachments:[],createdAt:Date.now(),sample:false,status:"pending",statusAt:"",promotedTo:"",contractId:c.id,autoCreated:true,autoAt:today,amendments:[]}});
  });
  out.sort(function(a,b){return a.key<b.key?-1:a.key>b.key?1:0});
  return out.map(function(x){return x.rec});
}
/*AT-CALC-END*/
async function autoTnRun(){
  var plan=atPlan(S.contracts,S.tenders,todayIso()),n=0;
  for(var i=0;i<plan.length;i++){if(await save(uid(),plan[i],"tn"))n++}
  return n;
}
/* standalone builds: run once a year when the app is opened on / after 5 January (WordPress does it on the server) */
async function autoTnMaybe(){
  var t=todayIso(),y=t.slice(0,4);
  if(!atDue(t))return;
  try{if(localStorage.getItem("rl.autoTn")===y)return}catch(e){}
  var n=await autoTnRun();
  try{localStorage.setItem("rl.autoTn",y)}catch(e){}
  if(n)toast(n+(n===1?" νέος διαγωνισμός δημιουργήθηκε":" νέοι διαγωνισμοί δημιουργήθηκαν")+" αυτόματα και περιμένουν έγκριση");
}
function atCard(){
  var can=stCanEdit();
  return '<div class="stcard" id="atCard"><h3>Αυτόματοι διαγωνισμοί από λήγουσες συμβάσεις</h3>'+
   '<p class="hint">Κάθε 5 Ιανουαρίου (ή την πρώτη φορά που ανοίγει η εφαρμογή μετά από αυτή την ημερομηνία) δημιουργείται ένας διαγωνισμός σε κατάσταση <b>«Σε αναμονή έγκρισης»</b> για κάθε σύμβαση που λήγει το τρέχον έτος +1, +2 ή +3 και δεν έχει ήδη σχετιζόμενο διαγωνισμό. Μεταφέρονται: όνομα, περιγραφή, διάρκεια, έτη. Εκτιμώμενη έναρξη: η επόμενη της λήξης της σύμβασης· λήξη: υπολογίζεται· εκτιμώμενο κόστος: το συνολικό κόστος της σύμβασης × 10%. Ο διαγωνισμός συνδέεται με τη σύμβαση και δεν μπαίνει στον Προϋπολογισμό ή το Πλαίσιο Συμφιλίωσης μέχρι να εγκριθεί.</p>'+
   (can?'<div class="actions"><button type="button" class="btn" data-act="autotn">Δημιουργία τώρα (για τις συμβάσεις που λείπουν)</button></div>':'<p class="hint">Μόνο οι διαχειριστές μπορούν να το εκτελέσουν χειροκίνητα.</p>')+'<p class="hint" id="atMsg"></p></div>';
}
async function atRunNow(){
  var m=$("#atMsg"),n=0;
  try{
    if(window.RL_AUTO_TN){var r=await window.RL_AUTO_TN.run();n=(r&&r.created)||0;if(n){if(m)m.textContent=n+" διαγωνισμοί δημιουργήθηκαν. Ανανέωση…";setTimeout(function(){location.reload()},900);return}}
    else n=await autoTnRun();
  }catch(e){if(m){m.textContent="Αποτυχία: "+((e&&e.message)||"");m.className="err"}return}
  if(m){m.className="hint";m.textContent=n?n+(n===1?" διαγωνισμός δημιουργήθηκε":" διαγωνισμοί δημιουργήθηκαν")+" (σε αναμονή έγκρισης).":"Δεν υπάρχουν συμβάσεις που χρειάζονται διαγωνισμό (όλες όσες λήγουν σε 1–3 έτη έχουν ήδη σχετιζόμενο διαγωνισμό)."}
}
/* =============== ΣΗΜΕΙΩΜΑ ΑΝΑΝΕΩΣΗΣ (Λογισμικά → Word) (3.18.0) =============== */
/* The note is filled in the browser from a Word template (.docx). The built-in default below can be replaced in Settings (stored in the WordPress database, or in this browser for the standalone builds). */
var NT_PH=["Σημερινή Ημερομηνία","Software Name","Description","Renewal Date From","Renewal Date To","Cost","Κωδικός Άρθρου","Περιγραφή Άρθρου"];
var NT_PH_INFO={"Σημερινή Ημερομηνία":"η ημερομηνία του σημειώματος","Software Name":"το όνομα του λογισμικού","Description":"η περιγραφή / ο σκοπός χρήσης","Renewal Date From":"έναρξη περιόδου ανανέωσης","Renewal Date To":"λήξη περιόδου ανανέωσης","Cost":"το κόστος ανανέωσης (χωρίς ΦΠΑ, χωρίς το σύμβολο €)","Κωδικός Άρθρου":"ο κωδικός του άρθρου προϋπολογισμού","Περιγραφή Άρθρου":"η περιγραφή του άρθρου προϋπολογισμού"};
var NT_KEY="rl.noteTpl",NT_MAX=2097152;
var NOTE_TPL_B64="UEsDBBQABgAIAAAAIQCI6fEprgEAAPUJAAATAAgCW0NvbnRlbnRfVHlwZXNdLnhtbCCiBAIooAACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADElttKw0AQhu8F3yHsrSTbVhCRpl54uFRBfYBtdpKsZg/sTtW+vZOmDSJtE2yDN4V05v/nm5kQZnr9pavoA3xQ1qRsnIxYBCazUpkiZa8v9/EliwIKI0VlDaRsCYFdz05Ppi9LByEitQkpKxHdFechK0GLkFgHhiK59VogPfqCO5G9iwL4ZDS64Jk1CAZjrD3YbHoLuVhUGN190d8NyZuDgkU3TWJdK2VK1wZNgG8VeajCL5FwrlKZQIrzDyN/ocVrrISUq5xQKhfOKGFXiVVoZ4WN8JEm6pWE6El4fBCa0vin9ZJLmy00SZP9PltIbZ6rDFp97ea8zSAEWpWukjaihTJtBztBzELPwZP0+CStdTdFwGUF4fgIjW+P+oBIiiEI1s7dDJ8wfx4M44d5N0luLRqLQyykte6mACMHgtg4dzOUICT48fERGuO+AJP/A6gXNsgEGuO+AANMoC9AM6nz/17BAAD9V0AFxbyCIRDW1t0USDcFNL+Hv44rm701KfXJWxfoSPF/aHxzUNTqmFp24FF1fHLakuR9cIdQ3yoS5LbifHW0zb4BAAD//wMAUEsDBBQABgAIAAAAIQAqoxp78AAAAFECAAALAAgCX3JlbHMvLnJlbHMgogQCKKAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAArJLBasMwDEDvg/2D0b1R2sEYo04vY9DbGNkHCFtJTBPb2GrX/v08GNsCXelhR8vS05PQenOcRnXglF3wGpZVDYq9Cdb5XsNb+7x4AJWFvKUxeNZw4gyb5vZm/cojSSnKg4tZFYrPGgaR+IiYzcAT5SpE9uWnC2kiKc/UYySzo55xVdf3mH4zoJkx1dZqSFt7B6o9Rb6GHbrOGX4KZj+xlzMtkI/C3rJdxFTqk7gyjWop9SwabDAvJZyRYqwKGhSeV1pdr/T3uDixkCUhNCHxZaHPjItGy/9c0jzjR+c9JIv2K/ytg7NDaD4AAAD//wMAUEsDBBQABgAIAAAAIQCCCKnfUx8AAE7TAAARAAAAd29yZC9kb2N1bWVudC54bWzsXXlvI8eV/3+B/Q6EFlgkkCX2fdCeCfrgJfE+JFFBEDSbTbLFZnezu3kuFvDtzSIJYASGN44D23CSRbBjG5NkdnzuAPkAze+QT7JV1WyKpEQNRyPNaGwR1rDqVdWvq9579d6rqi76lZ+MukZkoDmubpl3tvBdbCuimarV0M3Wna1qJbHDbUVcTzEbimGZ2p2tseZu/eTuP//TK8NYw1L7Xc30IgDCdGNDW72z1fY8OxaNumpb6yrubldXHcu1mt6uanWjVrOpq1p0aDmNKIHhGErZjqVqrgueJynmQHG3ZnDqaDO0hqMMQWMISEXVtuJ42ugUA39iEDrKR7mzQMQlgMAICfwsFPnEUEwU9uoMEHUpINCrM0j05ZDOGRxzOSTiLBJ7OSTyLBJ3OaQz6tQ9q+CWrZmgsGk5XcUDWacV7SpOp2/vAGBb8fS6bujeGGBiTAij6GbnEj0CreYIXbLxxAhstGs1NINshCjWna2+Y8Zm7Xfm7WHXY0H72de8hWZs9ljwOD6qjTzD9cK2zia8C5rLM8OCuBZ1NAPw0TLdtm7PrUP3smigsB2CDC5iwKBrhPWGNr7hVFtn2uRADKeAm3R/JruuEfT8YkQc20CaEGLeYpMuLD8z7EkXaPDpgy/FmgXm4hsanxCAOAPAqNqGziLE4GYYUfV0dkMcfcNpFeIEUoE4+ilj8Q1t4GpnFgAa/SeCIMiwH/ALNl/Achteo/1kcKGMorCt4iltxZ1PmgCxuaEhCBGpBcRAwQxLndsziKk9GdPoOeC4uyBDu/V0EzXpWH37FE1/OrT0qckewuDpCbBmE37RCLlP15lyW7GBJe+qsXTLtBylboAegekbATMwgiQA/wWKDL9QUhshOtSfWaJpwESjH4EmcesuCALrVmMMv21QQMVsxVHSYA7hGMGzAilsISpwoR6kkgmCYxMkAagxEHA2Sne2MOAoMEwg56SCA4lxiY1z3Jwoa02lb3izEp6dIxQWEFAvCg78cm1FBSMGlQwd8p1kMNgCZkp9OGyl71lbkSisa/U9SM8MwNBiAwXoNTYrcQIwJ2GZngsKFVfVgUKIltWJCKan9/oKRG0LpnuGjADqwZc7CZGJENqdSBBxmdgPKVBahjajGgoaCCrQjJ1kCdGjs+5F52N2zuXgVY7DtAqOZTWfflBh58ESIvBiIGnHFFNtW06kobteBQkBpsR5KgO0CqdIbJYtnWZdvWsbWsFyUd0gXBhoKU1vtYHKEDTO0CyBg/CrrrV1swHiAVQRGiCtESSVMVCDtClpBugpvhVRDMMa5sGyyFBsRID6Push1GQao0WCYqRZgdbQkYKzJCFLMoV00Y7N+xUZoaeM56plx2zL1WFQk5r3N+FYIKhRLaPfNYP2iqG3zLuG1vQAx8IsSs5bL2EdrGDBydhyFLsdwIFq+WbT1by7OwTBMRgWQs2oS8gHqAmYt3B9B5diPI1zDL0VUcEoeJyiIOODoWjNpqZ68aBqMH3gTAWSQP/WF0Y9BL0pA71ygKkByQrAv7PlQDmFNcCasuBEoBsGc9xUumCuFnTV64MWeFhHzQ2ScFi6mnBADahJSgwNdEbJAMm6Yah8iUgriG9MS2qDuacJrg3Gh7QA6e7FHXjaxy5AycDzRvrOWR/0eCg74BlAA6mYPe8WSD01mjkAEoFjhhnAipm8sFV5EYhfYaWgiQJ7EIjnHPbOSY5jDdua0nDnXF+GQdmlftQN3U7ohgEfAdMRJ6Z163B6g/nKIq4CZcu43iwV8PXfCE7AMJ4QdyQak3YojI3vCDzF7rBYnKUwisMlXPp32BpM8r4LFUsxZFsPhbxp7LuwCsNm2rXgaaKoR+E36mM0GAXsrOuoJcAgWBFkPEfz1DZMNsFow4LoQgnizSk7YM4FLiJSH2bB8m/m+iDAqOl04Tfo46qBClh0wbSPnja3HddLalY3AhOA3aBLCF4ZgJHM6oZ1IN20YMeCpxjmMiUakNAQYKdnSfCHyhbmxWIeGgUgH1efaCXNWLWottKCmouq2Kp3qDe89l1k+xYJs3yIsQx51rAuQQaeZhFzRlkGPQiMR+BEkBOcez/oEJd8+OMCoxclPBnGvLv+B/4f/Y/9T/zf+u+C9Ef+pxHwzyf+b0D294D4qf9hQHwXkD4ByT8A4gf+n/3fR0Cz3/nvA+KfQR1I+JH/wa7/0a7/7q7/8e6P4WMQlyH3YCQEH7gciBIERUhinF0ORNnZ52kC0eXq36tAdEmm5k5SfG4h59X0GGqJVCuUquWIkCylpWqmUi0JmUhBqGXjuUo5ki8lhVy6LFTS+VzkR9KusFvYzW+kXyzL0wQtwEDwcfpFykyCOlWlOc8WljOL+rVcfY1+XY/ODGMq8LyCoyvGOnGQzDniOCW2GyFNNTTFQZCWYTmhwg+R+7qzJaHPhUKEfHXbSsMaIhbXjb5TUlAIzkFnBGlwPQCezuGnBPAkgsXgJ6C4I7goXciPl/OdwAOiZOAGYVIxWuadLc+ALIeNnFZdMhxUFDA7QAhKFcNuK6dlTACO1PC0bZhDAzo7p9YYsYRM4glkbC5rxNYo2TlGjE7gshRfVLITdS5MEOJrzrXaq5uge3M39oPSvfPsOVSbW4m+aBJFUdenIHD60H8PxFIweHo3AoMpGF2BQOs9kPwtCLNg9mP/ow3cHI2zOMtQzAYWaGY/NrVAy9Wv2QLNlHCuqPP8qobeqtzVOjAJZwmOhtHMgvrgvCBRAgu7epUO7AqipI31ZGbJbgV/Ge9xy+Uns+jv+p/sRvw/wVV0bMlmL/AePjMBOA9t0q04rlMcGL1LULtgnfZSZJbE6Q08KZZgSU4Sn2ZD4mlM4a3sn1b2F3s6Oh4XMElYOfhkSUwGf1ctXp5jefzW0916uu+fp1tdlqy4OEnAhMSavbRbOVyRHOApVwzuYGt3tmxHczVnoG3djUVuY4/nPkE+nr7mP5r+5/SN6Zv+Pf9b/4H/nf8oApb03/qfg7/7gPxo+jokPJi+A8q+8r+e/tr/LuL/cfqq/xA0fjB9w/8KkjYIWWgyQYmCvMniH5eJBCmeL/7zfNpS9VufdsOCGZzlE5Qg08uCJ0URj9NoL+hFXbbfSvw2irlWLiMj/b7/4UWukpXZOLNmytxK4cqk8J7/ye46Mdzy/Dp4vi5uvDBwxEmG5FcjhxnxCiVTl9yLRLSoOT/doLvPpWfn89f/1H8II0EQ3H0FIr7PXzBuA2sZdP4R+H4IBvCFf/9nt/P2+c/bCPwsCWLNKoHGGDYhrJzxnLtKkEkSw9csEkPiQrC4XP32jOeGrRJYjiTASoFfFjzNxAVeoE4Pgs8xO49ZEJyao0u8TXd6ZFy34I2/q1SFmVm7DamfpRKud3z/BWK8D/13L96YYghcTiTOtzm3ArpeD/KCRSLvTd/0P4f7Y/59+FLyd/598PfZ9BeA9DDifzp9C2T/NotUPp++HolG/Lf9v/kPYAO46fbfoAy2fwgzvwPV/up/BbLfwl04/9H0V5ELI0sZODssePvleswVfHTZanpDeA0np3S1F0s8y0Hh+S4JS3AUQeMwmlhwSefvWK53SUslL6ZLOp89DI6xIklTy+zBSYLGZO50RwKOWGAIglx9m2uF+JjbmTePZwtvlRNz0sJb5SFx46uXV9GppduVFz+5q8YEw9McU/E0CTxOMz1ElNqWrmqRktbr68D63tka2i5i/LO6ZskRFHal1yxJHidwCm5AL16zpMREnE2I6ALy01+zXLgXGQz1lQvuRV7yxiUNgOHbIZvft6R5CswLLLh5NR/P6l1LisQ5DN23pHAeh2IBKYKGHKvDUg6nw6bwwmXOMrVZ9vSiJc4zGM7SJAlv4KEbfBkwEyNk2PAZXbdE+v3871Ze4ko95JIbG7rQ0oIEGIFkBv1WR2bZXr7uiJpUxraG9D0Y9EIbmHmK63rnaM36q3rQ4CLoza7qRYbAhTIEQu/aQHE8R0fNXcvQG+HlyzC+XIwtZ9BL9RyrbzYCaHjTMx5mPEU3ZpnZbcDzb27yGB/n4hy1QxFMfIfCZHlHSEjUDpMAuiyTsiTJeHhzs603GpqJxvLUFzdXLywuwaM+n7nLGco0kC78wQQg31DySG2+13cb544J+agEsPl1Re1AtwTvFd99ZYA8f7BWmVt+nCUSPA9vnkITFRokC/AR5n8+gnr1cxfHCAb+PNkYRg2hKY0pdaBpfU97ebID/JA2is1908sD3Z39IlMMJQ3t5a5r7UDbuINgYi66nh5QIfd2bM2BL53HMERro9GvEFFz6C1B/7UdeGE/xtveOUWeZZ/bBF2BX9MGxD2e1Z01C8e4A9ikT4DrV4zT4a6psBMKGEV6y7WA6/V0dS1IWHwOxObMQRXnAFC/FisvFWxFmkgJdwArXqJ2Mdr2gHOzgCejFylWrNUcwd+lubNVjbuyKBYFsSWkBfBJFyWiNdHL0RbI5OMi+LcC6YdYblA3Swb4ax6kjOHxUa6RMdtefa9cKlZZOSuKiX/9l5HwMo+dqMNm+nCvyrBFoWUwtX2sjElWKil2KqP9zHFyRFeS7cEJnSeSWLl0mLMmUZYz+/xQHXUS2WSuxfT6xV6GKQkIEHPpGqM79MDjDRnfG4pyepjP7u2n7JRhOwy/32ykTsajctfRy83aZLtaNg8LNVboN3NppbHPZON72REv2HLUkhFg3qg4ltM+IoxEXDe6ap4oNXLeiUSP5ARvS/3KuCaKdF1n6kXKHVt7ZIs/LGJjYL0ykxa935COjP3MyUA95HgSAZar+d7R0JzQstMyU95eZZR3i834frrCyl25XJWU0ZAt9UyO5dhjt1vK8hpx0C1oYo7q92qDinfIngz0kxafi44R4J57pKmZHtbbPpSZLgfYL0ejw6xwVlgCFS2nojgU1l4RCisD6UfknlFPZQcZc89AgPVUvtPJJnrDiZBt97flQa1Qah4lleFIP6no2ydYcmCnXLmmd7PKIVYbE02HyFIFMWs69Wo9WuQpI9qMtrM63isFPTxIE27eY6p7rcb2sS63ms0Mp3USRqJcHxxglkXF61J7khxRTT5ZatQJOpV1a+2eIQ2TtOFkenxdP+6MDvN6r4YACaKmVxyF6NSyfdzAvSJYxkfrhS45HNZy2AjnWnWKFhpFUGTTJ1E3IRIVLFFkS5hZycUPyBPG4ptaceJYuB5I+VDAqUR3u8gpuMJti4N+tBFtZOvEXo3u64V6OxnteCal9pLVqOaQtjoYSuv4jADTRbnTt8qsN4wLQqIow/kBC49Te5MMUR3XsdKgNqap+uHYrXLJMgZ4PagU5ALZ5mysc7S/J9p9S+2PiUMRAU76k7GgON6eSKnjcZ6uNB2SyDEEm5Vy6aKWq8c7gwoWHW+bNc2stJSa1d82VC+RqR2NJOcIb5a9aCFHRLfLrWDqlaKCkko5IDjKtbW6R0cPLb6t1lUqLeaTo/TeKJWdtA9q+WxN6faMVu64VdJqsrAtVvqd+GGaqRq83dK77ROGYRBgT/MOcuWUXdxvZVW2x2tDdr+ipgb5XkEHvuUkTh04x1r6UGcOdJ43DruTKlaoxmuO7FRaKb6VrWVwRmkc9eR+OuChQHeiVFpxynsdNr8nUQftNo4bRrm1bXeJI7400QrCsFTROqauZk72RwWucGBibH1A5LNmFd/mmsNW3jIlKlpHgMLRaCBZSbOK6fIhodg93RiqY3JPHFJsfDCw97d7VYHS0qXaIW1NErI9YONH2eL2kVol1FGxd1Rno3ye9XodaoIAq8eNmqgSRlaUU5nhcapzjB/m+/2J7MkCV0uc7LUyub3yQVNjx+TEPjjO69vdA5Ou2dpBGksWik5t1ClPkicu8B0IkG7vd5sOj++lmWKOyXG2mq1qx0ZSK0iMIHBJPq9NUlySOZ5wJbVJuZVcTc+MKFLjy2bqAIuXmaxzkuUdw2yeBIB1oxolqWwXv8gwSPV2Ue3hQ5hToWEonOpqadAg6PHxUa2PALUk7lbSvFhxs8N4/Igs5yZiUi8RznG2XxXao17PLh8Q4xZVFCsapZ+M+lms4WUw3m73awUTK0W3o726kmG4gywCrG23uH3u5ChZbOtslUw5tf0B7Qi9YrqcrmdksiLY/URSrBcmdPVQtKN0dVs5YeMHvVpJ1ou2exLP2scN6TCVVnAEmKLaFb6Pp9qTVJuIWxPq5PCgj9N9tz9K5PtDKnPQUpUkv2dS25UqIzfrpHEijwp5R1Vy9QnVj1YMELfZ24fm8SDQQyntcRpXaw4OK3mvssdoRTPXSWGScUx3jpg9ybLUUtZusuSYcZmhs93YjkZbYN4XolFhKBbLw7iUKQpVQagFxkGC3JXigmdlqc6AgoJpC0VBiCMBnP2sdacJMRModjHtCRuY+qWPxAG62FS7B6465vroG18LeL45WwakwMDEjmpmB8eVvUEpyZ/AXgY+BXT1LOj5erf0EePxOWiSJ+uhk2ro0HiOAHOryaAmABbkCUwlilVEQRVhxOpYHW042zphbPiLKQP4Ey6AGoHR8Cyk9cAKoCNq3lADFrQdrpKDgDnYgEIRNAyxT+NqmDu7PXTh0S2PsQmMXdkP3GS7dGk/+IXdQ73kT6xd4Tb4BqcS6CBi+rb/CL3g8bV/LwJfmIjAN30j01cBCX3d87+b/iLif+l/Bl8DjvgPUNGX07f8b6e/jkCIyPQNdEwBCr5BrwI/moF+Pn0DNAV4oNl9/+vpL0H5I9DwS//+8nWzNUqUIGWMEza62PTDVaLzeUdgAsYScCdvkXcYMIcEy18/78x+N0joxtnXJ0Bhen4ZmgsHNW9yO3k3mbx/gG/nf7N8FDj95TM6CHzig7/nwKGfvRRYMmBxXgVs+gJas3eAUXqIzmG/nZG/8h/4X0AL5X8FbNT0VcBC2ApebPgIVP4rOqlFDAYlkNeBuYOnrq/Ck1dg9i5kuSgyvHgVQ14cmqy5qqPbcEPlZjEcMPP/oKUHDAwtPWBv4CRgCp18B4wGf6+BDOT9w0BOM+a+Cd/Vi0B35H8zfWv6H/5DQJv+AtK+gSfi6CLKW0g28zsoUEj3ASHIBjXOCBCKazfi/xmeoT/wvw6q/SqofHHXwePeBj2FV2PgPZhgCKDkHnwkPMFf7nrQm9MDfjRE4B7fOO+c/97COT/Sz/CcPxxFgD3zn9/Cp32GOvUj/McgGVzL2d3Am5KYJMbx+EY/+fOcvaluQvcAdz1BB4nQbdw4H0sxNM0QaOQLHKVpTEwkMHjCeOtjX2Qfu+bdsPfPTvB5FH0vtAHAvsE3j4HTAdP70drXlW76O+lxgiXj8LdOr7pniz0oaaY2VIyIDBaXEXhkdIO59bPIP179zcUe/1nz7KK+CBROkvz19uX8aaJd+IreM+FRxbrJivTM+vb4voDg528oAnkDmLH7IPz5wv9fGAKjcAcFIg/D4OWz6TsomJoHNShmfm36yzAmDmOd8yKZldUKenERfMFwKozwUD/gXkMQpCMiiL5WbhjPEDeKegQ5niASq7+ecQ3v7dlluMMWcjqju15h/u7Os/SZ5/OBpkRKwBj4uvLiC3pEguUJ8fQl5ttY5dJ8f65zeE2sgjYJvoazc3Z9fz5rlyMYSFpaw6xu/63EM3D9BGrCZfS92YIIPORNuC6Cq5nv4HYhWjYFzf6CllJolYdWzW+gVTaa3DfYRP/j9XsXOnpaIHn2up2YtNaJoS7QjMgGl5aurwvu2hDjRgRkaNf5s2DL5k/+x/67N8izbuKhWC7BSDi9sor84XkoEmNFESdWfxpCjuMcK8ODpFsP9T30UO/DyPId4CWgN/na/xw6ELg7CNwOXFhDN4JCRLgV+Ha4J3e6TxsB/uc1/0u4pfbCLrIxGmN4/HqN+BrufwB8MAy5YYjw+k1moP92KObpW8Ea/O//81Ng7IO76X+FW8lAPYD2LNb7+zcvmCtgMJaWZfj/lfphuwKMZwSJ5Z6BS7yRu9KbMQmnKFagxJVL0jdyP/+He0r78eyYK3Bhv149KfoMnVm9hvZEPp+9RvFSBO6ogHj2a3Qu9C067kH7J+goKij7C9w8QW9rBBhwCQYfBL0p8KSzjZmVM7YHwckXXPXBgzGIjkjXcXo139eBXvx0d+keiNU32j9a2W46XbpuvrP0mNPczWJznpSZ+CZzjOEZkYbbTGem03IJmk4sifG89AJOpzV+i4On3MhkPI5NLE3wJLdiitbzbrn695F3hMglKDEhL/MO+D9ZkFYOETkZi8dXzfh63i1XR7ybkRZ4d5NM82woz8Q0X/DLNPPPP17908X/bWBBSJIh4hi1YkFwDuPo4AdOfmji/X8AAAD//+ycWW/bRhCA/4qg98R78DQqAzwDAylgOEafDBSKRMksFFEgaTvJk5M06AE0QFD0JU8FejylLdwiCNw28D+g/kN/SXeXpERKorShrUiOaPgQh7vUzjezs8PhyvWdT063/T2f/bG9fhjUTrebQct1G3XNd5u9Ojk+0vpB9rgVjA62aMdes98l4pNmr1F3erfu7DP51ujCYe3hg952MGi2nEZ94DuB45849Z3a+Is2DuMubCTkan7gtvcbdQAkRTYlmb4vE+35TKhKuqjVVz36onGvzSCjn4bfRH8Pn0Svh19Gb4dP84LL4fPh05wO5PeAXm9QO4XC9qDpN3fbjbqMBQwMS60zaeg8DJk0+RqZhuqsmMCy9NnWSoWm02ke98Lp5nsZERtFrNwXrVT1+154lBBZLlHKIXmD1dl0J/qRGOpy+O3wGTHW6+jf6E30jhwTK/5MDn4nP+fMikzwZvgVOXtBjPsieleLfhmeEYM/IeJn0QUVcdhZUERDNCWLw86qIqsQzzJp/gwzKUIQyOqamHS26lDCuiLIdNyLVC/25vyZm6K6oCOkmwaP1SdUj6eEakBLNT4eHtgCNkQKjUoZHsC0LCSIZo4HVAHQxrNgUbTLN2c8ElGGBw3iLht9z+2TaI4lQHvQg/3jHhE0j0MvUXMmO+84pI3vnvTSk2BzYubsdTD6OvqLrXoXJBq+nZtuyKZsSQUm/SAa7Gytf1bxkiwur6N3LKcgQNeaZ4EOWzXiFP9E59Gf0Xkt+p4o82JKlYKlwjIgEC2pbLycSGjnx4cMqeuKD1clHjxOL4rQSGTQK+WFZaNFjGd9Rkod4r+zX5f9PW8SWQiKSJntRzcD1Dzt5s2SjXODom+OwCQaAtYli5K85sA0I5GrAlPlkQs9EqsqUJAxcVclWUC3FXFcJaB0JwoH71sj+MicbzZO4oEGUoyJO5Or36RuKE5ZVDUVcpU7rh4vN5QxAAKUTEBvmzOMkaQBUYdoXgRYxFgWkYpHOVEBY7ffpkidDukiAoEB7rh+EN5lyGWU3hqPAbecfuj467okrc+g5lTG5yV786y8VspxLa23ORZBSQUQGVxp2Uw4eUd/75UxNwXkOMYsmAKrL7MnOi9/BKzM/pKWMoZPot+ic1pLfzV8PjyjxaLonNXbv+MxsokEWzHgBhp5rYw5/1FjUWC65nHmnOuH4Vn0B3OvS/LqkuuBm4R1pNg29YdF3mQgLE/V14pL8vnmzJsSUZE3kQX8/bxpWfVnzoTDtqAiWTYHuqs/zbgp6HiXRT7E0Fagrsk83lkhLodYMG3DsmSxQrw0xACLmm2xKkSFeDmIRVkQMFAFDsQT+c8ixDNu/jYUsaQgbOsT99cV4mtEjHQB2ILOc/9WIS6HWLYMTbMEnqStQlzSi0UTmCZL/SvES4rFAgSKJfFsDKgQl8yLbRthA1eIl4cYA0FHts2z2bfKi8shlkxkibh8jQJiCavjCmKFeBoxEHUbQ5NrK3PeYRchzjff5DKQpCJREHjy4gpxyUAhQ4xlhSdQVIhLLneipdmqgCrEy/NiDUq2ZVaBYonLnYJMrBg8ZaAKcUnESFMF2eQpyRenwBXNNHkQgYSgRm+4FtEs9s38mU2OsLZpauQOtqJ5LUUGSZAUlWpS0byOOzGoiqpKuVU0r0xTxJDMdYPnkVpFc3HcNA2MEeZJmyZoLkqbKsTpcweoa6ZiVMn/EnMpYGumJfGs/lXFthxiLJDUXzKq/ThLXNkEQSOxYuLRDiZ4DA1SaSZQ5P/5RIy4+ANEFpJ0fWQkhjgRZRCvG6TTyd2pmU2/H2ZEHLttd6JX0WV0MfHPRVY/9MwQZ28Ivp3fCjzbI2WERJUMPe+RItRtDaCx+1ENTUWWjXEciNWeEM7f052scxmPXOnm2g9jQzqvp2yYCLNudnjYcXtO4J8AeLh7cLi3v/uZdmCRl5+bXuv4gUPGcYiKfHCRfVajUuFwV4+7YA/9rRoCNwyydOMg7x7URi49M0QFTivc48aeCO+RTlSa+YTDkdNsO/6+03F8p99ySMPw0YCMxTlx+vWav+2SUOfvtpVEmaLm7TioZXqoSY+O54UcbwDT+FXUfvodIFwwKJYaZTukS0XRe0x1wEmHQfceNewpsSBUActCjqg1FbpVJGnxaZOaI/QG5ASS40zF7R4R4FCAbEcJid+h96BRV0SWucV5XHoyVoKsNoBuuUiGODrsHofsMKU06OqeT9pTz/I6ncAJbZ9eetDsOsyuZByp0wVuv9tz6FWCx406LRmkDofYQcvreX7uY6Z0ZOV7x2qW78+ole1O50fKhl6MnKeMkj4ySO3V9lp3fJel02Qd3XPD1lHy0dv4IvH8Yi/ve+1H7EU7mZE7/wMAAP//AwBQSwMEFAAGAAgAAAAhAOzv6L9mAQAAWAgAABwACAF3b3JkL19yZWxzL2RvY3VtZW50LnhtbC5yZWxzIKIEASigAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAtJbLTsMwEEX3SPxD5D1x0kJ5qGk3CKlbKB/gxpMHxHZkT4H+PaNWTQ0Uw8Jdzo1852heynT+obrkDaxrjS5YnmYsAV0a2eq6YM/Lh4sbljgUWorOaCjYBhybz87Ppo/QCaRHrml7l5CLdgVrEPs7zl3ZgBIuNT1o+lIZqwRSaGvei/JV1MBHWTbh1vdgsy+eyUIWzC4k5V9ueviPt6mqtoR7U64VaDySgjcgJFhyFLYGJM9tnKdkxBJ+HCAfxySojEGfYBePgwRRARwgUnPdAWGvBBmuYzK0ikbgAKBAtmIn5ulLD/XvvRidfhrCvYgK4HDTgd+JbRyexpj59VqtwFLvDwiDFKSYxKQALTUtgVeHvRKuRNRSHN/LUZDgKjbAtzIMUrgOUTGQ3nqruQ134h9XMjt9N8IElzEB3mH19ONQemKQ5Pb0Ryo8mHnUWlRG41KsOm8sBmnA4F/+B2afAAAA//8DAFBLAwQUAAYACAAAACEA/ywwhcICAADyCwAAEgAAAHdvcmQvZm9vdG5vdGVzLnhtbLSW3W6bMBTH7yftHRD3qYF8FjWpsiWbejet2wO4xgRU/CHbhOTtZwMGVrIKqMaFMcecn/8+9jnw8HghmXPGQqaMbl3/znMdTBGLUnraur9/fZttXEcqSCOYMYq37hVL93H3+dNDEcaMKcoUlo5mUBkWHG3dRCkeAiBRggmUdyRFgkkWqzvECGBxnCIMCiYiEHi+V/a4YAhLqSf8CukZSrfGocswWiRgoZ0NcAFQAoXCl5bhj4YswT3Y9EHBBJBeYeD3UfPRqBUwqnqgxSSQVtUjLaeRbixuNY0U9EnraaR5n7SZRuodJ9I/4IxjqgdjJghU+lGcAIHiNeczDeZQpS9plqqrZnori4EpfZ2gSHs1BDKPRhPWgLAIZ/PIUtjWzQUNa/9Z42+kh5V/fWs8cDZsWj3dPcAXlUllfcWQ2FXuB4ZygqkqowYEznQcGZVJypvqQKbS9GBiIef3AnAmmX2v4P7AVPtXaTtU29ACh8iv945klfL3ib43YDcNovEYIuHvOa0Sok9wO/Gk0HSC6w8sPhYQ9AArhAd+LCxjUzMAarPbcNKBaWU51a4YTtoG1h9YA9+K6QCifBQimFsd5mbcOywZqSgZh7N7BIwvVDCBskmaihgPLASWuOgQqwOWMdTUM8PE44K2bIBX0tlDfvpYon4XLOctLf0Y7akt2YX5exrBqhO+W4Tkx8Q8J5DrSk5Q+HSiTMCXTCvS6evoDHTKHTCtPsjmVnbxpbSb81N34sx0otwxJdHddf4CnSJUV66JEnMooGLC1SaTTzO/fJFrz0Voxp60MVgdv+z9feCWVv2NVca6ri/jqn9Jo59b1/MWB3++PzamA45hnqn+yA9jWi6D9fJYTihM06hxwO4BlEbd8rK10m8uAzGqUpqXX57nt0vybqzI33857u/Xi/+9opvC3l1d50Hu/gAAAP//AwBQSwMEFAAGAAgAAAAhANgvkZa/AgAA7AsAABEAAAB3b3JkL2VuZG5vdGVzLnhtbLSW23KbMBCG7zvTd2C4dwT4zMTONHXayV2naR9AEcIwQYeRhLHfvivMwQ2uB8jUF0JesZ9+rbQr7h+OLHMOVOlU8I3r33muQzkRUcr3G/f3r2+Tletog3mEM8Hpxj1R7T5sP3+6L0LKIy4M1Q4guA4LSTZuYowMEdIkoQzrO5YSJbSIzR0RDIk4TglFhVARCjzfK3tSCUK1hvm+Yn7A2q1w5NiPFilcgLMFzhBJsDL02DL8wZA5WqNVFxSMAMEKA7+Lmg5GLZBV1QHNRoFAVYc0H0e6srjFOFLQJS3HkaZd0mocqXOcWPeAC0k5DMZCMWzgr9ojhtVbLicAltikr2mWmhMwvUWNwSl/G6EIvBoCm0aDCUvERESzaVRTxMbNFQ8r/0njb6WHZ//q0XjQrN+0MN0a0aPJtKl9VZ/Ynd13guSMclNGDSmaQRwF10kqm+rAxtJgMKkhh1sBOLCsfq+Qfs9U+1dp2523oQX2kV/tHcvOym8Tfa/HblpE49FHwt9z1koYnOB24lGhuQiu37P41ICgA1gQ2vOyqBmrioFIm92Wk/ZMq5pz3hXLSdvA+j1r4HsxF4AoH4QIprUO+7DuFywdmSgZhqv3CFlfbHCCdZM0Z2LcsxDUxNkF8XzAMkGaemaZdFjQ5g3wxC72UO4/lqjflchlS0s/RntuS3ZhP54GsKqEvyxC+mNiXhIsoZIzEj7vuVD4NQNFkL4OZKBT7oBt4SDbR9mlx9Juz0/ViTPbiXLHlkR3234EOkVoThKAmkqssBHKBZNNp4lfvifBcRbasWcwztbB42q1XrqlFa5YY63L6mdd4YM0+rlxPW+286dfnhrTjsY4z0x35Ic1zefBcv5UTqhs06hx0PYelUZoZdlWyq8tgghuUp6X187L+wV519bzuFvAKf/v67kq7Nba2r7e/gEAAP//AwBQSwMEFAAGAAgAAAAhAHfkzgeMAgAAzwoAABAAAAB3b3JkL2hlYWRlcjEueG1spJbZcpswFIbvO9N3YLhPxGI7NhO7F0mX3HWa9gEUSRgmEtJIwsvb94i9pc0A8QWSBefTz9nQ/aeL4N6JaZPLYu+Ht4HvsYJImhfHvf/r55ebre8ZiwuKuSzY3r8y4386fPxwf04yqj2wLkxyVmTvZ9aqBCFDMiawuRU50dLI1N4SKZBM05wwdJaaoigIg2qmtCTMGNjqARcnbPwGRy7TaFTjMxg74AqRDGvLLj0jnA1Zox3ajkHRAhC8YRSOUfFs1AY5VSPQahEIVI1I62Wkf7zcZhkpGpPulpHiMWm7jDRKJzFOcKlYATdTqQW28FcfkcD6tVQ3AFbY5i85z+0VmMGmxeC8eF2gCKw6gojpbMIdEpIyHtOWIvd+qYuksb/p7J30pLZvhs6C8WnbwnY7xC6WG9va6im+q80fJSkFK2zlNaQZBz/KwmS56rqDWEqDm1kLOb3lgJPg7XNnFU4stf+1tsc6DD1wivwmdoLXyt8mhsGEaDpEZzFFwp97tkoEZHC/8SLXDJwbTmw+LSAaATaETfxYtIxtw0Ckr27HySeWVcupo+I4ee/YcGIP/FvMAEDLWYgobnW4wZkPWIZams3DtTFCzhZbnGHTFU1NTCc2gpa4GhDrBOOSdP3MMdk8p6074FUMYqiO7yvUr1qWqqfl76M99S377M5NM1hNwQ+bkHmfmOcMK+jkgiRPx0Jq/MJBEZSvBxXoVRFwV0hkN1RTdqnWXf40k5S7CS091xL9A5z/FCysEoU1foLauVtv4/Uuiv1qFT6dtlptfrCawBmT/tj7QbB7CD/vHrqlR5biktvBnYr+XVfDs71ykJecMOTdN4Yp076HDveoecSN1RWOo4ffAAAA//8DAFBLAwQUAAYACAAAACEALEGzTI0CAADPCgAAEAAAAHdvcmQvaGVhZGVyMi54bWykltlymzAUhu8703dguE8E3mIzsTMdu0vuOk37AIokDBMtjCS8vH2P2FvaDGBfIFlwPv2cDT0+XQT3TkybVMmtH94HvsckUTSVx63/6+eXu7XvGYslxVxJtvWvzPhPu48fHs9RQrUH1tJE54xs/cTaLELIkIQJbO5FSrQyKrb3RAmk4jglDJ2VpmgWhEExy7QizBjYao/lCRu/wpHLMBrV+AzGDrhAJMHaskvLCEdDlmiD1n3QbAII3nAW9lHz0agVcqp6oMUkEKjqkZbTSP94udU00qxPephGmvdJ62mkXjqJfoKrjEm4GSstsIW/+ogE1m95dgfgDNv0NeWpvQIzWNUYnMq3CYrAqiGIOR1NeEBCUcbntKaorZ9rGVX2d429kx6V9tXQWDA+bFvYboPYxXJja1s9xHel+UGRXDBpC68hzTj4UUmTpFnTHcRUGtxMasjpPQecBK+fO2fhwFL7X2s7lGFogUPkV7ETvFT+PjEMBkTTIRqLIRL+3LNWIiCD240nuabj3HBg86kBsx5gRdjAj0XNWFcMRNrqdpx0YFnVnDIqjpO2jg0H9sC/xXQANB+FmM1rHW5w5h2WoZYm43B1jJCzxRYn2DRFUxLjgY2gJi46xDLBuCJNP3NMNs5pywZ4FZ0YZsfbCvWrVnnW0tLbaM9tyz67c9MIVlXw3SZkbhPzkuAMOrkg0fNRKo1fOSiC8vWgAr0iAu4KieyGYsouxbrLn2oSczehuedaor+D818GC4sowxo/Q+0sNqtPy2UInzq3Cp9O61Yfqh+sRnDGpD+2fhBs9uHnzb5ZOrAY59x27hT077oYXuyVg7zohCHvvjFMmfY9tHtE1SNuLK5wHN39BgAA//8DAFBLAwQUAAYACAAAACEAQzff1o0CAADPCgAAEAAAAHdvcmQvZm9vdGVyMS54bWyklltvmzAUx98n7Tsg3lNDkuaCmlRask59m9btA7jGBFTfZJtcvv2OuW9sFdA8YMdwfv5zbvjh8cqZd6baZFLs/PAu8D0qiIwzcdr5v34+zTa+ZywWMWZS0J1/o8Z/3H/+9HCJEqs9sBYmuiiy81NrVYSQISnl2NzxjGhpZGLviORIJklGKLpIHaN5EAbFTGlJqDGw1QGLMzZ+hSPXYbRY4wsYO+ASkRRrS68tIxwNuUdbtOmD5hNA8IbzsI9ajEatkFPVAy0ngUBVj3Q/jfSPl1tNI837pPU00qJP2kwj9dKJ9xNcKirgZiI1xxb+6hPiWL/lagZghW32mrHM3oAZrGoMzsTbBEVg1RD4Ih5NWCMuY8oWcU2ROz/XIqrsZ429kx6V9tXQWFA2bFvYbovo1TJja1s9xHel+VGSnFNhC68hTRn4UQqTZqrpDnwqDW6mNeT8ngPOnNXPXVQ4sNT+19qOZRha4BD5Vew4K5W/TwyDAdF0iMZiiIQ/96yVcMjgduNJruk4NxzYfGrAvAdYETrwY1EzNhUDkba6HScbWFY1p4yK42StY8OBPfBvMR1AnI9CzBe1Djc48w7LxDZOx+HqGCFniy1OsWmKpiQmAxtBTVx2iGWCMUmafuaYdJzT7hvgjXdiqE4fK9RvWuaqpWUfoz23Lfvizk0jWFXBd5uQ+ZiYlxQr6OScRM8nITV+ZaAIyteDCvSKCLgrJLIbiim9Fusuf6pJwtwkzj3XEv09nP8ULCwjhTV+htpZrQ5f1k9LOC66Vfh0Wre6rn6wGsEZM/6x84Ngewi/bg/N0pEmOGe2c6egf9fF8GJvDORFZwx59ySlpdr30P4BVY+4sbjCcXT/GwAA//8DAFBLAwQUAAYACAAAACEAAIVT6tgCAACZDAAAEAAAAHdvcmQvZm9vdGVyMi54bWzEl0tvozAQgO8r7X9A3FMDeaOm1appq96qdvcHuMYEVD+QbULSX782YKClWwE9bA6xM2a+GeYFubw+UeIcsZApZzvXv/BcBzPEo5Qddu6f33ezjetIBVkECWd4556xdK+vfv64LMJYCUdrMxkWGdq5iVJZCIBECaZQXtAUCS55rC4Qp4DHcYowKLiIQOD5XrnLBEdYSm3qBrIjlG6NQ6dhtEjAQisb4AKgBAqFTy3DHw1Zgi3Y9EHBBJC+w8Dvo+ajUStgvOqBFpNA2qseaTmN9MnNraaRgj5pPY0075M200i9cqL9AucZZvow5oJCpX+KA6BQvObZTIMzqNKXlKTqrJneymJgyl4neKS1GgKdR6MJa0B5hMk8shS+c3PBwlp/1ugb18NKv14aDUyGmdXmtgCfFJHK6oohsavU9xzlFDNVRg0ITHQcOZNJmjXTgU6l6cPEQo5fBeBIib2uyPyBrfav0bav0tACh7hf546SyvOvib43IJsG0WgMceG9TesJ1RXcGp4Umk5w/YHDxwKCHmCF8MCHhWVsagZAbXcbTjqwrSynyorhpG1g/YEz8KMzHUCUj0IEc+uHWYx6hyUjFSXjcDZHwOhCBRMom6apiPHAQWCJiw6xKjDCUTPPDBOPC9qyAZ5pJ4fZ4XuNei94nrW09Hu0h3ZkF+a9aQSrbvjuEJLfc+Y5gZme5BSFDwfGBXwh2iPdvo7uQKfMgPnWhWyWcotPpdzUT72JidlEuWNGonul3/8yLViEGRTwQffOah3c3G6CwC2l+tGpSuk28PXnl5aG+h0zetq5nrdcBuvlbSN6FJ8I9ziGOVGdk9LkoyiXZ3Um2ufwCHUx3nGusHAdYI5EdYV8s6eBV5/Itxv5QQjq60FDFp86NRpchASygxViMrt/emewCBV8sYL/Z9fcdz+TC28fzPeeyVknk+v681UmpyXNRr/yBpR/LK7+AgAA//8DAFBLAwQUAAYACAAAACEA6Q+Qvo4CAADPCgAAEAAAAHdvcmQvaGVhZGVyMy54bWykltlunDAUhu8r9R2Q7xMDM5kFZSZSk7TNXZW0D+DYZkCxMbLNLG/fY/aWNgIyF9hjOJ9/zoZv785SeEeuTaqyHQqufeTxjCqWZocd+vXz69UGecaSjBGhMr5DF27Q3f7zp9tTlDDtgXVmolNOdyixNo8wNjThkphrmVKtjIrtNVUSqzhOKccnpRkO/cAvZ7lWlBsDW92T7EgMqnH0PI7GNDmBsQMuMU2ItvzcMYLJkBu8xZshKJwBgjcMgyFqMRm1wk7VALScBQJVA9LNPNI/Xm41jxQOSet5pMWQtJlHGqSTHCa4ynkGN2OlJbHwVx+wJPqtyK8AnBObvqYitRdg+qsGQ9LsbYYisGoJcsEmE9ZYKsbFgjUUtUOFzqLa/qq1d9Kjyr4eWgsuxm0L220xP1thbGOrx/iuMn9QtJA8s6XXsOYC/Kgyk6R52x3kXBrcTBrI8T0HHKVonjvlwchS+19re6jC0AHHyK9jJ0Wl/H1i4I+IpkO0FmMk/Llno0RCBncbz3JNz7nByObTAMIBYEX5yI9Fw9jUDEy76nacdGRZNZwqKo6Tdo4NRvbAv8X0AKyYhAgXjQ43OPMeyzDLkmm4JkbY2RJLEmLaoqmI8chG0BCXPWKVYELRtp85Jp/mtJsWeJG9GOaHjxXqN62KvKOlH6M9dS375M5NE1h1wfebkPmYmJeE5NDJJY2eDpnS5FWAIihfDyrQKyPgrpDIbiin/Fyuu/ypJ7FwE1Z4riWiPZz/clhYRjnR5AlqJ9x+eVxuFmtUrsKn07rVdf2D1QjOmOx5h3x/ex88bu/bpQcek0LY3p2S/kOXw4u9CJAXHQnk3XdOGNfIw/tbXD/ixvIKx9H9bwAAAP//AwBQSwMEFAAGAAgAAAAhAPQvsjONAgAAzwoAABAAAAB3b3JkL2Zvb3RlcjMueG1spJbZcpswFIbvO9N3YLhPBLbjhYmdaZ2mk7tO0j6AIoRhom0k4eXte8Te0mYA+wLJgvPp52zo/uHMmXek2mRSbP3wNvA9KoiMM3HY+r9+Pt2sfc9YLGLMpKBb/0KN/7D7/On+FCVWe2AtTHRSZOun1qoIIUNSyrG55RnR0sjE3hLJkUySjFB0kjpGsyAMipnSklBjYKs9Fkds/ApHzsNoscYnMHbABSIp1paeW0Y4GnKHNmjdB80mgOANZ2EfNR+NWiKnqgdaTAKBqh7pbhrpHy+3nEaa9UmraaR5n7SeRuqlE+8nuFRUwM1Eao4t/NUHxLF+z9UNgBW22VvGMnsBZrCsMTgT7xMUgVVD4PN4NGGFuIwpm8c1RW79XIuosr9p7J30qLSvhsaCsmHbwnYbRM+WGVvb6iG+K80fJck5FbbwGtKUgR+lMGmmmu7Ap9LgZlpDjh854MhZ/dxJhQNL7X+t7bEMQwscIr+KHWel8o+JYTAgmg7RWAyR8OeetRIOGdxuPMk1HeeGA5tPDZj1AEtCB34sasa6YiDSVrfjZAPLquaUUXGcrHVsOLAH/i2mA4jzUYjZvNbhBmfeYZnYxuk4XB0j5GyxxSk2TdGUxGRgI6iJiw6xTDAmSdPPHJOOc9pdA7zwTgzV4bpC/a5lrlpadh3tuW3ZJ3duGsGqCr7bhMx1Yl5TrKCTcxI9H4TU+I2BIihfDyrQKyLgrpDIbiim9Fysu/ypJglzkzj3XEv0d3D+U7CwiBTW+BlqJ1h/2az2X+H86Fbh02nd6qr6wWoEZ8z4BR4MNvvw22bfLD3SBOfMdu4U9B+6GF7thYG86Igh756ktFT7Htrdo+oRNxZXOI7ufgMAAP//AwBQSwMECgAAAAAAAAAhAEYL+aspLQAAKS0AABYAAAB3b3JkL21lZGlhL2ltYWdlMS5qcGVn/9j/4AAQSkZJRgABAQEAYABgAAD/4QAWRXhpZgAASUkqAAgAAAAAAAAAAAD/2wBDAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/2wBDAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/wAARCACQAIMDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD+/iiiigAooooAKKK5hfEFuYZfPhnt5hdX1mtvcjBcxEtuOMjYy7doBOAWGcYNAHT0V59d+L5h/wAe9vx3/wD18/n+WO/LaxdW/iSxudF1yw0zW9Iuhi80vVrIalp1+M8DPoDkgcjJz3NAHtVFfAWh/tZfAbTfGegfC7wP4t+HEOkt4Q8c+Jb3VtH8S6H4a8EeBF0PW9BQ6Lr250XQNd8T+IvEDuUOejtGjysob6etNXuUnW/iutRP2jUG1i8t/tv2/Tr6I6H/AGMGj/t5pToPhzzFh8RunhcwhmjeXBA8XI4B6/RXO2niOymBEpFue2eR79On1rdWQSAmMg+56f1/l696AJaKKKACiiigAooooAKKKKACsC4v7e2uIbaQS+bNa316p8iT7CBE0YZZNSMapHltSVUIY5XeQEKsru1X7SthfCxube0vfsu21vJ7d76ztL8AiNjpsciyEBiHIVgSDySQQ/mcAmgtBp4vdR1EWgAF1q15/aOpX2pjoAO2OOPYZ9gC1d3kVu1xq0yXWo6lpln4na0uxaaSfEp0vWide/sXRGJxydH0Yldw8w6J4ddg5LtX5hRfti69B+1F4d+E3iK6vPhN4N8d+I28SNH8YvDWraZ42s9MfR00LQfhrouhso8N+HvD/ifxGrBfFHimRE2ySbkkYRGP9M4f9cPqf515b4D1z4R+KvGPxP134f63ouo+KJ9a8M+DvHWqWN6dQ/tHVvA2iPruh6KwDKr/APCK+HNeZseF8qXPiZzh1DAA9L/5a/5/vVXmmsbP7P8Abr62037VxZ/bLz+zef1/Ln36Cufu/G2labf2Gh39xptv4o17SNU1rw3pN14k0b/ifaXoWs+H9B13WdDOf+Rd8Kf25of/AIUHA4yfjX4peML/AOIXxL1Dw7ok9vcaRptn48+GR8JatrOjnwz4s8UaH/wj/wDbnjP+wvEHh1x4ePhLxFrf/CLN4pXxl/wmRbLDwN4y/wCES5AOdm/Yv8O/EL9p22/aYufG3wu8fTW/xG0nW7r4ZDwL4O1PwXYeGdD0XxFoOjawyqp8S678ZE8Rf2z4oXxb4rlIZ9CKfKfCCGT9FOsX2iCf7Tbjp0x7deMf/Xr8xvFWgeMfBPjj4k6JcaVa6L4h+Nt5+zpY6Pq+NG8N+BvCPwt+BmjjX/iuP7cPiTwkefiLrfxTzggMfi54XOB/wlwFerfC68n+FXxY1/w54l8Ytd29z4d8K+GdH8D6n4wddN8CaZoWu69/bWs/24vhzwj8Mh4hzrmgh/hd4VP/AAmPgzwToHho+BgIy3/CZAH3HXGWHxv+Httr2n+G4/G2ht4g13xjqfgCy8Pkf8TW98VaDop17W9HXRfvKy+HNEO1lwy5JB5JryD4b/tPeE/iZ4E074maV4e8WaH8MPEFrpus+Dfivq+kazpvgfUfDWuqZPA2sD/hIj4R8UE+K/DI0VtgGR4y10+BwF8dCvlPQf2Pfj1Zftlv8bda+NFwVtPAw1l/iHpXwm8JaZp/ivxHrWtNoWtfDMeCfECeMH0XQG8PaBGJPEvhdl8ZMviLw6Wlk27JQD9mrPUoL+LMJHnAc27EZGPXIGRz+nStSvH7S8ns5TewdO/TnrnjH19uO3NemadqMGpWwuISvpcDGNp2nI9TwPw9+tAGpRRRQAUUUUAFFFY2sXYs7C4bvjj6H/8AV9aAPAvjB8R5vhvod94tuNP1rxZoMGr6W2r2ukz6RDqvhLSWC6ENZ0RJP3uusPECRq6MQynXACqhQq+Ofs9/tE+DPjnpesWVj4j0O5+IOgXmq3vjDwppI1nPhLSjrWvHwMNbPUeIT4cGhZ5xwM9K9Q+JHwx8A/GHSdP8OfE3wrp3jTQNM8R6X4ns/D2rXmsf8I3e6roY/wCJF/bmh/MviAgn/kVvFm4fUHnzxG8Pfsu+BNN8HfD/AMDfEf4oX+q+MvFGs+Efh/8AD/SdE1HxNfDXNaOu63t1vxB4i8J+GNC8P+F311EHifxb4xT5CSH8YSKqOAet+PDrdn4H8YXHh06l/wAJBa+D9TvNH/so/wDEz/tQ6Nga1ofPUkgDB5PAznB/CbwxpX7V3wE8N/B/9lb4Z/FXw7pg+IvhJPhP4DtNT/ZP+J183wl+GEfw012Txx+05rv7R3hxvB/hr4g+IPCjaCB4M8J+LfCHweSXxj4gaORfGsb+D1P3F4a/Zf03x78bvGPxL+IPww1D4a3vhNtN8SeHtOs/G/g7X/jd4T1nXP8AifvongP4o/D/AMTN4n8AfDfxS7a7H41+FfiuWTwam0w+CJ5PBXiuXwd4O9N1yX9tnX38JfDuD4i/s8/DbT9e8eLdXfiK10bxhqPxLP7OWA5ZPBGvj/hWmgfGQlv+EVIdvGPgrdGfHKqBnwa4B89/ta/BzxJ4WufhVqn7PWufDzxL8QPH3hmX9hu1m/aXfxX8RfBHhjwv428DyMPiSdG8DvH4i134ht4k+Ffgbwz40Z7i3TxkyoJZvBUPmeMzyPgz9mnx/wDCPXvg9Y/ET4a/AbTNe1U2P7MXwJ+Gvw1Txn8Q/hl4Q06HStf+Knx1/aAKfEXw34O8O+AfiH8XW0LX/FfjCXxTH408WzReHfDHgtPHvjPxx4y8WtL9FaD8Avg98RvjF4nuPC3jjxHb2Hw4stTOtXngf9oPxn4j1M+PNc/t/QW1vWtB1/f4Z8P+Iv8AhGwdvifk5wN3O6vSW/Z3+Lcvxc8K61pXx9a3+DHhi8Pij/hCdV8Hf2l4lvfE40XX9B0LRm13/hJAP+EdJ1zWvEwX/hDyxY8DarMoB5l+1n8bdB/Z3PinVbfw7r/jPxB4M+Cw8bfEv4q3PhB/GSfDb4QaHretS6Ey+CfDw8HHxFr/AIs8SaD/AMIsy+DmXxd4QPiPw943nSTwN4TcD8kvB8R8dfE7x98Ztc8V/s4/GfU/Bth8MNG8R/FD4U/FP4mftHeBf2bNM/aO0RdA+Bfwy+Cf7LXxd8QeLvhbrvxob41MvxR8cfFEeLfBnjQ+C9fdo4yvisgfXnir4LePfAf7RvxW+P3xG+I/i7xJ8UvCll4H0/wz+0f4h8I69pH7KfwI8AqfHmu+C/BXjb9nvw18aiPi7onirX/HWvyeMvEgdJvg1/bfw08dxnwWsM0sXg8MvhIav8H5/ib488CfGTxD8O/GfgeD4O2Hiz9hvxh+y98bNQ8c/HH4yeHvG3xx/aW0TR/iBrfhI65H8Kfh34J1nQPBPxQ8J+EfB3hLwV4R19/HHjn45+OPGiPHQB9p+HPiYt3L8EL74p6Hpnwk+LI+A/hnVf2fP2fvEF3pGoafrnxO8ea0ug+CviX4f+CasvipfEf7Pnh3QVB8MRsP+EK8HeO/E2f+ENePA+oPhR8aIPCHhfxT4f8A2g/iV4X07xf8M/GEXgK8vNa1nSF8T69pei6H4fTQvibrcWisHh/4Wqqr4r8GxbI8HxB4a8EKrTNItfJh8E+IPgL8L/Dvi34cfsy614m/aE+LHgvwx8F/Dnwm8D/G34h/Eq+8KfDLw9o3iHxpoXh3Rfit8YfEHjD4ZfD74dxaMu/xuEbwZ4S8Y3UYjL+MfHI8HQN4T8e/Ftr8G/AUf7a37S3gTxF8A9Yk/aR8B/HPU/h3q1n4P+N/inw98NPhb8MPh9+zdrOsa9J8P38XeFk+IojbQ/ip4Jg8KKzjxh4G8IeCQIvHBQSgH7vTfuP3Gf8AP69h/gcVf03VhpFyJzj7PcnN3nqMenvXyb+z18RfiJ45l+J//CT/AAz+MXgzwfpWs6VefDnWPit4RXwV4l1vS9e0LzNd0bRtE/4SXxd4oA8KeIWQgeKx4QY/8JGngjGzwkWXw4/txpdftCf8Ko8MfDv4n+NZde8N6VoujeCrnwh/whnjnQ/E7a5r48baz42/4T9fCLaF8PfC/hxkC+JlUlpNCEabyRuAP18orh/CWordW8+lGVTcaMyxhdoydNYMdIYnv+6TpjomD1FdxQAUUUUAFcL4nvMTrbj+6Pz47f1/lXdV85/ETxR4b+G2h+JdcvDYadp2gR6jrN3a297pOnPqC65rIOuFvM+bef4y4Dk/fycUAdJ/y1/z/erzPxx8Efgx8SbuXXPin4K8O+MxaaSLP/itbvVtT0vQ9LAfI0bRHDeGfD6ElSPFEW19wHz7Sa0/B3xI8AfEP/hKP+EA8Rab4st/C+sHwxq+q6V/bH9maf4nGinXf7GGuDI8QAjXNDYDwmc4OGwcgeg/uJrXyJ4La5t7rpaXf+f1x+lAH4meEfBviH4jeL57z4B/H7UvA+oeKvGHifwvp/w++FHhDRPiR+zP4H+BOJND0PVv2iRu8Iu/xH8VeII9F8WMPCXxe8HfGjZr/wDwhClvAa+Ngut41/Yo+Jn7RPwxXSf2o/20fEnxZ+DfhHxDqejeJfCXhL4EfDj4B/Ei/wBVj1oaC+iD4rH4jeLY/D3w+A1/5c7PHPhBFJHjb/hOom8v9aviXp/iq4+GfijTfhwlvYeMLXSkvPAtncBdN00eJ9EZNb0PSG3sijw34n8Q6KPDch3FhFrrbFZtqn8svA37cv7P3xH8EftM/Dm4+LWgfCbx9qurav4m8I/Cn4q/FLRfhL8bBrGu6NHr2t+C5PAnxe8Nt4t8PN4V8Reb4XiYeEfGFt4xHmN4JJ8EC1BANfx78JfAf7EPhbwxe/CT4/eMv2efBGh6XqviP4ufHn9pDx34y/aN8L+E/hfoWj6Ingf4ZPo3xd8TSNrev+K/EGr6L4e8D+HPC3i6Pxk0eieIY4x40uHEQ88vNR/blsW+CzaX+0lqPgH4gfHTxRpmuXHgnxt+z7o+p/8ACJfs665q7eHW0b/hVfh3xL/wk/8AwsXwlv8ABXxM8c/FA+MT/wAKX/4T3xQfHo/4QTwl4L8Fj7/+Ifwn+Fnxe+HXhT43+JfBUHi3xz4Q+Hmmaz4C1ZLnWvG2oeA9TKaJr66v4K0TbJ/wjviDAX/irfCnhKPxm/hIKisDIsDan7QHww+Evxf+B2lXHxk03xK3h/S9M07WbXxD4e8aa74M+JXhPVNe0g6FKmjeOP8AhIfCvibw6PFXhvXJfDHjMmSL/hL/AAhrfiK38dYikkjIB+OXg74E/twfE/4LaR+0L8JvEeh/HH4m/tJX/j3QPB3xWX4iat+x7pH7MXwcf4la23h742eB9D8Oj4vSfF7Xvir8PNE0TxGW8Wv4sCMvw2bwKj+AR4uZvrL4FfBz4z+C/G9/4wtfEHhC/wBf8eaz4sfw78JvjV+0f8TP2jPG/j3TvBekHwPLpHjj9onX/wDhLk0D4ffCvxPrvjvxY3wG+FHwfPg7/hNvELMfHJPhVmP0ronxC8SaJ+1V8PvgHomn2Hhb4EeJ/wBkXxbe/C3w5baTo+nabZ+JfAOufAiJDoZycJ4X+HHxUXw6iY2hdBA2gmvzC8b6z8S/hddafL4dn8S3Hi/4N3v/AAUq8UeAvEOk6QUO74rHw/8AAr4TaHogBD/8JF8WP20fG48MfBRGGPGyeAvFHjdgylloA+1fFXxm8OfAjXtL0D9oa9+Mel/ELTvEqfZf2ivFng/4laj8NviL/wALX1Xw6de0D4K+OPh5N40i+EXgHwkWbww3hr4qHwYvg2PQYvG37xY/GPjl/wAxPAn7C37M2vfsj/CX4m+MPhZqOteMPGX7TnwI8baT4d8WfFP4meJdOZPjn/wUd0AaFovjbQh4l/4Vlr//AAlXw711CT/whreCsaB/wnG0Fgy/t7cftK/BT4afGe48K+M/ij4J1XxvpXwu8KaLq9l4V8Qj4j/EzXPFUcoOtaT/AMIL4E/4Sz4nfunUSqw8IBj/AG4HjBYpnzLWPCXxW/aO+P3wy8Q6t8OvFfw8/Zz8B/EbSPjl4o1f4qPpHhXxr8SPHfwr0Yj4H+EdF+FOgyyeKPD3hzwt4m1j/hZvi7xN8WP+ETm83wF8Mox4K8szyxAH6M3n+tuJ+f8AOevJ4Of89/nO3/Zr+D0PxN8Q/GS58JRar8T/ABR4s0jxgPiBq96i+JNB1XQNFOhaLpWh63HHG3h/wBJ4cYK3hbLJ4yXWvEh8bL4sLyh/oWab/J/z+Qz6kmsegDd8MS/ZPEUH7/NvqlkbIrx82qYOu7evvrn4j3xXrdfOviK8k0y28NXFrPPbP/wnPgWykFuAUMeu+M9B0Fw4PBXbrh3gjBGQcjr9FUAFFFFABXwd+0v8DoPjv4Xt9L0oeHNF8YWusaXZaN8QdW0Yal4m8CeF9d1nQP8AhOh4HJOB4iPhzjJIHYnkV9414/eQ28V1cQdRa3n2L8Dj6dfX0NAHkvwj+GTfB/wZ/wAIPZ+ItR8R6Ba61q174b/tXSNH0/UrHSdcY68uja62gKo19m8Q/wBtFvE+OGJAZwu8+pUV5r8TvGV74I8L3+uaX4V8beNdYtbPUv7H8J/D7Rv+Ej8S6+WbCjQyRyScL/wlHiz/AIozJUYGQCAekz3kNnaXN9fTW1vp9oD9s1W6x/Zljpf/AFG84GT0GSByCSBk18reJPix+y78Z/BOo/8AC2/+FKeP/h/bXq6NrA8VWvg341eB7HVdaOvHQSSv/CW+GufDmgjxMwJKMmvBSMFgfz28YfGC/wDih8S/hR8TPg9rviTxH8L/ABP8CvE/wx+O/hT4g+Ij4a8DaENc1zXW8c/DD5ww8P8Axm8J+G/7b8TN4XXwgfGnjTwX4B+GR8AN4v8AA3/CaDxfy/gr4ezeC/CWkeB72x8KT+ENb8C6T8WtZvfjF4t1nwT8NP8AiRa3rmh6H8TNa8c6D8RSG8NMP+E3V/DHin/hDv8AhNP+E+8Mr488E+C3T/hC1APp3wR+wJ+wZ4jt9R8Y/AHwF4y/Zb1dvEvifQrHxH+zT8RviX+zBqN+dFKjW9Z0XQfh94nh+GXiLw4WOieI18TDwifBrlk+Yncp9U1b9lX4xW+lf2Vb/wDBRf8AbNHhg2f2O10nVNF/ZP8AEWpMxAyx8b+IP2bz4o8QE8cksemSeCfzF0z9pOzh+HXiD4ufA/w1q1v4n0H4X+KfG/7N+j/8I18X/Da+LdT16PxBrfgX4laH/wALfj8W+KfiB8OP2g/Ev/CD/DTPhNj4P8aPr/icGTwb438I+DPF9fq/ceMfGn7Uf7Hngj4tfswfEPwbD8QvHXw7+Gfxn+EXiHU7A6h8M9c8c6GdC8fReB/HIMr+KF8AeKte0bVvhh46cn/hM/CB15nWOLx14VRYwDV8Z+Jvgv8Asq/B+2+Ov7UfxYgaL4J6B4nstW/aJ+LsGhjx3YR+Obnw6uvaZoh0Lw5bk6/4pTRtA8OeE/CfhLwi/jTxmvh/w1DGtw7qk/wv4J/Zo8bf8FJfF9p+0z+3n4L8VeE/2a9K12x1v9jn9gXxhd6x4Jew8MaKx/4R39pX9r7Q/DYj8ReIPjN4qkkXxN4I+BPi4y+Df2Y/BOsiFo5viFN41uIfrNPD3wx/b++F37PPxnn0C50Hxd8Dfi7/AMLZ8OfDfx/Zf2ifhP8AtPfC3R/Hnwo1v4Z/GjwXEC2ueIfhN4i13xsEnhfevjDw/wCGfHHgSZv+KQLfSngH4kR+L73VPDutaVdeEviP4NQjxb4M1a6XU4bNtXLR6N4u0LX48L498A+Jyu7wV4kdULKH/wCE3HhDx3BceC4ACx8MfhJ8Kvgnow8OfB74Y/D/AOEvh8cjSfh74O0bwTpt92J1v/hH8/2/gEjPB5Neg+f7fp/9erE/b8P61XoAPP8Ab9P/AK9c/r3iTw54VtdPvvEeuab4b0+61jS9Fs7vV7z+zdM/tT/oC59+n6j1rYrxb9oP4VeJfjn8NL/4WaJ8QLX4baf4outKsfGGv3Xg8+N9SHhjOTouhaL4h8RjwzoPiE5GPFOPGA4zjsADnvGHxs8OeLPgz8SPH3w01S51P/hXXjzVPDFpqhsgdMHjvwP400D+3dY0UZYeIfDo8RfKxBKkg44Ix+gVfjJ8Iv2fJ/2Yvg7oOieOPEni/wAaav47+Ovwx+H3iTwr4p8RjxN8Nl0rXP2m9B0HQm8DeBdreGNAbxX8OToZ8bKVYEgZU521+zdABRRRQAV5d4itBHqU5EIYEfbc/T6e4P6V6jXC+LohD9gvByQfsZGOzEkHt3J9MYzQByNflN/wUS1fQ7vT7j+1fjFc+Erf4N6P4Y+IWs/DHw/4y0f4c+Jr/VfHnjU+BPhT8Tf+FqsfF3ij4fjwl4k0TXNo/wCEP8Y+CvGfjMAADx0PBfjPwZ7x8f8A9rPQ/hlr2neHNL13TboWvxI8B2XjHVfCdlrPjfxN4T8Ma7rYOueDP+EI8P8Ahvxd4m/4SLxX4d0I9jyQQRjn5V/b78R/DHRvjB8CfiBpHwr+Lnj/AOOPj/8AZ+/aL8GfC3SfAFprmnj4lfDDXNE8PJ47+GPxt0HQfDo+JuueHPCi6z4H+KI8Kp/whvjHwZ430Ey/8Jt4PLsXAPhjwNIfE3xX8A6R8TLTVL7xDq3i7VviAPAHiq70TxL488c6r4G1nx98WfAuur440PxF8Jk+IPiTxV8OtE0M+Bvik6eEF8FnXvE/jl/G3jPwF4u8aA/avwC/Zh/Zr0PQPhn8U/2mvAeoftTftK/ELwPH8WPAHwbW20T9qLw38CvAfiDxl4i8d6Jo3wU0XQfC3hf4XfD34feFG8dp4ch+JKL4N8HeNPGfh6GTwPOy+GfB9tF8j2MfgH4y/ETwt8BfEFxqXwk+GcngP9mLQvjR8Nbafxr8PL/w9pxR5Pjj4N0hdcMfifw94Y+K3xF+N3gfwt443yReNPHHgzx98TIvHso8EeFPGBb9Ifjt+wx428eeC/F2heG/iBLBq+uLFEtoz6Z4P8N6/qY0XXvDynx1or+HfGLv8PfCnh3Xv+EY+C3wz8Lf8Ig/wY58eeCJD8d1PjYAHwv+3946+IH7Ymh33gb4L/DTxJqtgfDfim/+Fur/APCI6R8ONR+C7eB86H49PxR1zxG/hX47/D74xnxJ4I+K3hePwp8J38IDwOvwj8Lp47PjFfi14KA/QH/gkrbmx/4Jq/sZaXC9g+j6b8FtK0fwbqul2Wq6bpfirwDoOr64vgbxlHoeuqreH9f+LHw6XRPFhMpeTzPET4cR+WifMz/Cjxv+w7qvgf8A4QOTxD8WPGtt4X+Glx8YP2lv2lbvWNN/Z6+DOnaNs8B/FT4o65ry+I18XfFz4jfFXw7oHwr8K+BvgR4Om8W+MvF/jH4UfA6X4geNvCDRxeNvF31p/wAE2de0PUv2abjwd4cnudS8L/BH41/Hj4FeG7u7P/H/AOA/AvxO1/8A4VTz/wBk51zwOPp2oA1dXif9nr9sDSfFMVwNN+En7bd7pXgDxdbFQNM0H9rHwNoZHwp8Y58wkv8AtBfBnQtd+GXjiQoif8Jh8JPhcgVn8WO9e/fEPwvo/wAQILOfQten8KfEjwJfanqPgP4gaPZJqWq+FtW1pU/trRtc0Ntq/ED4feKzGqeM/C7N/wAVkEjw6+Ox4L8aLc+O/wAH/C3x9+Evjn4O+Mr/AFrTdG8ZaQbKy8QeHbv+zPE/gLxPoWsDXvAvxN8E66Sw0DxH4T8S6HovinwQcAf8JnoIG3Klj8+fsnfHnxP8SdE8cfCP49toejftbfs43mm+Ff2hNL8O232DTPFrayxj+Ffx/wDBGiksx+Dn7QPh7w+3ibwZuJbwX43HijwKx3eEGAAPb/gj8Zo/ilY+KdC13Rk8G/Fv4ZeJ28G/F74dm88tfD/iP+yU1zQ9a0ADzG8RfDz4qeGGXxT4K8VMf3nhAkZh8ceFfGKxe21+c/7Wn9rfAfVdA/bu8K6XqVzcfBHwf/wjH7SHhPSf+JkfiV+yYNa/t7Xtb/sPOD8RP2e/Eeua38ePBAwMeCx8T/A2T/wlwA/QDQdYsde0vT9c0q+ttS0fVLTS9a0fVrS8GpaZqGl67/yAta0P8D/SgDYorPvLyx021uL6+vrbTdPtf+Py7u7z+zdMsf6e/T36Vf8AJuP+eA/z+FAHhHxKtv8AhLfjT+zT8OF0+01Wzh8YeKvjL4qtzqhs2sPDfwn0Jn0LWo4VIaZ1+M3jX4XSBFz8qMxUorCvuivg/wDZ5XU/iH8cfj78YZdLsn8IeHT4a+APws12TR401XU/+EEfXtf+NusaBr8ui25/4QDxR8R9c0DwxIPCsrW8/i34Q3EU8GPDMCp94UAFFFFABWbqNkNRsLiymxi4Urx0wCDwecdO/wBPetKigD5f1f4Y+FbzxR4P8ST6X/Z3ij4deJNU8UaPd6TjTft+p67omvaBro1zgf8ACQA+HNcJBPP4DFfNf7bP7PmofHf4Sabq/gHwl4S139oD4IeMfDPxl/Zz1XxD4k8Y+CdTsPHPgfWTrmv6RoPxR+H/AIl8KeJfAP8Awtjw4Nb+GPjbxOW/4Q9E8QE+O/BHjPwOPLf7p8YabeLLb6xo9oty25V1e0tPKW/vNPbP+nRsuA7xY4GCxBGOQQvNed5v4e3+emfbr+QB/Kr4W+IXg/8AaB8SnQvjP4N+Kf7OPjn4iftHeKLL4vfGH4hto/gnVfgx4pHgo6D8c/hefBPxDPi74Y/D/wAR+Lvhz44/4Wf4I8VsfGX/ABRfj/PgM/8AImeNa/c/wX+3f+zzcaZ4Zt/ipf65+zf/AG7ZaYvgTVvjvf6Rpfw0+JWlttOhaz4H/aLXxL4t+GPj87cEeGf+ExHjdQf+K78ELuJrwX9ur/gnL+yX+0Reah438R+EfEmi/tD/ABPvNL0jSdV+Gnxs8Z/BbVvjV4m8DaG40LwVrWtIPFnhhPER+Hmgjw0virxb4Ok3D/hHIl8aquwp7V+wt4g+COg/BHwl+x54MTxro3iL9n3wf/whmrfAb9oPSh4a+N/hPwLoWtldDXXfBGv+I/GB8eeHF8O61ofhfwX8UfCPi3xl4K8ZZyvjZ2yoAPHf2x/iP/wTI8beGLbx5+0F+0Toni6L4b2X2u18GfAv4/8AjLxN4n8YaZ5ZA8HH4U/BvxN4m8SeIT4sYp4afy/Bw8YkB408bIxBT3H9gb4feNvhv+z3dXvxJ8H/APCtPG3xS+Kvx3+P/iT4Ub9HjPwm0z4tfE7X9c8CfDDWX8OsPDav8Kfh0fA3hTxoVK+Dt+gDb1BPqPx50r4D6F8HPib4e+IB8F/Db4f6h8N/FXifx34gs9K0rwRpfhPwH4GU65rvjTX9aHh4LofhzwmNEyBKHAbDAB8FfyP8Z/Gbxb+11qd9rnxC0/xn4Z+E+l2C+J/hx8PNetTYal4R03XtF/4TzRfiX8U/BBRP+Eh/aG8VfBYD4oL8L/Fiqf2ZfBXj74F+Bykfx5/aJHjT4OAH7Y+E/i78MfHOuTeHvBvxF8F+LdXt11Jru08Las3iFrD+xADrgbWdCC+GlYAgFXVWByCAwIrI8V6Nqk/iP+3PB1homnahdWelaL4k8Q3mj/8AE017wwORov8AbnPIOt62RxwRkc4rnP2d/g/a/CvwJZWWo6Hpnhrxfr9tpl74g0bSVA07whpGgAL4F+GWjMJJN/h74V+Hg3htW/d/8Jn4wfxH41aJZPFcjPx37YX7WPgf9kD4d2vibWfDniT4pfFLxn/aui/Ar9nv4dlNS+J/xy8daJocuvazpOiaC7D/AIprwroEbeJvGvisJL/whvg4Y8o+OR4Q8H+LQD5h/bs+MfxB8G+HfB/7Lv7PltY+K/22/wBrvSPEngH4XadqbHUfDPwn+GQ0dtF+Kf7WHxT0RJEYfDr4U+HtXB8H+Z8njf4xeIPDXgIJMrSrH95/s9/B/Q/2evgZ8F/gR4cv9S1vw/8ABH4V+A/hHo+reIbz/iZ3+l+BfBfh/QdC1rXOn/FRf8SP6d818Df8E0/hVYC2+Kf7TvxS8feGvjR+2L8c9W0m8+NXxN8OfN4I8J+Axo//AAkHwr+Gn7PEkpkfRf2WfDPw71zRfFPwWmkd5fG3/CQ/8Jx48dfHS+Lwn6s0AfLv7XWj/FXWPgZ4+g+HXinwl4agtfCHii98e2nirwJrXjfUtd8Mf2GT/Yvgg+H/ABGv9geIc8DI8Y84JX+78YfA69/aa+CXwu8Y2XxU0LxLd/tU/tA+JPhh8P8A4JXXivx4PiR4aP8Abuif8SHRBoegkeJfh/4e/Z88Of8ACcfFD42lvCAH/Iz+OSfGIBI/VHxV4w8OfD3wt4h8ceMdctvDfhfwvo+qa14k8Q3d5/Zul6fpehev4DrXhn7OPw38QfEvxqn7Vfxy8Ban4S8a3P8AbGhfs+eB/FF15us/CX4Qa3G+7W9f8OOIx4Y+M/xP3alceL7iR5vFnhLwRJ4b8BNb+DJ5fir4PlAPqj4T/Dfw/wDCLwH4W+GfhaWZtG8HaXFYxXN5aaWmraxqrLLJrnjDxDJoOieG7S68S+MdeGr+L/F+vrawN4n8XeIfFF5Ku+5RR63RRQAUUUUAFFFFABXgus+E5vBUOoajoFtqGqaJ563914asgb7U9D0/kSp4IhdmZAD80XhYSSOB5kfghYgkPhC796ooA/CX9sr4AfGT47+NvC3jH9n2/wDFeu+CNL8H6n8QdY1ey+Ox0rS9e8Uf2wNA0PRfgepZj8P/AIhnw6NeYeKM+DvBaqQpLFdx+z/iH+yF+zz8Yfh58PfBfjj4dXlrD8LLHTk+FfivSPGfjTw18b/hPqchUnWvBXxs8P8AiT/hZeg+JAUU+NJD4uMnjHDp45fxgksqyfQXij4Qq0up6/8ADO5034ZeMtWvNOudS1Oz0w+I/CniC4OuTa3rZ8S+BBrnhnw9quteJzquqQt4vtn8NeNfNuNFnk8XPa2o8MSeJeIPjlqfwjtQf2jPA+o/DawtgRdfFTQG1bxv8ECVOghyPHSeHn8SeAl/4SLXF8L5+Kvg/wAH/wDCZEEeBD4ybKqAfmd8Z/2KP25PG3xG8I+B/Fnxq0f9r39jv4c6zpHxL8MfCn416zo3wo8S/Ev4oaDreg618KvCH7YHxO+H3w3mHxd+DPwl8TaV/wALO8F+GvCvg4f8Ll8ZL4ZHxE3w+D1bxh89+FPhB/wU3+EfjPw/b/EH9nj9nz4peCdE8OeBvFHxz8aeEv2ydF/4SHxXqcfxm1v9pP47fGNdG+Lvw28Hf8I9/wANC/EbQ/hh4b2eMfGEnhDwX8GfhA3gdN0aeDRb/wBBfhXx54H8eWtvfeBvGPhLxbp91/x53fh7WNG1I9/p9cd/QV+X37b37PXx3+LXxp+FM/hyw+HHiS38U6xqfhnR9KNp8TPDfhiw8CeBR/wtnH7RXjfw+fF/9v8Ah3xX4j0EeGD4WHg4KT4hyMsWwAe3+Jfjl/wUf17Qp1+FX7CPwd8NeKLkZs9W+PH7Zejf8IvYgcf2zruifCD4a+L/ABNr/OOBh+OwBr5F8A/8E0f2n/HvxF8S/HT9sD9qvRB8ZvHukt4Y8S+LP2Y/B+r6b4m8P/DB9a0LxFonwb+CXjj4hN4ub4A/Brwt4n0PQ/FLN4T8HyeOJPHGh/8ACeP44Pjsu4/aLw/N4pu9F0a98YWOi6d4nubMXniS08P3utap4bsNUwP7cGi66/hvwk/iHw/jqWO45ySTXI+PPjB8K/hXYXGq/E34meCfBWn2v+m3l34t8SaNpufz/wA+1AH4/fEeHwB/wTN1n4f/AAI/Zf8AhJ8P/CXgDxj4x8MfGfxgfA954x1H45+PB4G1saDrmifFTXPEBY+ID8WPEWPC/gjxT4s8YgE/8JP4HwBgD9X9V+NejfDb4Op8Wv2grO0+Adla2QvPE+geKfEWj+INQ8JuAA2jprOgPJ4Z13xAWyVTwpI5VTtLt94+JeIvGfiv9pfwT4q0j4C/s76X8QPCXxF0eOzvPiT+0F/bXwn+Evi3StH0jQ9c8OYiXw23xS+IXh2Q6xIPAvinwj4NPgt/Kl2+NzsZR7H8Hv2UpfBfj9Pjj8bPij4i/aI+OVpDqOj+Gta1LQtN8FfDj4aaXrEmtWd0/wAJvhRpT6+PBmt+INFuYtD8Y+NPFHizxr42vIf+ElSx8U+E/B/i7xR4NnAPOPC3wc+Iv7Tvij4Y/GT4wDxL8MvhN4D8R2HxC+GH7N72mqeHPGmseJ9C13Sdb+FfxL+OGsW9zFfaBLbvE3iiP4BRW5HhExeGLfx7cRyN44+EFv8ApXRRQAUUUUAFFFFABRRRQAUUUUAFFFFAHzP4s/ZJ/Zt8aXHifUdW+DfgfTvEfjK8F54l8ceEdMPw7+JOp6imr/2+NUk+J/gGTwt8S1nbXts7SW/iyBpHAIfYzq/mXiH9hP4YXOhf2J4G+If7R3wkuftYvI9f8FftCfErWNRn4YLpbwfF3xD8VfDrRM2GkU+GGyFxE8fOPuWigD4P0P8AYI+EtvoUmh+PPiF+0r8Wrqe/a8fxD4y/aP8Aib4b1OCMxD/iTrB8H/EHwr8PJoUbibbbr4WLv/a7EsVdhF6V8Lf2Q/2a/hBqPh7X/AXwf8CWvjHwrNqr6H8Q9X0UeNvizp0eurrMetJ/wtTxs/iX4lSCa31vXfD3+leLLgxeF7l/CMOyzhgt4/qaigAooooAKKKKACiiigAooooA/9lQSwMEFAAGAAgAAAAhALwQH6A6BwAAtSIAABUAAAB3b3JkL3RoZW1lL3RoZW1lMS54bWzsWk+P2zYWvy+w30HQ3bEk/w/iFP7bNJlJBjOTLHqkJVpiTIkCSc+MsSiwSE97KVCgu+ihBXrroSi2QAu02Mt+mAAJdrsfYklKtkibapJmWrTYGQNjkfr93nt87/HxWfadd65S7FxAyhDJhq5/y3MdmIUkQlk8dB+fzxt912EcZBHAJINDdwOZ+87dP/7hDrjNE5hCR/AzdhsM3YTz/HazyUIxDdgtksNM3FsSmgIuhjRuRhRcCrkpbgae122mAGWuk4FUiH20XKIQOudSpHt3K3yGxb+MMzkRYnomRUODobDRypdvbMMmmDoXAA9doScil+fwirsOBoyLG0PXU3+u07x7p7ljYV5D1ohz9bclloxoFSgijRc7pjcL+m2/0qAQmB8CZ335qiQqBAhDsdrCHB3sd7peP9iCNVRxaZE+6PmtPYKmoXWoYdAdB22ToFDFZftwofPBbNoxCQpVXHYOCCMvGA9aJkGhisvuAaE9G/WCmUlQqASjbHUI7/b6/e4WvsMsCb5nxQ+6Xa833eIrWFPLtEJAxuvyLgVPCZ0LgIoy4Chz+CaHSxAK3CjnhDlTxHIMNq6Tg4wwMe0Fvi+SsO0Fu1fhd3AbAo1ezoXscE6a5LCQopwP3ftCsKthXvzww/Nn3z1/9v3zDz98/uwfzhGKE24j3gNZrBN//PLj/37+F+c/337x4yd/qyEwnfDy67++/Oe/flIBNyz7+zcvv/vmxacf/furT2z4EQULHX+OUsich/DSOSWpXKRFBVzQN6ScJwDplFEWM5ABSbLBZzwx4A83AAMbcAxNdz6hoohYke+unxpGnyV0zZEN+SBJDeQxIXhMqH1hD5Q6zRfrLK7RT9c68BSAC6v6yV7AZ+tc7ANkFTpJoGHqCRbRBzHMIHfkPbKC0MZ7HyHDv8copISRJXfeR84YILtjztHCSK2KdQ+lIkAbq40i9IaHjp84Y4KtCqbwwoSKzQKwVSjEhjffBWsOUrvVIMU69AjwxGro2YaGhuMZF0GPISbOLIKMWUmPqFx1RXoAREGzZ8Ax3qQmlHK0skKPACE6dEpWkwSkud1ulCU6+D22EhkLnBPC7XYQc8/IsQgIyOoj/wRBI/KvseMfiwJlTxZ5Z02tewQSc49u8BJAq/gRTY0CPKLIninjdWyk+hGEGFyCCELn8XtWAskN31eG309EtbkHrR66D8zUleMMMtFbqWbIEmLEjAw+gzGpM+l4s1eRNiBLAa2V/XBlps9sQcUGtaYvDldGoUVU7uQaOx4xKeV15J4kwMgxOWY16buhRiRfa9sJ0tOfQ4JvThKV//U9dA6woaJKnnOAnCNrMRYcIxMqjtxgire2E5fmRtbC0dxrk1KUvaJn+lV7JdGOvPjscxv4mvqjGuRbdUa1JWa/H6oF7ndBE0Ij9PtogqZgnZ1AedBYsDc90E0PpJH+P3qg2l1+0/ncdD5aObrpfH71zqdqdtRDpu2jJCUmrX2utEQYn/ENhkdMtUlMFIRoLibVQJF2z7HyRFxu9RnAmAJ17VDC/4R4cpaAXOjxlYqYlbJj5uSEiV5LTVuFyxt4nR6TqHxYKJuy4jGqYABe3fA61Q3R2fFiutvTnrruNKhRrB7tbm2Q7DexQ1dn2tGy2dHbzb7CDrW+6zFkYDOkLxXUG6LeyvCI88sB8lF8p10+vGahyO9IBqwUsI3ztce81qXm2gPbEgfS3GuKuWGHnnumHXpSJuJwOZi/5qgPtNgaJkqHWCzp9X+ZqMvKslcwcGaOnEtpVk8KCkE+dJfig5e4THMhkckCBnCcDd2Qlw7/WfUmp4xPAUsKnLpVOiFFHFIHo1SkvhEOnGn2DcQu+g3bF8hY/AbtU296uOFyCUNeM1MNxb1SivX226LlgKyF3WdJdOks8JqeAuGtTs+XUY4Q47uQR4hqmV65cq+IlVvT+Baq2rIA5wkozxujzhd4db2zR1uIMnV/Wea4XM0ilpF6+3P51Sx5QyuldYeLPFZrCsov1whodmkngmFXUdIP6t9gV/9qT5C3Pys08zR1hnnSbJt52rRp3nW2DZrCKk1rz49rPyj2c1ieHds+VI0OvnYni6diH0xFe7vGxQzOxEgZnZ/QwvwFiTbba8yKXVMubFsYcHYKlw6KrkQltbmo/Fa7qmynhRJ5tO2YVufuMUuCBBZ7eMcuEv6n2TuK0i0a9h1b9fI2Cfyq0l0QisDtSknpMFmADpwpPj1SMNl+4VxWWTW9rd1X3FlTNHT/7HVG7UnQmTS8fmfWaLfaXqPfGbUao06n5c86vjcdBx8IA3mS+p0ikHOQIrwpf6Kh5g9+ppFuP+ncCknaJOpDSFOR1c80/KD+ZxrCL8KsYOa3g1EwaUymfrfRDqbdRr/XGjUmQXcajESB785HH7jOhQL74+l0Pu8Eje5E4NreqNMYjVuTRrc/Gwdzf9aeehJcxuKqLM2lM7bpefd/AAAA//8DAFBLAwQUAAYACAAAACEAiUFYsDEIAADDHQAAEQAAAHdvcmQvc2V0dGluZ3MueG1stFlbb9s4Fn5fYP+D4ed1zYtISsakA123mW3aom53n2WJjoVIokDJSTOL+e9zdLPjhCyaGfQlkc7H8/Hw3EjRv/z6rSoX91K3haqvlvgNWi5knam8qG+vll+/JCt3uWi7tM7TUtXyavko2+Wvb//5j18eNq3sOhjWLoCibjdVdrU8dF2zWa/b7CCrtH2jGlkDuFe6Sjt41bfrKtV3x2aVqapJu2JXlEX3uCYI8eVEo66WR11vJopVVWRatWrf9Sobtd8XmZz+zRr6R+YdVSKVHStZd8OMay1LsEHV7aFo2pmt+qtsAB5mkvvvLeK+KudxDxj9wHIflM5PGj9iXq/QaJXJtoUAVeVsYFGfJ3ZeEJ3mfgNzT0scqEAdo+HpqeXsdQTkBQHP5LfXcbgTxxo0n/IU+et4+ImnODsW879mzBOC/PgqCkJnO/p/vfoTrjbv8sPr6OYYrXvdtEsPaXvKyJFxX76O0XnCOCZYqbK7p5zydU5jJ8LH6hzD9qVZhqweoffFTqd67BlTSlfZ5vq2VjrdlWAOpPYCsnMxWNf/hSD3/4ZH+W2Q976dHvZl/wCufwst7b6QDwv4l4JBD3K3XKx76e9KVSBtpM6g2q+Wgk5A2z2W8lNay2QwMynKTupZnyYIL+ElLcttP66F9tq/Z8e2U9UsQr0I2hAQX4gG6va6/tp7eJAcZNp35YtR9bHaSf1c2vWOuJDkhZZZN1rZ9+yP9edjPRv0EvyU6vRWp83BPuTDPLN1xJfeitOiS5nqMzpJO9XQd5fLGuT3RVs8X0La+7YGRw3SD2k1IUMgtOxVVP3fMX5FfefXterG7n4elst9eiw7sGwLU8+BEmTGa/XpWGfdcdD7D0wHho1IdgCXZGDBtkkzkIaq7rQqZ4pcfVBdCHuahpY7ke2V6sAG+Uk/feutg261ws9GTfLRkvVzbVnnL16eM12KT0QXquO2e37ajlt4n0ng0KvlxbZ8o3LZe/6oix8v8iF8vUswm+wyz6TgzKGLXA5ZMoQ0AZdui9+lX+e/QYkUQDnE4W+Y8F0LZN1P/RH6zJfHRiYy7Y4QvZ8125AhSVk0N4XWSl/XOVT8z5ut2O+lhhkKKJgbSPlCq4fB1X25wWnvZ018bOX/YDR0evoFCuYuUB00u3ePzQHc/feiecrocxLDqTVv54fPUDGnsQh7CPlzn+7hM4QQpTwwQ4T7p27wDKIOR54ZYoh7s1+eQUIErgVyBU4iMxSi0E3MUERQ4Fogygk3QwmJE98IYcqpZ/YGZizwzYSYcZ+aHYU5jRwLJJwAmZf8nXjhCCXCYnxEEmo2nhCMhDlexKFeLMyQS100d67nEI99mxYHB5shn4ZOaIYigZE5lAAl3Jw2kIY8MJsBkM/NPqQcTptmC6ngkKZmKGDMYiENROybU5RGJHLN8aIRTxwLYeIwx2yGQ7GDzISOQ0hiJnQEdrDZ845LPW4h9LjXf4yaIJ9ElvpyfGgB5ng5Eaa+2fMMc0bNKcoYEcyixSD+5igzn3rC7EMWkghbCCMn4eZ1sQRHoUUrEYklKJBrLDZ3AA4OdswdgAOlpfQ4FtjSsTnBUWLOQy6AkZghlyPfYoYrIm72Ifd4wCxL9qHCLMb7DiUWCwPHERZHhZwn5igDlBCLGYkjLMYLijzPXA6CiiQ2R1kw4lFzfQkPc0vaCI+Q0LxkETIuLGZEIra0L5diPzC716UORhYtx2GxuSpdl1HHQhhQFpi94YZMWHLejVAcm1PUjZknzD70MCaROQ89zCJhdq9HeOSbjffgkEIscwkUWMrBcyn43gJBnM3u9aBRcotW4BBmMT7EsSUPvcQJkTltfDggWI49PsaBa57Lh9ZrOc75DqaW3utzYtsrfQ+FntmHvicSYk4A30eBZRv1QxSHFjNihh2zNwIkAmpOG3A87FJmyKOBb54rCLgXmI0PIuZbUjQkcHYw50ZIOMbmSgkFo5Z4hT7yLbt5GAshzLUcJlCw5nVFSCBLt4kgxpY9JaIII3MCRBQwCyFlXmSBHHCvxULmuK55yRHHcWB2VOQKEZr7fOQL33IGiKC6LO6NQhHYoAQlrtlRMYJDtjnZALIFJcYo4BYt+K6wJHZMMLN0tpgQlJhzIyY8sJyWYyKo5Ssg5iT0zdkbu8wPLBaGwhPmdSVgoGeulMRlkeUgnfiQORYI5grNyZYkFEI2QOsRg0/katP/PNFfAo1P/WXLohpVwrTa6SJd3Aw/YKz7ITt9FxT1PGAn90rLC2h73M3oajUhbZWWZQJf/TMyGlFt8qJtIrkfX8qbVN+euecx2izO5f63E19/+yr1v7U6NhP8oNNmvEqZx2Bn+vasNkXdvS+qGWiPu+1Jr0714xPsWOcf7/XosrOnHjbdQVbDvdT7dLjjGAbLevV1O3k+K/W2v8CQN2nTjPcgu1t8tSyL20M3XnHCW57qu+Fld0smjAwYGbHhJc365cHo6eEsI7PsyTg6y+hZ5swy5yxjs4ydZXyW8eFa+bGRuizqu6vl6bGX71VZqgeZvzvjL0STF4a7res6K4+5hMTIVdZe19su7doRbw9pI6Px7hVyUY2C6TK2Xdxv5LcO/JoX3XLRNkVepd8gkGj61pqGl+mjOnYXg3usH91cUvQ/fcz3VOsL7aEinlnT3wpnBaTu9rHanW9030xrK4u228om1Wmn9Az+awSxA0vPrqH24GnMPig9kQRT68BsuDfuhpswyI7Pch+krcxncFZmo/L/YYuLobLjFY0oWTnCQys4pzor2CNiN3B9j+Poj7mw519f3/4JAAD//wMAUEsDBBQABgAIAAAAIQBkPTZFdwgAAHFbAAASAAAAd29yZC9udW1iZXJpbmcueG1s7FzZbuM2FH0v0H8wDPQxkahdxmQKL0kxxXRQdFL0WZbpWBhtkGQ7ee3P9BP6Wf2FctFmy6ZEWco4joHByNYlj3gPeS+PyNAffn723MEGRrET+HdDcCsOB9C3g4XjP90N/3x8uDGGgzix/IXlBj68G77AePjzxx9/+LAd+WtvDiNUcIAw/Hi0De274SpJwpEgxPYKelZ86zl2FMTBMrm1A08IlkvHhsI2iBaCJAKRfAqjwIZxjHCmlr+x4mEKZz83Q1tE1hZVxoCKYK+sKIHPBQbgBlEFUzCqQFILIOShBKpQMjeUJuBWVYCUVkCoVRUktR3SAee0dkhSFUlvhyRXkYx2SJXh5FUHeBBCHxmXQeRZCfoaPQmeFX1bhzcIOLQSZ+64TvKCMEUtg7Ec/1uLFqFaOYInL7gRdMELFtCVFxlKcDdcR/4orX+T18dNH9H66SWvAd1mj0WPMwX4nLhxktWNmnBHq88Ce+1BPyGsCRF0EY+BH6+cMM8OXls0ZFxlIBsWARvPzcptQ9Aw1I6lthnthgKwSfPTvvNc2nI2IhAb9CaGyGs0acLuM7OWeGgEFw9uRU2JXNAw+WQAUgVAs2HDySLDMFIMwS6iG+M4DcMqw6G9gnGcgljQMAfuN6YEsFhzQUhy1g58wdVLWPEiWaz44LI+EnBdK7FWVpwHDUVcNkwEGaJSQqQDzA3sPJ9hTMhHmpoDvnilPgyfTgvUX6JgHRZozmlon4qUvcXqiQMrDfhyEopPa8zXlRWiTO7Zo09PfhBZcxe1CIXvAEXggPQA/h8NZHwhH+EzuY/HT/ph6eIPi/UAp8ThR6QCrXmcRJadfFl7g51vn1AoITWJwEcRRBIywjepYBwvExhNImh9w0Uwih/jx442FhpWojwba/dgNhwI2OSt3cT5DDfQfXwJYVaI3HXx3bRY4oVuZpQnujaejZXU5G6wxUGX7HGkOVlpkBZDevbBy+8uoO14VoaO6j6i6Swz/gRuC8OvdnbbhcskvR/+HpFWIULSa1YIPQaxMgoD1J26JJLyQlHS8TERGCk1b0cry38ielzW8uIEXyDP33cR4DoJmvDQrLmB+HsnLkvduAwUhekztXM7LfXjtNyN0xIonDjkNLVzOy3347TSkdOGwXaa2LmdVvpxWu3GaeQD02lq53Za7cdprRunFZmdx6id22mtH6f1bpxWRXYio3Zup/V+nDY6clpnJzJq53ba6MdpsxunNYWdyKi9gdPCjkDCMEz1hCdyfvU0lme6eK+mHrZQT8aDaIynklZwl/fTVT21dfmqnq7qic/pq3q6qqererqqp3qnr+rpkHrCcxq3egKqcQ+m6kPq4WH1tHqZR87iN5aGmon3U11WxgWDeW8RZ5PQtZGniigqknZPm7HTNfO168KM6L2euWnWLzu6QKwheTuK0stD4CcxpjO2HeduOI4cPEK2I2jFyTh2rLvho+PBePAFbgd/BJ7lE9wxYrFU2I5LX1aOn+DBtrQQZdlTyeNYEowwhLKAKYpi66maRWPQgkajZv45SuM0WEcOjDBrJb727mLW9gtyckeVXJm71pMfi7v//v6Hnz1JrZnIjrL3FyqO/yQhLnG3e4+TJjqgyjS11v1smv7lp0mWaqa+ozR9ffHmAQ05ylHpBidBVCeeYwzKZs0k+d1jkEbcecagorWdCDqPQSpQzzMGVaVtou8wBqmYPccY1EDbTP5aMUg18XnGoGa0TfAdxCCnisYjjltFy1NVAYoppxS0VtFANqcTUVMKivP+Lalo1L9IlokPTfuzm7XJrlYaSy4As+0QdYMtjD7DBHXKEbearj92tphY9mtykl/pS8ZBtw6vMEbO04qlQ/fXC0Hxhsrwa1cz0iHX0q9uVhA7Ww58pTHYdJGwsxW/1xmDh5cBa8ZgZVGv2Rjc1Uw9jsGmy3ydrdm90hhsupLX2bLc64zBw2t1NWOwsvJ2bAxyagacVLg1g6IqClClzP/WmkHS1aliHtm9zDtE1lVNlkW68rbTAZnY6EMz1G3uiTLdthWKoruLeNjOpRtPXno7B01SR5uusmkj9hNlDKbiDGRM3aahojOpoPYTlQ9+mfrOyqduGxGYTBqo/USx1HNwdLWjagI2FcR+or7qNzga66u6fVaNnV6p/URJ1mNwdLXzKrPTJbWfqOJ6Do6O9mM1kZ0uqf1E4ddvcDQWfnVU6OyUSe3da0UMyq0V1Yl0r4gPmcZrrRXvx7qmqmBaUJj3YUkr6tJkiqQiPe5wNloRgJz/g6KH2K9acZ82Q2bTRuzvQyuqKpMKar98rSjpTBqo/Z1oRZNNBbG/D62os9MrtV++VlTY6ZLa34dWBOx0Se3vQysa7JRJ7d1rRRw93FpREzVZRDov9bD9XqQkjjWkOwsK8z4sacU8qjuJ4vM/J/HG1F+fpyfemPrjPVNxmeqv11MWb0z99Xn24o2pP94TGReq/sh+7nEaOtnvfRvqr9eTG29M/fGe5+hI/eFhw63+9Ikq6tPJyepvpqiaPk7fAHb7sKT+pKlpACn9YZTz2VVm91eLoyHvY6WQPR3WHgW5IK1Izm0cp6JyruNSVwrZ02HtuY0L0orkDAaDirozGhekFcmBiuNUVA5cXOpKITtd1h6ouBytSA9HHKei9vDEBWlFctKBQcX+SYjmWtEnGtEv/VIK/um60WJNftiO3JRMXdZ0/NdfuMKOnMwaS4WhQIAqqHiurqCqhqHLsgi046BU7B0BxbNeBdSQdNFEzTWPg+a784dA8RxSAZUAUDUNKBIDVWehkr35CqvAVAz8h8eVn/8rUGUWKlnF3UeVNQB0SdSpgj8IKrFAyctBhQADtdQ0WC3NR9shUBxxVf9VFWjonyYdR6VRl6HSK31b+fg/AAAA//8DAFBLAwQUAAYACAAAACEAM+g/fo0KAAB1XgAADwAAAHdvcmQvc3R5bGVzLnhtbNycW2/buBLH3w9wvoPg99SX2Llh00WaptsAbTdbJ9hnWqJjoZLoI8l1sp9+SUqyKY9IcyhmFzgvsXWZn0j+Z4YaWeEvv76kSfCT5kXMsuvB+N1oENAsZFGcPV8Pnh4/nVwMgqIkWUQSltHrwSstBr++/+9/ftleFeVrQouAA7LiKg2vB6uyXF8Nh0W4oikp3rE1zfjBJctTUvLN/HmYkvzHZn0SsnRNyngRJ3H5OpyMRmeDGpPbUNhyGYf0Iws3Kc1KaT/MacKJLCtW8bpoaFsb2pbl0TpnIS0K3uk0qXgpibMdZjwFoDQOc1awZfmOd6ZukURx8/FIfkuTPWCGA0wA4CykLzjGRc0YckuVE0c4ztmOE0cKx60xCiDaoBCT06Yd4kOYK6wiKqMVDtdoNBS2pCQrUqzaxGWCI04VYuVgCQt/qEyKG7TZDviaCg3T8Or+OWM5WSScxL0y4I4VSLD4y/URH/IrfZH7xbDUX5aJ+MJH7T0P3YiFH+mSbJKyEJv5Q15v1lvy4xPLyiLYXpEijOPrwWOc8mj/RrfBd5YSHhzbK0qK8qaISefB1U1WdJuFRcfuobhmQrJnfsJPwoeeZidP8/ZVdrsWccTRJD+Z30jLYd3q6lPpy3q3VZ920HOeNHgKmVeZjB+lyy9cMxrNS37gejASF+M7n+4f8pjlPFvt981pGn+Oo4hmynnZKo7onyuaPRU02u//45P0h3pHyDYZ/356fibFSIro7iWka5G++NGMpPzK34RBIs7+X2M7bgap6/wVJSJnB2O8yUSYFEpvJGNz0BUH8OlbgadvBZ69FfjsrcDnbwW+eCvwpW/wkrGS5hIS78P08tJkExK57bspj3GZUPvT55tFibQoc5Y9259/l675xBYX9hZV4gkexSRjOzyGARGYYB6na/4hzT3yrBOXJc86Xx3j3SaE30yG/jrcAL31uAF677J1aj4KZAnLl5vE4yA2RH+j2BD9DSNLNmlWeO20BPrsswR677JPz5FA68n8GPC3nN9Ze1NE0rzJIWnetJA0b0JIml8VrO+jrGjWN09WNOs7pmO0L3FR+vM3SfPmb5Lmzd8kzZu/SZo3f5M0b/4mad78TdK8+dvpx4AulzQsPc47CtOb7ylMj7NPVtJ0zXKSv/pi3iX0mWSlL9xDzpbi4STLqgcCPpii8kh83pFXPG9S/0kX/honYF5b5s37Hlc09VBlPSQkpCuWRDQPHumLxvOsi+NvLJivSRhXhaZqJ0F2deSX+HlVBvOVLPoPOWej46YixwE7i0uKuRjYTUx2X2kUb9KmrZXftaxPEdbS0VrWUwvr/ZTfMp3ZmsKrnlmY7m9sW6bntqbwqhe2pjKEWqZGl/xI8h+dHnFu9KRdgabxw3OjP+2sOy9sdKmdaZc3nhv9qRU4wU0Y0qzLNSwjSA+wDCU9ABVTegwquPQY+yjTM4zh9p3+jMUk3DO5yjY8kJw852S9OrQ9lTfDdhn2jw0r5eShAiby8aod4J7f+mQFDTpBp/KnCjtQKxPph9c+JekZ9rlJz7BPUnqGXbbS2uPSlh5jn7/0DPtEpmfgMxqcO5AZDQKQGQ0CnDIaxDhltD73DXqG/Q2EnoEPW8jAh22fews9Axe2wN4tbCEGH7aQgQ9byMCHLbxvQ4YtBCDDFgKcwhZinMIWYvBhCxn4sIUMfNhCBj5sIQMftq61gdbeLWwhBh+2kIEPW8jAh628rewTthCADFsIcApbiHEKW4jBhy1k4MMWMvBhCxn4sIUMfNhCBi5sgb1b2EIMPmwhAx+2kIEPW/ljRp+whQBk2EKAU9hCjFPYQgw+bCEDH7aQgQ9byMCHLWTgwxYycGEL7N3CFmLwYQsZ+LCFDHzYyl8N+4QtBCDDFgKcwhZinMIWYvBhCxn4sIUMfNhCBj5sIQMftpCBC1tg7xa2EIMPW8jAhy1kGD21/r1SfT1SNR47PEXVsSbyaZn9C6G8Wd/pkuY0C+FDWQSraZceJp8H2ME+MPYj2L3d2qLI8sSSEi+SmMkH35of21WwfFsC96Pq77fB5+o14+N4KXEH3rYzDwmJs+o9WfhAdGptCh7KTI3Or5qCwnBq9HnVFNycTo0ZWTUFE+TUmIhlkDZvrfBpClgb045iPdbYG1O4Yg8H2pi4FUs4zsZ0rVjCYTYmacVyFoiMfWg+sx2ss927qQBh9EwFca5HGD0UStbkaBgl1trpEdYi6hHWauoROFm1HAd99Sy80HqWo+Iw5tCK9whbPQKtOES4KQ44PRSHLHfFIctRcZgr0YpDBFrxHhlbj3BTHHB6KA5Z7opDlqPicI5DKw4RaMUhAq1438lay+mhOGS5Kw5ZjorDO0C04hCBVhwi0IpDhJvigNNDcchyVxyyHBUH1TVecYhAKw4RaMUhwk1xwOmhOGS5Kw5ZRsXlU5iW4jihFXvkfZpiiZysFUtkxlYsXcorxdy1vFIQruUVlKzRHlleqdrpEdYi6hHWauoROFm1HAd99Sy80HqWo+LI8qpL8R5hq0egFUeWV1rFkeWVUXFkeWVUHFle6RVHllddiiPLqy7Fe2RsPcJNcWR5ZVQcWV4ZFUeWV3rFkeVVl+LI8qpLcWR51aV438lay+mhOLK8MiqOLK/0iiPLqy7FkeVVl+LI8qpLcWR5pVUcWV4ZFUeWV0bFkeWVXnFkedWlOLK86lIcWV51KY4sr7SKI8sro+LI8sqoOLK8+sptYsv/GNrifuqcpyQvg8+va5oncSYrGd+X+EyKVUmO/5LqgH7Kclqw5CeNgjcfoy99h2e4bS0TJy4nl77kBiUf/+vBWv1vrqhaXa6+hjzxPtqt5yaMReOCepG7Zpk32Yn6d+dqIy94mV+fNRqNL0ejm+bX3XqBvuKv5vik+fG2+OtWLGPX3lkvqqcso5ec/Pa96Vqzbp5sKexbuOKdC+v1tTR9qxfU2/1Tm1g4EPS0WYZvd1YgT6uauJeiOb0Rdq9afWZLoroPmraXIooN7ZZRbhSmSgTaRu7+0+94K3mbFkmlG/9ynwltt/V6gFVroxdS0/gJtzRJvpLqdLY2nJvQZVkdHo/kghCHJyxYWbLUQMjlTKRHDNsNqjbNTpNt0gXN67cwtAEhMm3HuMtXg3wMuaVTh5uCD5CM7cM20pTEidwan4OWtg52t+l4DB8usnmTx9UiD/XqmbttsWbm/mAs1o+sB7YGhmKqai5GNiXbpYRm56SZQ1tZotp5PBG0ktxuhD6QJGEsk4sOHA5QfaxekaByRsK1+V1kaJj9zIN3+WE6mTV3RboVSsmKpUQZvf0OueRovXUwLOOGqg5LvdN1WMRLSNy7DkdELIEonO7oWIgpvTlQsW65yza9bw3MbDY5n93Vh9Z1hiELOU3xz+ZEcftS+fua8bGYnu68QTlJpoLdORdn9bs5IuQlcVhfoX9kKZ06HKTqUKB0GI7G8ZH4J+fIbh/4VC1Ledi9ZrVKlA9ULGVIDInx/8E9lP4ejl91SOce9aD3GaR/33PEBLhfIeBwAGSBoiwgcNSR4DCIVQbkIcMd5+Xt+O7ytu04sbxtEbcc4h3dxkNCsYTSS7khSb1qTN33A19ovhXv/wYAAP//AwBQSwMEFAAGAAgAAAAhABgahsVlAQAAIQQAABQAAAB3b3JkL3dlYlNldHRpbmdzLnhtbJzTUW/CIBAA4Pcl+w8N70p1akxja7IsJnve9gMQrpYIXAO46n79oFZX44vdSzna3pcDjtX6qFXyDdZJNDmZjFOSgOEopNnl5OtzM1qSxHlmBFNoICcncGRdPD+tmqyB7Qd4H/50SVCMyzTPSeV9nVHqeAWauTHWYMLHEq1mPkztjmpm94d6xFHXzMutVNKf6DRNF6Rj7CMKlqXk8Ib8oMH4Np9aUEFE4ypZu4vWPKI1aEVtkYNzYT1anT3NpLkyk9kdpCW36LD047CYrqKWCumTtI20+gPmw4DpHbDgcBxmLDuDhsy+I8UwZ3F1pOg5/yumB4jDIGL6cqkjDjG9ZznhRTWMu5wRjbnMs4q56lYs1TBx1hPPDaaQ7/smDNu0+RU86XiGmmfvO4OWbVWQQlcmobGSFo7PcD5xaEM4tu/jtnRBqWIQdq0I9xdrL7X8gQ3aV4uNA5vQYkVvLnbxCwAA//8DAFBLAwQUAAYACAAAACEA5Mjq780CAACUDQAAEgAAAHdvcmQvZm9udFRhYmxlLnhtbOSVW2+bMBSA3yftPyDeWwyBJI2aVkkv0l72sHbas2NMsIJtZpsm+fc75pLQhawhkyJNC1Iwx/jD/jg+3N5veOa8UaWZFFPXv0auQwWRMRPLqfv99flq7DraYBHjTAo6dbdUu/d3nz/drieJFEY7MF7oCSdTNzUmn3ieJinlWF/LnAroTKTi2MClWnocq1WRXxHJc2zYgmXMbL0AoaFbY9QpFJkkjNBHSQpOhSnHe4pmQJRCpyzXDW19Cm0tVZwrSajWsGaeVTyOmdhh/PAAxBlRUsvEXMNi6hmVKBjuo7LFsz0g6gcIDgBDQjf9GOOa4cHINofF/TjDHYfFLc55k2kB4qIXIhg087AnO7zF0rGJ03645h15diw2OMU6fU9Msn7EsEWsEiyTZNVm0n7Soh1wy+075GTyZSmkwosMSJCVDiSWU4LtP7wfeyqbdFPGrZa6kWS2Adbu6p3rrCcCcwDNFMNZGc6xkJr60POGYfEgaY6GKERWV3WEruPZO0mKlaaWUd458+t4gjnLtk1Yr5nWdU/ODEmbjjcMz4RV1H2aLaGn0As0dZ8QQsHT87NbRfyp+wCR0Tia15EAJlb9burIYBdBNkJKTnnpVxxScvb3wEO9SsKBjFfGqXa+0rXzTXIsjmgJQMsARaAmgvagpxZVkv8pLQ+yUIwqK+aIkhFouCnVWCVhTyVcxlR1OknYhsY9hISDiwj5Ad8K+43UnTqihrH/detAQacOXBjZM0HaK6t8+O8jex9NpNPH+H3kVB8vW76Q3VUkgsNH9rM4gm1j82PUS8Y52+W3lV7axitOYdJ/rKlV+bC19QI11e/aK0N0WDyCj/aKf8ZemUu5cmbCsJ/FMSdhnRnWyuAiBbVa7ni0d9Je7+kZUl3f9HUyy43UziPTeYa3RxMFnfLx3dWWv0+U4JiUw6L6sRT/PCn/rYy6oe9+AQAA//8DAFBLAwQUAAYACAAAACEAietUB8kBAABaAwAAEQAIAWRvY1Byb3BzL2NvcmUueG1sIKIEASigAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAnJPNbtQwEMfvSLxD5BOXrJOsaEuUTSVAPVGpEotA3Iw93ZomtmV7m+YxKg6IhQpWhUNfxs/USXaTfp64RDP/+c/PH+MU++d1FZ2BdVKrGUknCYlAcS2kWszIh/lBvEci55kSrNIKZqQFR/bL588KbnKuLRxZbcB6CS5CknI5NzNy4r3JKXX8BGrmJuhQWDzWtmYeU7ughvFTtgCaJckOrcEzwTyjHTA2I5FskYKPSLO0VQ8QnEIFNSjvaDpJ6a3Xg63dkw195Y6zlr418KR1KI7ucydHY9M0k2baW3H/Kf10+O59f9RYqu6uOJCyEDz30ldQhlX4F/6EdfgRLjD+Ha4i/KzDN0wvUbwKvzbiBUprDP+iuArX4TLCtp/hO4rX6OmEF2FV0JHcreGWX74C92UvjwnG3ALz2pa1AW+l0MveMajd+E6hbbQVDnvvZZhUzPlDfATHEsTrtjRMsVZqL13EdX9EL1VHfGztui2cye49lVnvGNOBfGSl8iDKLMlexmkap7vz5FWe7eZJ8nlkDqZiO9HN1kFEOIl8M7eh8nH65u38gHS8nZ63N0+n+XTLe9B/C6y3u/5v4gDYXOD9v6G8AQAA//8DAFBLAwQUAAYACAAAACEArD4Tqi4CAABABAAAEAAIAWRvY1Byb3BzL2FwcC54bWwgogQBKKAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACcVMFu00AQvSPxD5ZPXBLbAVoUbbZCqVAOQCPFbc/LepKsut61dreh4S8qDhWBCqLCoT+z38SsnRqHcuJivXk7O34z82xydFXKaAXGCq1GcdZP4wgU14VQi1F8mr/pvYoj65gqmNQKRvEabHxEnz4hU6MrME6AjbCEsqN46Vw1TBLLl1Ay28djhSdzbUrmMDSLRM/ngsOx5pclKJcM0vQggSsHqoCiV7UF46bicOX+t2ihedBnz/J1hfUoyaGsJHNA34ebkiQtQXLtmMxFCTRDug3IlC3ABq4B5FybwtJBlpKkgWS8ZIZxh8Oj2csU+Q5BXleVFJw5nCt9J7jRVs9ddFKLjUIBknRTCDYwA35phFtTLNUNyVuhgpQBSRqE2gxbGFYtLX0eBLYRmXEmYYy90zmTFkjyhyATYGGvUyaCwJUbroA7bSIrPuFmB3H0gVkIExvFK2YEUy5u0pqgxrKyztBcOIm127iG3bQuFi/CFBuwn1gHtQbE++rqN9iTOfbm/iE264qtNTRSGzl+43/5H37rv/hrxN/9XYSPrf+M4S2Sd/5bQ14jtUX4E8mNv/e3EV776m+QvMecQDzzm0eNPkj+S+RYlxVTazqBjxKc600Zv2CmiHY8+mOXEBZ6YU+rXB8HC+42tU923HUu3HJWMR48cJgedn3WOSIzZKFA47SrbwkywUEZGV6Ad9UCioecxwfBuWfND4FmB/00Dc7ucOi39kulvwEAAP//AwBQSwECLQAUAAYACAAAACEAiOnxKa4BAAD1CQAAEwAAAAAAAAAAAAAAAAAAAAAAW0NvbnRlbnRfVHlwZXNdLnhtbFBLAQItABQABgAIAAAAIQAqoxp78AAAAFECAAALAAAAAAAAAAAAAAAAAOcDAABfcmVscy8ucmVsc1BLAQItABQABgAIAAAAIQCCCKnfUx8AAE7TAAARAAAAAAAAAAAAAAAAAAgHAAB3b3JkL2RvY3VtZW50LnhtbFBLAQItABQABgAIAAAAIQDs7+i/ZgEAAFgIAAAcAAAAAAAAAAAAAAAAAIomAAB3b3JkL19yZWxzL2RvY3VtZW50LnhtbC5yZWxzUEsBAi0AFAAGAAgAAAAhAP8sMIXCAgAA8gsAABIAAAAAAAAAAAAAAAAAMikAAHdvcmQvZm9vdG5vdGVzLnhtbFBLAQItABQABgAIAAAAIQDYL5GWvwIAAOwLAAARAAAAAAAAAAAAAAAAACQsAAB3b3JkL2VuZG5vdGVzLnhtbFBLAQItABQABgAIAAAAIQB35M4HjAIAAM8KAAAQAAAAAAAAAAAAAAAAABIvAAB3b3JkL2hlYWRlcjEueG1sUEsBAi0AFAAGAAgAAAAhACxBs0yNAgAAzwoAABAAAAAAAAAAAAAAAAAAzDEAAHdvcmQvaGVhZGVyMi54bWxQSwECLQAUAAYACAAAACEAQzff1o0CAADPCgAAEAAAAAAAAAAAAAAAAACHNAAAd29yZC9mb290ZXIxLnhtbFBLAQItABQABgAIAAAAIQAAhVPq2AIAAJkMAAAQAAAAAAAAAAAAAAAAAEI3AAB3b3JkL2Zvb3RlcjIueG1sUEsBAi0AFAAGAAgAAAAhAOkPkL6OAgAAzwoAABAAAAAAAAAAAAAAAAAASDoAAHdvcmQvaGVhZGVyMy54bWxQSwECLQAUAAYACAAAACEA9C+yM40CAADPCgAAEAAAAAAAAAAAAAAAAAAEPQAAd29yZC9mb290ZXIzLnhtbFBLAQItAAoAAAAAAAAAIQBGC/mrKS0AACktAAAWAAAAAAAAAAAAAAAAAL8/AAB3b3JkL21lZGlhL2ltYWdlMS5qcGVnUEsBAi0AFAAGAAgAAAAhALwQH6A6BwAAtSIAABUAAAAAAAAAAAAAAAAAHG0AAHdvcmQvdGhlbWUvdGhlbWUxLnhtbFBLAQItABQABgAIAAAAIQCJQViwMQgAAMMdAAARAAAAAAAAAAAAAAAAAIl0AAB3b3JkL3NldHRpbmdzLnhtbFBLAQItABQABgAIAAAAIQBkPTZFdwgAAHFbAAASAAAAAAAAAAAAAAAAAOl8AAB3b3JkL251bWJlcmluZy54bWxQSwECLQAUAAYACAAAACEAM+g/fo0KAAB1XgAADwAAAAAAAAAAAAAAAACQhQAAd29yZC9zdHlsZXMueG1sUEsBAi0AFAAGAAgAAAAhABgahsVlAQAAIQQAABQAAAAAAAAAAAAAAAAASpAAAHdvcmQvd2ViU2V0dGluZ3MueG1sUEsBAi0AFAAGAAgAAAAhAOTI6u/NAgAAlA0AABIAAAAAAAAAAAAAAAAA4ZEAAHdvcmQvZm9udFRhYmxlLnhtbFBLAQItABQABgAIAAAAIQCJ61QHyQEAAFoDAAARAAAAAAAAAAAAAAAAAN6UAABkb2NQcm9wcy9jb3JlLnhtbFBLAQItABQABgAIAAAAIQCsPhOqLgIAAEAEAAAQAAAAAAAAAAAAAAAAAN6XAABkb2NQcm9wcy9hcHAueG1sUEsFBgAAAAAVABUAOAUAAEKbAAAAAA==";
function b64ToU8(b){var s=atob(b),u=new Uint8Array(s.length);for(var i=0;i<s.length;i++)u[i]=s.charCodeAt(i);return u}
function u8ToB64(u){var s="",k=0x8000;for(var i=0;i<u.length;i+=k)s+=String.fromCharCode.apply(null,u.subarray(i,i+k));return btoa(s)}
function xmlUnesc(s){return s.replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&quot;/g,'"').replace(/&apos;/g,"'").replace(/&amp;/g,"&")}
function xmlEsc(s){return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}
function ntRe(){return new RegExp("\\[("+NT_PH.join("|")+")\\]","g")}
/* Replaces the [placeholders] of every paragraph. A placeholder may be split over several runs by Word: the replacement goes into the run where it starts (so it keeps that run's formatting) and the rest of the placeholder is removed from the following runs. */
function ntFillXml(xml,map){
  return xml.replace(/<w:p[ >][\s\S]*?<\/w:p>/g,function(p){
    if(p.indexOf("[")<0)return p;
    var runs=[],tre=/<w:t(?:\s[^>]*)?>([\s\S]*?)<\/w:t>/g,m,text="";
    while((m=tre.exec(p))){runs.push({s:m.index,e:m.index+m[0].length,t:xmlUnesc(m[1]),o:text.length});text+=xmlUnesc(m[1])}
    var re=ntRe(),out=text.split(""),hit=false;
    while((m=re.exec(text))){hit=true;out[m.index]=map[m[1]]==null?"":String(map[m[1]]);for(var k=m.index+1;k<m.index+m[0].length;k++)out[k]=""}
    if(!hit)return p;
    for(var i=runs.length-1;i>=0;i--){
      var r=runs[i],nt=out.slice(r.o,r.o+r.t.length).join("");
      p=p.slice(0,r.s)+'<w:t xml:space="preserve">'+xmlEsc(nt)+'</w:t>'+p.slice(r.e);
    }
    return p;
  });
}
function ntParts(z){return Object.keys(z).filter(function(n){return /^word\/(document|header\d*|footer\d*)\.xml$/.test(n)})}
async function ntBuild(bin,map){
  var z=await zipRead(bin.buffer.slice(bin.byteOffset,bin.byteOffset+bin.byteLength));
  if(!z["word/document.xml"])throw new Error("Το πρότυπο δεν είναι έγκυρο έγγραφο Word.");
  var dec=new TextDecoder("utf-8"),enc=new TextEncoder();
  ntParts(z).forEach(function(n){z[n]=enc.encode(ntFillXml(dec.decode(z[n]),map))});
  var names=Object.keys(z).sort(function(a,b){return a==="[Content_Types].xml"?-1:b==="[Content_Types].xml"?1:0});
  return zipBuild(names.map(function(n){return {name:n,data:z[n]}}));
}
/* which placeholders a template contains (used when a template is uploaded) */
async function ntInspect(buf){
  var z=await zipRead(buf);
  if(!z["word/document.xml"])throw new Error("Το αρχείο δεν είναι έγκυρο έγγραφο Word (.docx).");
  if(Object.keys(z).some(function(n){return /vbaproject|activex/i.test(n)}))throw new Error("Το πρότυπο περιέχει macros και απορρίφθηκε.");
  var dec=new TextDecoder("utf-8"),txt="";
  ntParts(z).forEach(function(n){dec.decode(z[n]).replace(/<w:p[ >][\s\S]*?<\/w:p>/g,function(p){var t="",m,tre=/<w:t(?:\s[^>]*)?>([\s\S]*?)<\/w:t>/g;while((m=tre.exec(p)))t+=xmlUnesc(m[1]);txt+=t+"\n";return ""})});
  var found=[],re=ntRe(),m;while((m=re.exec(txt)))if(found.indexOf(m[1])<0)found.push(m[1]);
  return found;
}
async function ntGet(){
  if(window.RL_NOTE_TPL){
    var r=await window.RL_NOTE_TPL.get(),t=r&&r.template;
    if(t&&t.custom&&t.data)return {custom:true,name:t.name,at:t.at,bytes:t.bytes,bin:b64ToU8(t.data)};
  }else{
    try{var o=JSON.parse(localStorage.getItem(NT_KEY)||"null");if(o&&o.data)return {custom:true,name:o.name,at:o.at,bytes:o.bytes,bin:b64ToU8(o.data)}}catch(e){}
  }
  return {custom:false,name:"Σημείωμα-προεπιλεγμένο.docx",at:0,bytes:0,bin:b64ToU8(NOTE_TPL_B64)};
}
function ntInfoHtml(t){return t.custom?'Χρησιμοποιείται <b>προσαρμοσμένο πρότυπο</b>: «'+esc(t.name)+'» ('+Math.round(t.bytes/1024)+' KB'+(t.at?', ανέβηκε '+fmtDate(iso(new Date(t.at*1000))):'')+').':'Χρησιμοποιείται το <b>προεπιλεγμένο πρότυπο</b> της εφαρμογής.'}
function ntCard(){
  var can=stCanEdit();
  return '<div class="stcard" id="ntCard"><h3>Πρότυπο Σημειώματος ανανέωσης (Λογισμικά)</h3>'+
   '<p class="hint">Το κουμπί «Ετοιμασία Σημειώματος» στις λεπτομέρειες κάθε Λογισμικό συμπληρώνει αυτό το αρχείο Word. Για αλλαγή: κατέβασε το τρέχον πρότυπο, επεξεργάσου το στο Word (άφησε τα πεδία σε αγκύλες όπως είναι) και ανέβασέ το ξανά.</p>'+
   '<p class="hint" id="ntInfo">Φόρτωση…</p>'+
   '<details><summary>Πεδία που συμπληρώνονται αυτόματα</summary><ul class="hint">'+NT_PH.map(function(k){return '<li><code>['+esc(k)+']</code> — '+esc(NT_PH_INFO[k])+'</li>'}).join("")+'</ul></details>'+
   '<div class="actions"><button type="button" class="btn" data-act="ntdl">⬇ Λήψη τρέχοντος προτύπου</button>'+(can?'<button type="button" class="btn primary" data-act="ntup">⬆ Ανέβασμα νέου προτύπου (.docx)</button><button type="button" class="btn" data-act="ntreset">↩ Επαναφορά στο προεπιλεγμένο</button>':'')+'</div>'+
   (can?'':'<p class="hint">Μόνο οι διαχειριστές μπορούν να αλλάξουν το πρότυπο.</p>')+'<p class="hint" id="ntMsg"></p></div>';
}
async function ntShowInfo(){
  var e=$("#ntInfo");if(!e)return;
  try{e.innerHTML=ntInfoHtml(await ntGet())}catch(x){e.textContent="Δεν ήταν δυνατή η ανάγνωση του προτύπου."}
}
function ntMsg(t,bad){var e=$("#ntMsg");if(e){e.textContent=t;e.className=bad?"err":"hint"}}
async function ntDownloadTpl(){
  try{var t=await ntGet();await offer(t.custom?t.name:"Σημείωμα-πρότυπο.docx",t.bin)}catch(e){ntMsg("Δεν ήταν δυνατή η λήψη του προτύπου.",true)}
}
function ntPick(){
  var inp=document.createElement("input");inp.type="file";inp.accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document";
  inp.onchange=function(){if(inp.files&&inp.files[0])ntUpload(inp.files[0])};inp.click();
}
async function ntUpload(f){
  try{
    if(f.size>NT_MAX){ntMsg("Το αρχείο είναι πολύ μεγάλο (μέγιστο 2 MB).",true);return}
    var buf=await f.arrayBuffer(),found=await ntInspect(buf),u=new Uint8Array(buf),b64=u8ToB64(u);
    if(window.RL_NOTE_TPL){await window.RL_NOTE_TPL.save(f.name,b64)}
    else{try{localStorage.setItem(NT_KEY,JSON.stringify({name:f.name,at:Math.floor(Date.now()/1000),bytes:u.length,data:b64}))}catch(e){ntMsg("Δεν ήταν δυνατή η αποθήκευση του προτύπου σε αυτόν τον browser.",true);return}}
    var miss=NT_PH.filter(function(k){return found.indexOf(k)<0});
    ntMsg("Το πρότυπο αποθηκεύτηκε."+(found.length?" Βρέθηκαν "+found.length+" από τα "+NT_PH.length+" πεδία."+(miss.length?" Δεν υπάρχουν στο πρότυπο: "+miss.map(function(k){return "["+k+"]"}).join(", ")+".":""):" ΠΡΟΣΟΧΗ: δεν βρέθηκε κανένα πεδίο σε αγκύλες· το σημείωμα θα βγαίνει χωρίς συμπληρωμένα στοιχεία."),!found.length);
    ntShowInfo();
  }catch(e){ntMsg(e&&e.status===403?"Μόνο οι διαχειριστές μπορούν να αλλάξουν το πρότυπο.":((e&&e.message)||"Αποτυχία αποθήκευσης του προτύπου."),true)}
}
async function ntReset(){
  if(!window.confirm("Να επανέλθει το προεπιλεγμένο πρότυπο; Το προσαρμοσμένο πρότυπο θα διαγραφεί."))return;
  try{if(window.RL_NOTE_TPL)await window.RL_NOTE_TPL.reset();else{try{localStorage.removeItem(NT_KEY)}catch(e){}}ntMsg("Επανήλθε το προεπιλεγμένο πρότυπο.");ntShowInfo()}
  catch(e){ntMsg("Αποτυχία επαναφοράς: "+((e&&e.message)||""),true)}
}
/* the dialog on a software record */
function ntStart(id){
  var it=byId(id);if(!it)return;
  var nf=it.dateTo?addDays(it.dateTo,1):todayIso(),ba=(it.budget||[]).filter(function(p){return p&&p.article})[0];
  S.nt={id:id,err:"",d:{date:todayIso(),name:it.name||"",desc:it.description||"",from:nf,to:addYear(nf),cost:it.cost==null?"":String(it.cost),article:ba?ba.article:""}};
  ntDraw();
}
function ntCollect(){var w=S.nt;if(!w)return;[["date","nt_date"],["name","nt_name"],["desc","nt_desc"],["from","nt_from"],["to","nt_to"],["cost","nt_cost"],["article","nt_art"]].forEach(function(p){var e=$("#"+p[1]);if(e)w.d[p[0]]=e.value})}
function ntDraw(){
  var w=S.nt,d=w.d;
  openPanel('<div class="ph"><h2>Ετοιμασία Σημειώματος</h2><button class="btn small" type="button" data-act="back" data-id="'+esc(w.id)+'">Άκυρο</button></div>'+
   '<p class="hint">Δημιουργεί αρχείο Word από το πρότυπο των Ρυθμίσεων. Έλεγξε ή διόρθωσε τα στοιχεία· η περίοδος και το κόστος προτείνονται για την επόμενη ανανέωση (η δαπάνη δεν καταχωρείται, αυτό γίνεται από το «Renew…»).</p>'+
   '<div style="display:grid;gap:12px">'+
   '<label class="f">ΗΜΕΡΟΜΗΝΙΑ ΣΗΜΕΙΩΜΑΤΟΣ<input id="nt_date" type="date" value="'+esc(d.date)+'"></label>'+
   '<label class="f">ΛΟΓΙΣΜΙΚΟ<input id="nt_name" type="text" value="'+esc(d.name)+'" autocomplete="off"></label>'+
   '<label class="f">ΣΚΟΠΟΣ ΧΡΗΣΗΣ / ΠΕΡΙΓΡΑΦΗ<textarea id="nt_desc">'+esc(d.desc)+'</textarea></label>'+
   '<div class="grid2"><label class="f">ΠΕΡΙΟΔΟΣ ΑΝΑΝΕΩΣΗΣ ΑΠΟ<input id="nt_from" type="date" value="'+esc(d.from)+'"></label><label class="f">ΕΩΣ<input id="nt_to" type="date" value="'+esc(d.to)+'"></label></div>'+
   '<label class="f">ΚΟΣΤΟΣ ΑΝΑΝΕΩΣΗΣ (€ χωρίς ΦΠΑ)<input id="nt_cost" type="number" step="0.01" min="0" inputmode="decimal" value="'+esc(d.cost)+'"></label>'+
   '<label class="f">ΑΡΘΡΟ ΠΡΟΫΠΟΛΟΓΙΣΜΟΥ *<select id="nt_art">'+artOpts(d.article,true)+'</select></label></div>'+
   '<div class="err" id="nterr">'+esc(w.err)+'</div><div class="actions"><button class="btn primary" type="button" data-act="ntgen">⬇ Δημιουργία Σημειώματος (.docx)</button></div>',"renew");
  var f=$("#nt_from");if(f)f.addEventListener("change",function(){var v=f.value;if(parseIso(v))$("#nt_to").value=addYear(v)});
}
async function ntGen(){
  ntCollect();var w=S.nt,d=w.d,e="";
  var cost=Number(d.cost),art=artFind(d.article,articles());
  if(!parseIso(d.date))e="Η ημερομηνία του σημειώματος δεν είναι έγκυρη.";
  else if(!String(d.name).trim())e="Συμπλήρωσε το όνομα του λογισμικού.";
  else if(!parseIso(d.from)||!parseIso(d.to))e="Συμπλήρωσε και τις δύο ημερομηνίες της περιόδου ανανέωσης.";
  else if(d.to<d.from)e="Η λήξη της περιόδου πρέπει να είναι μετά την έναρξη.";
  else if(d.cost===""||!isFinite(cost)||cost<0)e="Συμπλήρωσε το κόστος ως αριθμό (0 ή μεγαλύτερο).";
  else if(!String(d.article||"").trim())e="Επίλεξε το άρθρο προϋπολογισμού.";
  if(e){w.err=e;var x=$("#nterr");if(x)x.textContent=e;return}
  var desc=String(d.desc||"").replace(/\s+/g," ").trim().replace(/[.\s]+$/,"");
  var map={"Σημερινή Ημερομηνία":fmtDate(d.date),"Software Name":String(d.name).trim(),"Description":desc||"………","Renewal Date From":fmtDate(d.from),"Renewal Date To":fmtDate(d.to),"Cost":bdNum(cost),"Κωδικός Άρθρου":art?art.code:String(d.article),"Περιγραφή Άρθρου":art?art.desc:""};
  try{
    var t=await ntGet(),out=await ntBuild(t.bin,map);
    var fn=("Σημείωμα ανανέωσης - "+String(d.name).trim()).replace(/[\\\/:*?"<>|\r\n]+/g," ").replace(/\s+/g," ").trim().slice(0,120)+".docx";
    await offer(fn,out);
  }catch(x){w.err="Δεν ήταν δυνατή η δημιουργία του σημειώματος: "+((x&&x.message)||"");var y=$("#nterr");if(y)y.textContent=w.err}
}
/* =============== ΓΕΝΙΚΕΣ ΠΡΟΝΟΙΕΣ (3.16.0) =============== */
/* A general provision reserves money for budget purposes: description, related budget article, attachments and amounts (net of VAT) for the 3 years after the registration year. The amounts are counted in the Budget. */
function pvYears(p){var b=+p.baseYear||new Date().getFullYear();return [b+1,b+2,b+3]}
function pvAmt(p,y){var a=(p.amounts||[]).filter(function(x){return +x.year===y})[0];return a&&a.amount!==""&&a.amount!=null&&isFinite(Number(a.amount))?Number(a.amount):""}
function pvSum(p){return r2(pvYears(p).reduce(function(s,y){return s+(Number(pvAmt(p,y))||0)},0))}
function pvArtText(p){var a=artFind(p.article,articles());return a?a.code+" — "+a.desc:String(p.article||"")}
function pvAllYears(list){var m={};list.forEach(function(p){pvYears(p).forEach(function(y){m[y]=1})});return Object.keys(m).map(Number).sort(function(a,b){return a-b})}
function pvFiltered(){
  var q=String(S.q||"").trim().toLowerCase();
  return (S.provisions||[]).filter(function(p){return !q||[p.title,pvArtText(p),p.notes,p.baseYear].join(" ").toLowerCase().indexOf(q)>=0})
    .sort(function(a,b){return (+b.baseYear||0)-(+a.baseYear||0)||String(a.title).localeCompare(String(b.title),"el")});
}
function renderPv(){
  var all=S.provisions||[],yrs=pvAllYears(all),vat=bdVat();
  $("#stats").innerHTML='<div class="stat"><b>'+all.length+'</b><span>Γενικές Πρόνοιες</span></div>'+yrs.map(function(y){var t=r2(all.reduce(function(s,p){return s+(Number(pvAmt(p,y))||0)},0));return '<div class="stat"><b class="num" style="font-family:var(--f-display)">'+bdNum(t)+'</b><span>Σύνολο <b class="yr">'+y+'</b> (€, χωρίς ΦΠΑ· με ΦΠΑ '+bdNum(r2(t*(1+vat)))+')</span></div>'}).join("");
  $("#alerts").innerHTML="";
  $("#chips").innerHTML=[["all","Όλες"],["trash","🗑 Κάδος"+(S.trash.pv.length?" ("+S.trash.pv.length+")":"")]].map(function(c){return '<button type="button" class="chip" data-f="'+c[0]+'" aria-pressed="'+(S.filter===c[0])+'">'+c[1]+'</button>'}).join("");
  var rows=pvFiltered(),h;
  if(!all.length)h='<div class="empty"><h2>Δεν υπάρχουν Γενικές Πρόνοιες ακόμα</h2><p>Κατέγραψε εδώ γενικές πρόνοιες για σκοπούς προϋπολογισμού: περιγραφή, σχετικό άρθρο και ποσά για τα επόμενα 3 έτη. Τα ποσά περνούν αυτόματα στον Προϋπολογισμό, στο σχετικό άρθρο.</p><div class="actions"><button class="btn primary" type="button" id="emAdd">+ Νέα Γενική Πρόνοια</button></div></div>';
  else if(!rows.length)h='<div class="empty"><h2>Κανένα αποτέλεσμα</h2><p>Δοκίμασε άλλη αναζήτηση.</p></div>';
  else{
    var ty=yrs.map(function(){return 0}),tt=0;
    h='<div class="tbl"><table class="art pvt"><thead><tr><th>ΠΕΡΙΓΡΑΦΗ</th><th>ΑΡΘΡΟ</th><th>ΕΤΟΣ ΚΑΤΑΧΩΡΗΣΗΣ</th>'+yrs.map(function(y){return '<th class="num">'+y+'<br>€ χωρίς ΦΠΑ</th>'}).join("")+'<th class="num">ΣΥΝΟΛΟ</th><th>ΣΥΝΗΜΜΕΝΑ</th><th></th></tr></thead><tbody>'+rows.map(function(p){
      var ys=pvYears(p),s=pvSum(p);tt=r2(tt+s);
      return '<tr><td><b>'+esc(p.title)+'</b></td><td>'+esc(pvArtText(p)||"—")+'</td><td class="mono">'+esc(p.baseYear)+'</td>'+yrs.map(function(y,i){var v=ys.indexOf(y)>=0?pvAmt(p,y):"";if(v!=="")ty[i]=r2(ty[i]+v);return '<td class="num">'+(v===""?"":bdNum(v))+'</td>'}).join("")+'<td class="num">'+bdNum(s)+'</td><td>'+((p.attachments||[]).length||"")+'</td><td><button class="btn small" type="button" data-act="pvopen" data-id="'+esc(p.id)+'">Άνοιγμα</button></td></tr>';
    }).join("")+'<tr class="tot"><td colspan="3">Σύνολα (εμφανιζόμενες γραμμές)</td>'+ty.map(function(v){return '<td class="num">'+bdNum(v)+'</td>'}).join("")+'<td class="num">'+bdNum(tt)+'</td><td colspan="2"></td></tr></tbody></table></div>';
  }
  $("#list").innerHTML=h;
}
function showPvDetail(id){
  var p=getItem("pv",id);if(!p)return;S.open=id;S.openCat="pv";
  var vat=bdVat(),ys=pvYears(p);
  var files=(p.attachments||[]).map(function(a,i){return '<li><a href="#" data-blob="'+esc(a.id)+'">'+esc(a.name)+'</a><button type="button" class="btn small danger" data-delfile="'+i+'">Αφαίρεση</button></li>'}).join("");
  openPanel(
   '<div class="ph"><div><h2>'+esc(p.title)+'</h2><span class="hint">Γενική Πρόνοια · καταχωρήθηκε το '+esc(p.baseYear)+'</span></div><button class="btn small" type="button" data-act="close">Κλείσιμο</button></div>'+
   '<dl class="kv wl">'+ownRow(p,"provisions")+'<dt>ΣΧΕΤΙΚΟ ΑΡΘΡΟ</dt><dd>'+esc(pvArtText(p)||"—")+'</dd>'+
   ys.map(function(y){var v=pvAmt(p,y);return '<dt>ΠΟΣΟ '+y+'</dt><dd class="num">'+(v===""?"—":bdEur(v)+' <span class="hint">χωρίς ΦΠΑ · με ΦΠΑ '+bdEur(r2(v*(1+vat)))+'</span>')+'</dd>'}).join("")+
   '<dt>ΣΥΝΟΛΟ</dt><dd class="num">'+bdEur(pvSum(p))+'</dd>'+
   '<dt>ΠΛΑΙΣΙΟ ΣΥΜΦΙΛΙΩΣΗΣ</dt><dd>'+(p.rcInclude?"Συμπεριλαμβάνεται":"Δεν συμπεριλαμβάνεται")+'</dd>'+
   '<dt>ΣΗΜΕΙΩΣΕΙΣ</dt><dd>'+esc(p.notes||"—")+'</dd></dl>'+
   '<p class="hint">Τα ποσά περιλαμβάνονται στην καρτέλα «Προϋπολογισμός», στο σχετικό άρθρο, με προσθήκη ΦΠΑ.</p>'+
   '<div class="sec"><h3>Συνημμένα</h3>'+(files?'<ul class="files">'+files+'</ul>':'<span class="hint">Δεν υπάρχουν συνημμένα.</span>')+
   '<div><button class="btn" type="button" data-act="attach"'+(S.assets?'':' disabled')+'>+ Προσθήκη αρχείων</button> <span class="hint">'+(S.assets?'Μέγιστο μέγεθος αρχείου '+attMB()+' MB.':'Η μεταφόρτωση δεν είναι διαθέσιμη σε αυτή την προβολή.')+'</span></div></div>'+
   '<div class="sec"><div class="actions"><button class="btn" type="button" data-act="edit">Επεξεργασία</button><button class="btn danger" type="button" data-act="pvdel">Διαγραφή</button></div><div id="delbox"></div></div>'
  ,"detail",true);
}
function pvStart(id){
  var p=id?getItem("pv",id):null,y=p?+p.baseYear:new Date().getFullYear();
  S.pv={id:id||null,err:"",d:{title:p?p.title:"",article:p?p.article:"",notes:p?p.notes||"":"",baseYear:y,attachments:p?(p.attachments||[]).slice():[],createdAt:p?p.createdAt:0,rc:!!(p&&p.rcInclude),amts:pvYears({baseYear:y}).map(function(yy){var v=p?pvAmt(p,yy):"";return v===""?"":String(v)})}};
  if(ownOn())S.pv.d.ownerId=p?(p._owner||""):ownMe();
  pvDraw();S.dirty=false;
}
function pvCollect(){
  var w=S.pv;if(!w)return;var d=w.d,g=function(i){var e=$("#"+i);return e?e.value:null};
  var t=g("pv_title");if(t!==null)d.title=t;var a=g("pv_article");if(a!==null)d.article=a;var n=g("pv_notes");if(n!==null)d.notes=n;
  for(var i=0;i<3;i++){var v=g("pv_amt_"+i);if(v!==null)d.amts[i]=v}
  var rcx=$("#pv_rc");if(rcx)d.rc=rcx.checked;
  var ow=g("pv_owner");if(ow!==null)d.ownerId=ow;
}
function pvDraw(){
  var w=S.pv,d=w.d,ys=pvYears({baseYear:d.baseYear});
  openPanel('<div class="ph"><h2>'+(w.id?"Επεξεργασία Γενικής Πρόνοιας":"Νέα Γενική Πρόνοια")+'</h2><button class="btn small" type="button" data-act="close">Άκυρο</button></div>'+
   '<p class="hint">Καταχωρείται το '+d.baseYear+'· τα ποσά αφορούν τα επόμενα 3 έτη ('+ys.join(", ")+') και δίνονται χωρίς ΦΠΑ.</p>'+
   '<div style="display:grid;gap:12px">'+
   '<label class="f">ΠΕΡΙΓΡΑΦΗ *<input id="pv_title" type="text" value="'+esc(d.title)+'" autocomplete="off" placeholder="π.χ. Πρόνοια για αναβάθμιση υποδομών"></label>'+
   '<label class="f">ΣΧΕΤΙΚΟ ΑΡΘΡΟ ΠΡΟΫΠΟΛΟΓΙΣΜΟΥ *<select id="pv_article">'+artOpts(d.article,true)+'</select></label>'+
   (ownOn()?'<label class="f">ΥΠΕΥΘΥΝΟΣ<small>'+esc(ownField("provisions").hint)+'</small>'+ownSelect("pv_owner",d.ownerId,"provisions",!!w.id)+'</label>':'')+
   ys.map(function(y,i){return '<label class="f">ΠΟΣΟ '+y+' (€ χωρίς ΦΠΑ)<input id="pv_amt_'+i+'" type="number" step="0.01" min="0" inputmode="decimal" value="'+esc(d.amts[i])+'" placeholder="0,00"></label>'}).join("")+
   '<label class="f">ΣΗΜΕΙΩΣΕΙΣ<textarea id="pv_notes">'+esc(d.notes)+'</textarea></label></div>'+
   rcChk("pv_rc",d.rc)+
   '<div class="sec"><h3>Συνημμένα</h3>'+((d.attachments||[]).length?'<ul class="files">'+d.attachments.map(function(a){return '<li><a href="#" data-blob="'+esc(a.id)+'">'+esc(a.name)+'</a></li>'}).join("")+'</ul>':'')+'<span class="hint">'+(w.id?'Τα συνημμένα προστίθενται και αφαιρούνται από το παράθυρο της πρόνοιας (κουμπί «Προσθήκη αρχείων»).':'Μετά την αποθήκευση ανοίγει το παράθυρο της πρόνοιας, όπου προσθέτεις τα συνημμένα.')+'</span></div>'+
   '<div class="err" id="werr">'+esc(w.err)+'</div><div class="actions"><button class="btn primary" type="button" data-act="pvsave">Αποθήκευση</button></div>',"wiz",true);
}
async function pvSave(){
  pvCollect();var w=S.pv,d=w.d,e="";
  if(!String(d.title).trim())e="ΠΕΡΙΓΡΑΦΗ: υποχρεωτικό πεδίο.";
  else if(!String(d.article||"").trim())e="Επίλεξε το σχετικό άρθρο προϋπολογισμού.";
  var any=false;
  d.amts.forEach(function(v,i){if(e||String(v).trim()==="")return;var n=Number(v);if(!isFinite(n)||n<0)e="ΠΟΣΟ "+(d.baseYear+i+1)+": μη έγκυρο ποσό (αριθμός ≥ 0).";else any=true});
  if(!e&&!any)e="Συμπλήρωσε ποσό για τουλάχιστον ένα έτος.";
  if(e){w.err=e;var x=$("#werr");if(x)x.textContent=e;return}
  var rec={rcInclude:!!d.rc,title:String(d.title).trim(),article:String(d.article).trim(),notes:String(d.notes||"").trim(),baseYear:d.baseYear,
    amounts:d.amts.map(function(v,i){return {year:d.baseYear+i+1,amount:String(v).trim()===""?"":r2(Number(v))}}),attachments:d.attachments||[],createdAt:d.createdAt||Date.now(),sample:false};
  var id=w.id||uid();
  if(ownOn()){var ov=Number(d.ownerId)||0;if(!ownWarn("provisions",ov,(w.id&&getItem("pv",w.id)||{})._owner))return;if(ov>0)rec._owner=ov}
  if(await save(id,rec,"pv")){closePanel();S.pv=null;toast(w.id?"Αποθηκεύτηκε":"Προστέθηκε: "+rec.title);showPvDetail(id)}
}
function pvExport(){
  if(needX())return;var vat=bdVat(),list=pvFiltered(),yrs=pvAllYears(list);
  var head=["ΠΕΡΙΓΡΑΦΗ","ΑΡΘΡΟ","ΕΤΟΣ ΚΑΤΑΧΩΡΗΣΗΣ"].concat(yrs.map(function(y){return y+" (χωρίς ΦΠΑ)"})).concat(["ΣΥΝΟΛΟ (χωρίς ΦΠΑ)","ΣΥΝΟΛΟ (με ΦΠΑ)","ΣΗΜΕΙΩΣΕΙΣ"]);
  var rows=list.map(function(p){var ys=pvYears(p);return [p.title,pvArtText(p),p.baseYear].concat(yrs.map(function(y){var v=ys.indexOf(y)>=0?pvAmt(p,y):"";return v===""?"":v})).concat([pvSum(p),r2(pvSum(p)*(1+vat)),p.notes||""])});
  if(!rows.length){toast("Δεν υπάρχουν πρόνοιες για εξαγωγή");return}
  offer("genikes-pronoies-"+todayIso()+".xlsx",wbBuffer(rows,null,head));
}
/* =============== ΠΛΑΙΣΙΟ ΣΥΜΦΙΛΙΩΣΗΣ (3.16.0) =============== */
/*RC-CALC-START*/
var RC_LIMIT=4999; /* a contract is reported when its total cost differs from the estimated cost of its tender by MORE than 4,999 € (up or down) */
function rcPct(base,cur){return base>0?Math.round((cur-base)/base*10000)/100:null}
function rcSets(tenders,contracts,limit,provs){
  limit=limit==null?RC_LIMIT:limit;
  var byProm={};(tenders||[]).forEach(function(t){if(t.promotedTo)byProm[t.promotedTo]=t});
  var dev=[],amd=[],inc=[],tamd=[];
  /* ΣΤ: ACTIVE tenders that were amended and whose amount changed (base = the tender before its first amendment) */
  (tenders||[]).forEach(function(t){
    if((t.status||"active")!=="active")return;
    var am=(t.amendments||[]).filter(function(a){return a&&Math.abs((Number(a.costAfter)||0)-(Number(a.costBefore)||0))>=0.005});
    if(am.length){var o=Number(t.amendments[0].costBefore)||0,cu=Number(t.cost)||0;tamd.push({t:t,base:o,cur:cu,diff:r2(cu-o),pct:rcPct(o,cu),n:t.amendments.length,list:t.amendments})}
  });
  (contracts||[]).forEach(function(c){
    var t=byProm[c.id],cur=ctTotal(c);
    if(t){var tc=Number(t.cost)||0,df=r2(cur-tc);if(Math.abs(df)>limit)dev.push({c:c,t:t,base:tc,cur:cur,diff:df,pct:rcPct(tc,cur)})}
    var am=(c.amendments||[]).filter(function(a){return a&&Math.abs((Number(a.costAfter)||0)-(Number(a.costBefore)||0))>=0.005});
    if(am.length){var orig=Number(c.amendments[0].costBefore)||0;amd.push({c:c,base:orig,cur:cur,diff:r2(cur-orig),pct:rcPct(orig,cur),n:c.amendments.length,list:c.amendments})}
    if(c.rcInclude)inc.push({c:c,cur:cur,n:(c.amendments||[]).length});
  });
  /* only ACTIVE tenders are listed (promoted tenders are found through byProm above, they are not listed) */
  return {tenders:(tenders||[]).filter(function(t){return (t.status||"active")==="active"}),dev:dev,amd:amd,inc:inc,tamd:tamd,provs:(provs||[]).filter(function(p){return p&&p.rcInclude})};
}
/*RC-CALC-END*/
/*RC2-CALC-START*/
/* Πλαίσιο Συμφιλίωσης (3.19.0): ONE table in the layout of the Word/Excel template. One row per record AND article:
   A) every active tender, B) contracts promoted from a tender whose total cost differs by more than RC_LIMIT, C) amended contracts whose amount changed,
   D) contracts with "Συμπερίληψη στο Πλαίσιο Συμφιλίωσης", E) general provisions with the same choice.
   Columns: current year Y (approved) · Y+1, Y+2, Y+3: base (ΜΔΠ), proposed change, revised. Amounts include VAT, as in the budget sheet. */
var RC_ORDER=["tn","dv","am","inc","pv","tm"],RC_LBL={tm:"ΣΤ · Τροποποιημένος διαγωνισμός",tn:"Α · Ενεργός διαγωνισμός",dv:"Β · Σύμβαση από διαγωνισμό με μεταβολή κόστους",am:"Γ · Τροποποιημένη σύμβαση",inc:"Δ · Σύμβαση επιλεγμένη για το Πλαίσιο",pv:"Ε · Γενική Πρόνοια"};
function rcByCode(B){var m={};Object.keys(B.byArt).forEach(function(c){var by={};B.byArt[c].forEach(function(r){Object.keys(r.by).forEach(function(y){by[y]=r2((by[y]||0)+r.by[y])})});m[c]=by});return m}
function rcX(l,v){return l+": "+(v===""||v==null?"—":v)}
function rcMonths(m){return m===""||m==null?"":m+" μήνες"}
function rcExplTn(t,kind){return [RC_LBL[kind||"tn"],rcX("Διαγωνισμός",t.title),rcX("Περιγραφή",t.description),rcX("Διάρκεια",rcMonths(t.months)),rcX("Εκτιμώμενη ημερ. έναρξης",bdGr(t.dateFrom)),rcX("Εκτιμώμενη ημερ. λήξης",bdGr(t.dateTo)),rcX("Εκτιμώμενο κόστος",bdEur(Number(t.cost)||0))]}
function rcExplCt(c,kind,extra){
  var l=[RC_LBL[kind],rcX("Σύμβαση",c.title),rcX("Αριθμός Διαγωνισμού",c.tender),rcX("Περιγραφή",c.description),rcX("Διάρκεια",rcMonths(c.months)),rcX("Ημερ. έναρξης",bdGr(c.dateFrom)),rcX("Ημερ. λήξης",bdGr(c.dateTo)),rcX("Κόστος (συνολικό, με πρόσθετες υπηρεσίες, χωρίς ΦΠΑ)",bdEur(ctTotal(c)))];
  return l.concat(extra||[]);
}
function rcExplPv(p){return [RC_LBL.pv,rcX("Περιγραφή",p.title),rcX("Άρθρο",pvArtText(p)),rcX("Σημειώσεις",p.notes)]}
/* base / rev: {code:{year:amount}}. One row per article; rows with no amount in Y..Y+3 are left out */
function rcRows(kind,key,title,base,rev,Y,expl){
  var codes=Object.keys(base).concat(Object.keys(rev).filter(function(c){return !(c in base)})),out=[];
  codes.forEach(function(c){
    var b=base[c]||{},v=rev[c]||{},C=r2(b[Y]||0),D=[],E=[],F=[];
    for(var k=1;k<=3;k++){var d=r2(b[Y+k]||0),f=r2(v[Y+k]||0);D.push(d);F.push(f);E.push(r2(f-d))}
    if(Math.abs(C)<0.005&&D.concat(F).every(function(x){return Math.abs(x)<0.005}))return;
    out.push({kind:kind,key:key,title:title||"",code:c,C:C,D:D,E:E,F:F,expl:expl});
  });
  return out;
}
function rcBuild(arts,tenders,contracts,provs,Y,limit,vat){
  var R=rcSets(tenders,contracts,limit,provs),rows=[];
  function ct(c){return rcByCode(bdBuild(arts,[],[c],[],vat))}
  function tn(t){return rcByCode(bdBuild(arts,[],[],[t],vat))}
  R.tenders.forEach(function(t){var m=tn(t);rows=rows.concat(rcRows("tn",t.id,t.title,m,m,Y,rcExplTn(t)))});
  R.dev.forEach(function(d){
    var ex=["Εκτιμώμενο κόστος διαγωνισμού: "+bdEur(d.base)+" · μεταβολή: "+(d.diff>0?"+":"")+bdEur(d.diff)+(d.pct==null?"":" ("+(d.pct>0?"+":"")+String(d.pct).replace(".",",")+"%)")];
    rows=rows.concat(rcRows("dv",d.c.id,d.c.title,tn(d.t),ct(d.c),Y,rcExplCt(d.c,"dv",ex)));
  });
  R.amd.forEach(function(d){
    var first=d.c.amendments[0]||{},before=Object.assign({},d.c,first.before||{}),
        ex=["Τροποποιήσεις: "+d.n+(d.list.length?" ("+d.list.map(function(a){return a.description||"—"}).join("; ")+")":"")+" · αρχικό κόστος: "+bdEur(d.base)+" · μεταβολή: "+(d.diff>0?"+":"")+bdEur(d.diff)];
    rows=rows.concat(rcRows("am",d.c.id,d.c.title,ct(before),ct(d.c),Y,rcExplCt(d.c,"am",ex)));
  });
  R.inc.forEach(function(d){var m=ct(d.c);rows=rows.concat(rcRows("inc",d.c.id,d.c.title,m,m,Y,rcExplCt(d.c,"inc",[])))});
  R.tamd.forEach(function(d){
    var first=d.t.amendments[0]||{},before=Object.assign({},d.t,first.before||{}),
        ex=["Τροποποιήσεις: "+d.n+(d.list.length?" ("+d.list.map(function(a){return a.description||"—"}).join("; ")+")":"")+" · αρχικό εκτιμώμενο κόστος: "+bdEur(d.base)+" · μεταβολή: "+(d.diff>0?"+":"")+bdEur(d.diff)];
    rows=rows.concat(rcRows("tm",d.t.id,d.t.title,tn(before),tn(d.t),Y,rcExplTn(d.t,"tm").concat(ex)));
  });
  R.provs.forEach(function(p){var m=rcByCode(bdBuild(arts,[],[],[],vat,[p]));rows=rows.concat(rcRows("pv",p.id,p.title,m,m,Y,rcExplPv(p)))});
  rows.forEach(function(r,i){r.i=i});
  rows.sort(function(a,b){
    var k=RC_ORDER.indexOf(a.kind)-RC_ORDER.indexOf(b.kind);if(k)return k;
    k=a.title.localeCompare(b.title,"el");if(k)return k;
    if(a.code!==b.code){if(!a.code)return 1;if(!b.code)return -1;k=a.code.localeCompare(b.code,"el",{numeric:true});if(k)return k}
    return a.i-b.i;
  });
  return {rows:rows,counts:{tn:R.tenders.length,dv:R.dev.length,am:R.amd.length,inc:R.inc.length,pv:R.provs.length,tm:R.tamd.length}};
}
function rcHeads(Y){
  return ["Κεφάλαιο","Άρθρο","Εγκεκριμένος\n Π/Υ "+Y+"\n€","Π/Υ "+(Y+1)+"\nΒάση ΜΔΠ\n€","Προτεινόμ. Αλλαγή\n€","Αναθεωρ. Π/Υ "+(Y+1)+"\n(1+2)\n€",
    "Π/Υ "+(Y+2)+"\nΒάση ΜΔΠ\n€","Προτεινόμ. Αλλαγή\n€","Αναθεωρ. Π/Υ "+(Y+2)+"\n(3+4)\n€","Π/Υ "+(Y+3)+"\n(Π/Υ "+(Y+2)+" βάση ΜΔΠ)\n€","Προτεινόμ. Αλλαγή\n€","Προτεινόμ. \nΠ/Υ "+(Y+3)+"\n(5+6)\n€ ","Επεξηγήσεις για την προτεινόμενη αλλαγή"];
}
/* the 13 cells of a row (A..M): text for A,B,M, numbers for C..L */
function rcCells(r){return ["",r.code||"",r.C,r.D[0],r.E[0],r.F[0],r.D[1],r.E[1],r.F[1],r.D[2],r.E[2],r.F[2],r.expl.join("\n")]}
/*RC2-CALC-END*/
var RC_XLSX_B64="UEsDBBQABgAIAAAAIQArQX8wcgEAAA4FAAATAAgCW0NvbnRlbnRfVHlwZXNdLnhtbCCiBAIooAACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACslMtuwjAQRfeV+g+Wt1Vi6KKqKgKLPpYtEvQDTDxJLBzbsgcKf9+JKbSqeAjBJlE8nnvuTDwejFatYUsIUTtb8H7e4wxs6ZS2dcE/p2/ZI2cRpVXSOAsFX0Pko+HtzWC69hAZZdtY8AbRPwkRywZaGXPnwVKkcqGVSJ+hFl6Wc1mDuO/1HkTpLILFDDsNPhy8QCUXBtnripY3Tmbacva82dehCi69N7qUSEbF0qp/kMxVlS5BuXLRknQefQCpYgOArcl90EQME0CkwiJnYi80gKHYOdSfsnLKTM5io328o9oPIVLoIGGb+EF/JGgFbCwDvsuWyhcrI75cmM+cm+fHVc7tTupS3kptd86PGEi7o0iv/pWddAUm4VNGkA4aiPS83EOSOUWMuDYQr935JHoS3cgAaoJ0iOurO/irfdQIjdY4OB9pegOc34ftpHTZmSchCKjhd1b2nbgdkmb/4s5Dd7koUPvgIt1mw28AAAD//wMAUEsDBBQABgAIAAAAIQCXCEWY9AAAAE8CAAALAAgCX3JlbHMvLnJlbHMgogQCKKAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAArJJNT8MwDIbvSPyHyPfV3ZAQQkt3QUi7IVR+gEncD7WNoyQb3b8nXIBKY3Dg6K/Xj195u5unUR05xF6chnVRgmJnxPau1fBSP67uQMVEztIojjWcOMKuur7aPvNIKQ/FrvdRZRUXNXQp+XvEaDqeKBbi2eVKI2GilMPQoiczUMu4KctbDN81oFpoqr3VEPb2BlR98nnz79rSNL3hBzGHiV06swJ5Tuws25UPmS2kPl+jagotJw1WzFNORyTvi4wNCs8jbf6O9PO5OHEiS4nQSODLQB8dF4nW/2nS0sYvf+YR3yQMryLDJwwu3qB6BwAA//8DAFBLAwQUAAYACAAAACEAHZKv16gDAAASCQAADwAAAHhsL3dvcmtib29rLnhtbKRWbW/iOBD+ftL+h1zUr2nivBEiYJVAoqtUKtRy7a2EhNzEAatJnHVMoaruv984CZSW0y7bRWDH9viZt2cmDL7uilx5JrymrByq6NJQFVImLKXlaqj+PY81T1VqgcsU56wkQ/WF1OrX0Zc/BlvGnx4Ze1IAoKyH6lqIytf1OlmTAteXrCIlnGSMF1jAkq/0uuIEp/WaEFHkumkYrl5gWqotgs/PwWBZRhMyYcmmIKVoQTjJsQDz6zWt6j1akZwDV2D+tKm0hBUVQDzSnIqXBlRVisS/WpWM48cc3N4hR9lx+LrwQwYM5l4THJ2oKmjCWc0ycQnQemv0if/I0BF6F4LdaQzOQ7J1Tp6pzOHBKu5+0ir3gOW+gSHjt9EQUKvhig/B+ySac7DNVEeDjObkvqWugqvqBhcyU7mq5LgWUUoFSYdqD5ZsS95t8E0VbmgOp5bRM4Dh+ujA5xmXK8h+kAvCSyzImJUCyNYZ/7vEarDHawY0Vm7J9w3lBKoHSAQOwYgTHz/WMyzWyobnQ3XiLx5ombJtvbgj/BluzTiTjteLGyJkEXbbi6CqJljgxTVLcL6Y4eQJr0BKKloid9nv2Rl2eu7SMhOUWshemiZyF8F4MSdFtThiMz4tnV/gM06acOoQwdbL0UA+f4wmOMv9PWlngivwfDW5hsTd4WdII5Al7ar8CvLkLV+Nnjt2UTjWHAuFWhDanhZaXk8L+64RBTEKPBf9C25w108Y3oh1Rw2JOVRt4MHJ0RTv9ifI8Dc0fdP/anQfTc4fhv0ZqAOuyC54T8m2fiORXCq7NnFDVXPBm5d3q22T0weaijV0Xcf2QKLd+4vQ1RoMRsi1ZcVwUxo2VF89y0aOFwZaZIaOZo9jVwsndqhF4Tgyo9iwItNuDdKPLGraLVjWzErZlMidbMEI+rqcZXThmftSCb9K4Rl80vf3UpLRkqSytgDlaNVhLXd5WVzOOC3FMoD+LqsN+NeokNCGOmrV/XkRXCD/Ynph9gb6Ec7PQOdUANl/AAug5gfEY3ywGuxJoKzl1HjbR4bZFj3ZietajAYwQ7lRiHIIITasvqnZMYo1G/UNLQxdW3MmseX00GQcObFkmXzp+TsJmX2yl3l6c5tgsYEWIKu/WftyjLvdw2bWbnRBf1eO/u2kSVl3/UeSd/BWz8m50vH9uZLjm+l8eq7wdTRfPsRnSwfTcBL8woXg9jb4No/+OSjR/zeuOqQcaL4ngL7/OzP6DwAA//8DAFBLAwQUAAYACAAAACEABQlHb/MAAAC+AgAAGgAIAXhsL19yZWxzL3dvcmtib29rLnhtbC5yZWxzIKIEASigAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAArFLLasMwELwX+g9i77XstJRSIudSCrm27gcIaW2Z2JLQbh/++woXEgdCevFlYXbZmdnHdvczDuILE/XBK6iKEgR6E2zvOwUfzevdEwhi7a0egkcFExLs6tub7RsOmnMTuT6SyCyeFDjm+CwlGYejpiJE9LnShjRqzjB1Mmpz0B3KTVk+yrTkgPqMU+ytgrS39yCaKWbl/7lD2/YGX4L5HNHzBQlJPA15ANHo1CEr+MNF9ghCXtbfrKnPeS94kp+hnGN11US1ponvkA7kEPlk5JgiOVeuu3lY9SROJ7TvnPLHLS+zTB93I8++rv4FAAD//wMAUEsDBBQABgAIAAAAIQAfvplAgC8AAIClAQAYAAAAeGwvd29ya3NoZWV0cy9zaGVldDEueG1stJ1bU1zZsl7fHeH/oOC9EXWvUkg60YKqdd92ePvyTKPqFtFCyEDf9gn/d39rVS5EzhxdUvdmRhwf6QyyZqFBMqkh5Ob1f/x+8/HFr/u7++vbT29OJqdnJy/2n65u319/+unNyf/6n7vv1icv7h8uP72//Hj7af/m5I/9/cl/vP2v/+X1b7d3P99/2O8fXuiET/dvTj48PHx+9fLl/dWH/c3l/ent5/0nveXH27ubywf9n3c/vbz/fLe/fD886Objy+nZ2fLlzeX1p5PDCa/uvuWM2x9/vL7aX9xe/XKz//RwOORu//HyQe///Yfrz/fjaTdX33LczeXdz798/u7q9uazjvjh+uP1wx/DoScvbq5eVT99ur27/OGj/ty/T+aXVy9+v9P/TPX/ZuPTDDw808311d3t/e2PD6c6+eXhfY5//M3LzcvLq8eT4p//m46ZzF/e7X+97j+AX46a/r13abJ4PGv65bDZ3zxs+XhYr+vu1S/X79+c/OfF+WJxvlpcfPduMX333Xwx23737vvV7rvdar3aLHeLrfj/O3n7+v21PsL9n+rF3f7HNyffT179Y7rRQS/fvh5W6H9f73+7f/L7Fw+XP/xz/3F/9bDX00xOXjzcfm73Pz6c7z9+fHPSCfzr9vbmn1eXH/f/6JdScHKmde8X+Yfb25/78yo98kzPfT+c0z/35dXD9a97O0NO7v/v8N50+q3ekZeP78nT34/v1W7Y/f9+9+L9/sfLXz4+/I/b38r99U8fHvTMCxnpV+rV+z8u9vdX2mU98+nh1KvbjzpC//vFzXX/SaldvPx9+PW36/cPH/S7yelmNV0ullMdc/XL/cPtzf+xtwzv1uNDdd7wUP06PvTsdL2R9MnXHirTw0P16/jQ+elXHzW3R+nX8VGz09lkOT/76vuqP8rwhPr1yx/zbLqazWerr/wxl/ZQ/To+dHm6mE83y/XXHrqyh+rXL+/wZr2err/6Z9XNOLzD+vXLQyfa4a8+6cYeqV/HR65O5+uv/0En2tfDLvSLax/y9enXF2HyuET6zV/4eE7GDep/88Xt1+VMxv3pf2MPnK1Pp2d/unkvD2s/fEZdXD5cvn19d/vbC12Keo/vP1/2X2ImryZarMPnz2n/kX34cH3187vb/hOKP58W+mS+6g/5vj/lzYl9gvXk3YEcbpRh5jyQC3vUUsf8+nby+uWv+jy/siO37o1T/8ZdOKtw4zM/Xro3zv0bq3BW7cYXfrxxb1z6N7bhrP5mlBmJ7S80OX8U3193qfjFZBB/uHQeb7O/9JHoj31z0n/03pzcD2LP/Pv47jChz+bHiUT9eZxInF0cJvRp/XhGomkbJ9KPYZxIbBaHCd0Aj8+ySj6wcSJ5lipOrP0Z9WFCt8Xjs2ySD3mcSJ6ljROTRHv/Na3/JNPV8vg8yZr+w0birujTyO1Kf5BW6rAnhy+Ewydp/8k7m58+XuhPVgi/Ho6fvv35OkAOtKXDZ+s7Q1rfEZ0bevI5fRHRNqJdREVEZURVRHVETURtRN0BzeQ//UyUyax2+/MTu4ae2jX01G5E24h2ERURlRFVEdURNRG1EXUHRHa1jN9sdzo/3fzl5e2fQGv/xOW7A+q/LD8uryH9MqKLiLYR7SIqIiojqiKqI2oiaiPq7M8Iy6t7PK/e/gn0pf3w1Ie7wdBTvQfUv/B+1BvRNqJdREVEZURVRHVETURtRN0B0fbqS1xevf0TJHoNPdV7QE5vRNuIdhEVEZURVRHVETURtRF1B0R6+7//ePoi6NgXtr91OfRPkOg19FTvATm9EW0j2kVURFRGVEVUR9RE1EbUHRDp1Rf0vHr7J0j0Gnqq94Cc3oi2Ee0iKiIqI6oiqiNqImoj6g6I9PYv5vL6HZ4hETyyp4aNOcXAtsB2wApgJbAKWA2sAdYC64yh7L6kst4V/euFdJtH5mQf5rzsyLb22KdzO2AFsBJYBawG1gBrgXXGUHZap89+Mfd/5RFkG3OyLYqevrKwxz4VuwW2A1YAK4FVwGpgDbAWWGcMZf+VvPtbXwX7vyYKso052dZNTnZkWzvPb3acK2CuBFYBq4E1wFpgnTGU/Vdq7+/JPrSQe8Xc13r/AXCyLaOc7Mi29lgvO84VMFcCq4DVwBpgLbDOGMruuyXvnX0oIy/bmJMdo+qiN9rfa08+AFtgO2AFsBJYBawG1gBrgXXGUHb2FJxAC47MyYYatDkvG3oQ5gpgJbAKWA2sAdYC64yhbBeGdvXpkxL/Su7vXSNQhhNIQ2NPxV4A2wLbASuAlcAqYDWwBlgLrDOGsl0mZpENnTiBUDTmZUMqwtwOWAGsBFYBq4E1wFpgnTGU7aIxi2yoxv7vnsMXSOhGm/PXCJQjzBXASmAVsBpYA6wF1hkj2f3XrS9fIHPIHp4hKciRPb2zjbnNBrYFtgNWACuBVcBqYA2wFlhnDGW7gswiGwqyf82XbrYxLxsKEuZ2wApgJbAKWA2sAdYC64yhbFeQWWRDQU6hII152bEqtzC3A1YAK4FVwGpgDbAWWGcMZbuCzCIbCnIKBWnMy4aChLkdsAJYCawCVgNrgLXAOmMo2xVkFtlQkFMoSGNeNhQkzO2AFcBKYBWwGlgDrAXWGUPZriCzyIaC7P/5VrizoSBtzr0aAbYDVgArgVXAamANsBZYZwxlu4LMIhsKcmrMvRqBgrQ5LxsKEuYKYCWwClgNrAHWAuuMoezsBTmFghyZkw3fXbQ5Lxu+vwhzBbASWAWsBtYAa4F1xlB29oKcQkGOzMmOtXhhc142fLcR5gpgJbAKWA2sAdYC64yh7OwFOYWCHJmTDQVpc142FCTMFcBKYBWwGlgDrAXWGSPZPctbkMMzJAU5sqeyjblXI8C2wHbACmAlsApYDawB1gLrjKHs7AXZ/zOm9Ds1I3OyYy1e2JzbbGA7YAWwElgFrAbWAGuBdcZQdvaCnEFBjszJhu9B2pyXHed2MFcAK4FVwGpgDbAWWGcMZWcvyBkU5Mic7FiLFzbnZce5HcwVwEpgFbAaWAOsBdYZQ9nZC3IGBTkyJxu+B2lzXnac28FcAawEVgGrgTXAWmCdMZSdvSBnUJAjc7KhIG3Oy45zO5grgJXAKmA1sAZYC6wzhrKzF+QMCnJkTjYUpM152VCQMFcAK4FVwGpgDbAWWGcMZWcvyBkU5MicbChIm/OyoSBhrgBWAquA1cAaYC2wzhjKzl6QMyjIkTnZUJA252VDQcJcAawEVgGrgTXAWmCdMZSdvSBnUJAjc7KhIG3Oy4aChLkCWAmsAlYDa4C1wDpjJHuevSCHZ0gKcmRPZRtzBQlsC2wHrABWAquA1cAaYC2wzhjKzl6QcyjIkTnZUJA25zYb2A5YAawEVgGrgTXAWmCdMZSdvSDnUJAjc7KhIG3Oy4aChLkCWAmsAlYDa4C1wDpjKDt7Qc6hIEfmZENB2pyXDQUJcwWwElgFrAbWAGuBdcZQdvaCnENBjszJhoK0OS8bChLmCmAlsApYDawB1gLrjKHs7AU5h4IcmZMNBWlzXjYUJMwVwEpgFbAaWAOsBdYZQ9nZC3IOBTkyJxsK0ua8bChImCuAlcAqYDWwBlgLrDOGsrMX5BwKcmRONhSkzXnZUJAwVwArgVXAamANsBZYZwxlZy/IORTkyJxsKEib87KhIGGuAFYCq4DVwBpgLbDOGMrOXpBzKMiROdlQkDbnZUNBwlwBrARWAauBNcBaYJ0xkr3IXpDDMyQFObKnso25ggS2BbYDVgArgVXAamANsBZYZwxlZy/IBRTkyJxsKEibc5sNbAesAFYCq4DVwBpgLbDOGMrOXpALKMiROdlQkDbnZUNBwlwBrARWAauBNcBaYJ0xlJ29IBdQkCNzsqEgbc7LhoKEuQJYCawCVgNrgLXAOmMoO3tBLqAgR+ZkQ0HanJcNBQlzBbASWAWsBtYAa4F1xlB29oJcQEGOzMmGgrQ5LxsKEuYKYCWwClgNrAHWAuuMoezsBbmAghyZkw0FaXNeNhQkzBXASmAVsBpYA6wF1hlD2dkLcgEFOTInGwrS5rxsKEiYK4CVwCpgNbAGWAusM4aysxfkAgpyZE42FKTNedlQkDBXACuBVcBqYA2wFlhnDGVnL8gFFOTInGwoSJvzsqEgYa4AVgKrgNXAGmAtsM4YyV5mL8jhGdL/jln/rMl/lcHmXEEC2wLbASuAlcAqYDWwBlgLrDOGsrMX5BIKcmRPN9uYlx2rcgtzO2AFsBJYBawG1gBrgXXGUHb2glxCQY7MyYaCtDl3jQDbASuAlcAqYDWwBlgLrDOGsrMX5BIKcmRONhSkzXnZUJAwVwArgVXAamANsBZYZwxlZy/IJRTkyJxsKEib87KhIGGuAFYCq4DVwBpgLbDOGMrOXpBLKMiROdlQkDbnZUNBwlwBrARWAauBNcBaYJ0xlJ29IJdQkCNzsqEgbc7LhoKEuQJYCawCVgNrgLXAOmMoO3tBLqEgR+ZkQ0HanJcNBQlzBbASWAWsBtYAa4F1xlB29oJcQkGOzMmGgrQ5LxsKEuYKYCWwClgNrAHWAuuMoezsBbmEghyZkw0FaXNeNhQkzBXASmAVsBpYA6wF1hkj2avsBTk8Q/qfaoaCtDkXNcC2wHbACmAlsApYDawB1gLrjKHs7AW5goIc2dPNNuZlQ0HC3A5YAawEVgGrgTXAWmCdMZSdvSBXUJAjc7KhIG3OXSPAdsAKYCWwClgNrAHWAuuMoezsBbmCghyZkw0FaXNeNhQkzBXASmAVsBpYA6wF1hlD2dkLcgUFOTInGwrS5rxsKEiYK4CVwCpgNbAGWAusM4aysxdk/zOjws8yMOZkQ0HaY71sKEiYK4CVwCpgNbAGWAusM4aysxfkCgpyZE42FKTNedlQkDBXACuBVcBqYA2wFlhnDGVnL8gVFOTInGwoSJvzsqEgYa4AVgKrgNXAGmAtsM4Yys5ekCsoyJE52VCQNudlQ0HCXAGsBFYBq4E1wFpgnTGUnb0gV1CQI3OyoSBtzsuGgoS5AlgJrAJWA2uAtcA6YyR7nb0gh2dIfxoNFKTNuagBtgW2A1YAK4FVwGpgDbAWWGcMZWcvyDUU5MiebrYxLxsKEuZ2wApgJbAKWA2sAdYC64yh7OwFuYaCHJmTDQVpc+4aAbYDVgArgVXAamANsBZYZwxlZy/INRTkyJxsKEib87KhIGGuAFYCq4DVwBpgLbDOGMrOXpBrKMiROdlQkDbnZUNBwlwBrARWAauBNcBaYJ0xlJ29INdQkCNzsqEgbc7LhoKEuQJYCawCVgNrgLXAOmMoO3tBrqEgR+ZkQ0HanJcNBQlzBbASWAWsBtYAa4F1xlB29oJcQ0GOzMmGgrQ5LxsKEuYKYCWwClgNrAHWAuuMoezsBbmGghyZkw0FaXNeNhQkzBXASmAVsBpYA6wF1hlD2dkLcg0FOTInGwrS5rxsKEiYK4CVwCpgNbAGWAusM0ayN9kLcniG9AduQkHanIsaYFtgO2AFsBJYBawG1gBrgXXGUHb2gtxAQY7s6WYb87KhIGFuB6wAVgKrgNXAGmAtsM4Yys5ekBsoyJE52VCQNueuEWA7YAWwElgFrAbWAGuBdcZQdvaC3EBBjszJhoK0OS8bChLmCmAlsApYDawB1gLrjKHs7AW5gYIcmZMNBWlzXjYUJMwVwEpgFbAaWAOsBdYZQ9nZC3IDBTkyJxsK0ua8bChImCuAlcAqYDWwBlgLrDOGsrMX5AYKcmRONhSkzXnZUJAwVwArgVXAamANsBZYZwxlZy/IDRTkyJxsKEib87KhIGGuAFYCq4DVwBpgLbDOGMrOXpAbKMiROdlQkDbnZUNBwlwBrARWAauBNcBaYJ0xlJ29IDdQkCNzsqEgbc7LhoKEuQJYCawCVgNrgLXAOmMke3KWPSEPT5E05CN86nuELmwIbgnuCBYES4IVwZpgQ7Al2I2Q1WcPyskZFOUj9OpjP16Mk27ZCUp9fLjURyj1EUp9hFIfodRHKPURSv0BsvrseTk5g758hF49FOY4maiH/9YOTUp9nJT6CKU+QqmPUOojlPoIpf4AWX322JycQW0+Qq8eenOcTNRDcdKk1MdJqY9Q6iOU+gilPkKpj1DqD5DVZ0/PyRm05yP06qE+x8lEPfQnTUp9nJT6CKU+QqmPUOojlPoIpf4AWX32EJ2cQYk+Qq8eWnScTNRDjdKk1MdJqY9Q6iOU+gilPkKpj1DqD5DVU5bqgrr65f7h9mZ3e3dz+fDmRII+6Jfp/LQv3MPbyv31Tz3U236fzC+vXr3/42J/f7X/JHZ2Oj15+/rqxd2bk+8nZ9Clj9CrhzIdJxP10KY0KfVxUuojlPoIpT5CqY9Q6iOU+gNk9RSpz6zeKlW/vLSPx7vJmUFF0AjPH6FerI9Qr3Bs8gnUi8sI9QonQqmPUOojlPoIpT5CqY9Q6iOU+gNk9ZSsz6zemtWrN+jVG/TqI5T6CKU+QqmPUOojlPoIpT5CqY9Q6iOU+gNk9RSwz6zeCtarN+jVG/TqI5T6CKU+QqmPUOojlPoIpT5CqY9Q6iOU+gNE9ROq2edVPzyFvlA49SN06kfo1APcTgDuCBYES4IVwZpgQ7Al2I2Q1fe59fnyk/4/5ExeTeyl6TOrPxRdot6gV2/Qq49Q6iOU+gilPkKpj1DqI5T6CKU+QqmPUOoPkNX3uZVZ/aHoEvUGvXqDXn2EUh+h1Eco9RFKfYRSH6HURyj1EUp9hFJ/gKyeavaZt95q1l84Br16g159hFIfodRHKPURSn2EUh+h1Eco9RFKfYRSf6RmJ1Szz6zeatarN+jVG/TqI5T6CKU+QqmPUOojlPoIpT5CqY9Q6iOU+iM125dK7gvHatarN+jVG/TqI5T6CKU+QqmPUOojlPoIpT5CqY9Q6iOU+iM1O8lfs8NThFc4lrhevUGvPkKpj1DqI5T6CKU+QqmPUOojlPoIpT5CqT9Ss5M+tzJ/mbXM81tv0KuPQXgxGd5DfeSefDykPk5KfYRSH6HURyj1EUp9hFIfodRHKPUHyF9m+9zKrN4yz6s36NXHIJT6CKU+QqmPUOojlPoIpT5CqY9Q6iOU+gil/gBZfZ9bmdVb5nn1Br36GIRSH6HURyj1EUp9hFIfodRHKPURSn2EUh+h1B8gqp8+x/dmHz5cX/387vbP/xpz8eXvMYcn1P2hV1Ff/jJthHop9uUv0wz21+WXv0wDuJ0A3BEsCJYEK4I1wYZgS7AbIX8gqG31+ugZ/wp5atGnU5+oj/B8YpP9dflE/WHyKZT6CKU+QqmPUOojlPoIpT5CqY9Q6iOUeoOHtXt5d/vb29f6X/3frU/6XQzXzzOrt+jz6iOU+gNM1Eco9RFKfYRSH6HURyj1EUp9hFIfodRHKPUGUT217TOrt+jz6iOU+gNM1Eco9RFKfYRSH6HURyj1EUp9hFIfodRHKPUGUX0fX+kX3WdWb9Hn1Uco9QeYqI9Q6iOU+gilPkKpj1DqI5T6CKU+QqmPUOoNonpq2z9T33+1+IvfK5xa8XnvEcr7ASbeI5T3COU9QnmPUN4jlPcI5T1CeY9Q3iOUd4PoncL2Ob1b7nnvEcr7ASbeI5T3COU9QnmPUN4jlPcI5T1CeY9Q3iOUd4Povc+ub71q/s6+W+t57xHK+wEm3iOU9wjlPUJ5j1DeI5T3COU9QnmPUN4jlHeD6J2S9jn33ULPe49Q3g8w8R6hvEco7xHKe4TyHqG8RyjvEcp7hPIeobwbRO/Us8/p3SrPe49Q3g8w8R6hvEco7xHKe4TyHqG8RyjvEcp7hPIeobwbJO/91ZHznhnO7/8Bz9OAAng+Mei9A9zS5I5gQbAkWBGsCTYEW4LdI0Tvf6Vd/8b9PqNwBSjvsf0uCMo7hStAeadwBSjvFK4A5Z3CFaC8HwnXWV9WGb+uDueHfT/k3NNPAnmP4SfvEcp7hNr3COU9Qu17hPIeofY9QnmPUPseobwbxH3/K9X6d/adknVGyWowuWcoWWFS3ilZAco7JStAeadkBSjvlKwjRO99U+Xc90OzJfd7hNr3mHza9wi17xHKe4Ta9wjlPULte4TyHqH2PUJ5j1D7bhC9Z+7VGfUqQHmnXgUo79SrAOWdehWgvFOvApR36lWA8n6kV2eZe3U4P9zv1Ks2mdwz1KswqX2nXgWofadeBah9p14FqH2nXh0h7nvmXp1RrwLUvlOvAtS+U68C1L5TrwLUvlOvAtS+U68C1L4f6dVZ5l4dzg/7Tr1qk8m+U6/CpPadehWg9p16FaD2nXoVoPadenWEuO+Ze3VGvQpQ+069ClD7Tr0KUPtOvQpQ+069ClD7Tr0KUPt+pFfnmXt1OD/dd4DnE4N+3wFuaXJHsCBYEqwI1gQbgi3B7hHSvs8z9+pwfvAeI1beqVcByjv1KkB5p14FKO/UqwDlnXoVoLwf6dV531QZX78P5wfvh5DzvWqTyb7HDpT3CLXvEcp7hNr3COU9Qu17hPIeofY9Qnk3iPueuVfn1KsAte8x+S4IynuclHfqVYDyTr0KUN6pVwHKO/XqCNF75l6dU68ClHfqVYDyTr0KUPtOvQpQ+069ClD7Tr0KUPt+pFfnmXt1OD/cMzFi5Z16FaC8U68ClHfqVYDyTr0KUN6pVwHK+5FenWfu1eH84J161SaT+516FSZ1z1CvAtQ9Q70KUPcM9SpA3TPUqyPEeyZzr86pVwFq36lXAWrfqVcBat+pVwFq36lXAWrfqVcBat+P9Oo8c68O54d9p161yWTfqVdhUvtOvQpQ+069ClD7Tr0KUPtOvTpC3PfMvTqnXgWofadeBah9p14FqH2nXgWofadeBah9p14FqH0/0quLzL06nJ/uO8DziUG/7wC3NLkjWBAsCVYEa4INwZZg9whp3xeZe3U4P3inXrXJxHuMQ3mnXgUo79SrAOWdehWgvFOvApT3I7266JsqY68O5wfvh5DzvWqTiffYgfIeofY9QnmPUPseobxHqH2PUN4j1L5HKO8Gcd8z9+qCehWg7hnqVYDyTr0KUN7jpLxTrwKUd+pVgPJOvTpC9J65VxfUqwDlnXoVoLxTrwKUd+pVgNp36lWA2nfqVYDa9yO9usjcq8P54Z6hXrXJ5J6JcSjv1KsA5Z16FaC8U68ClHfqVYDyfqRXF5l7dTg/eKdetcnEO/UqTOp+p14FqHuGehWg7hnqVYC6Z6hXR4j3TOZeXVCvAtQ9Q70KUPtOvQpQ+069ClD7Tr0KUPtOvQpQ+36kVxeZe3U4P+w79apNJvtOvQqT2nfqVYDad+pVgNp36lWA2nfq1RHivmfu1QX1KkDtO/UqQO079SpA7Tv1KkDtO/UqQO079SpA7fuRXl1m7tXh/HTfAZ5PDPp9B7ilyR3BgmBJsCJYE2wItgS7R0j7vszcq8P5wTv1qk0m3qlXYVLe46S8U68ClHfqVYDyTr0KUN6P9Oqyb6qMvTqcH7wfQs73qk0m3mMHat8jlPcI5T1C7XuE8h6h9j1CeY9Q+x6hvBvEfc/cq0vqVYC6Z6hXAco79SpAeadeBSjvcVLeqVcByjv16gjRe+ZeXVKvApR36lWA8k69ClDeqVcByjv1KkDtO/UqQO37kV5dZu7V4fxwz1Cv2mRyz1CvwqTumTgp79SrAOWdehWgvFOvApT3I726zNyrw/nBO/WqTSbeqVdhUt6pVwHqfqdeBah7hnoVoO4Z6tUR4j2TuVeX1KsAdc9QrwLUPUO9ClD7Tr0KUPtOvQpQ+069ClD7fqRXl5l7dTg/7Dv1qk0m+069CpPad+pVgNp36lWA2nfqVYDad+rVEeK+Z+7VJfUqQO079SpA7Tv1KkDtO/UqQO079SpA7Tv1KkDt+5FeXWXu1eH8dN8Bnk8M+n0HuKXJHcGCYEmwIlgTbAi2BLtHSPu+ytyrw/nBO/WqTSbeqVdhUt6pVwHKe5yUd+pVgPJOvQpQ3o/06qpvqoy9OpwfvB9CzveqTSbeYwdq3yOU9wi17xHKe4TyHqH2PUJ5j1D7HqG8G8R9z9yrK+pVgLpnqFcByjv1KkB5p14FKO/UqwDlPU7KO/XqCNF75l5dUa8ClHfqVYDyTr0KUN6pVwHKO/UqQHmnXgWofT/Sq6vMvTqcH+4Z6lWbTO4Z6lWY1D1DvQpQ90yclHfqVYDyTr0KUN6P9Ooqc68O5wfv1Ks2mXinXoVJeadeBSjv1KsAdb9TrwLUPUO9OkK8ZzL36op6FaDuGepVgLpnqFcB6p6hXgWofadeBah9p14FqH0/0qurzL06nB/2nXrVJpN9p16FSe079SpA7Tv1KkDtO/UqQO079eoIcd8z9+qKehWg9p16FaD2nXoVoPadehWg9p16FaD2nXoVoPb9SK+uM/fqcH667wDPJwb9vgPc0uSOYEGwJFgRrAk2BFuC3SOkfV9n7tXh/OCdetUmE+/UqzAp79SrAOWdehWgvMdJeadeBSjvR3p13TdVxl4dzg/eDyHne9UmE++xA7XvEcp7hNr3COU9Qu17hPIeobxHqH2PUN4N4r5n7tU19SpA3TPUqwDlnXoVoLxTrwKUd+pVgPJOvQpQ3m0SvWfu1TX1KkB5p14FKO/UqwDlnXoVoLxTrwKUd+pVgPJ+pFfXmXt1OD/cM9SrNpncM9SrMKl7hnoVoO4Z6lWAumfipLxTrwKU9yO9us7cq8P5wTv1qk0m3qlXYVLeqVcByjv1KkB5p14FqPudenWEeM9k7tU19SpA3TPUqwB1z1CvAtQ9Q70KUPcM9SpA7Tv1KkDt+5FeXWfu1eH8sO/UqzaZ7Dv1Kkxq36lXAWrfqVcBat+pVwFq36lXR4j7nrlX19SrALXv1KsAte/UqwC179SrALXv1KsAte/UqwC170d6dZO5V4fz030HeD4x6Pcd4JYmdwQLgiXBimBNsCHYEuweIe37JnOvDucH79SrNpl4p16FSXmnXgUo79SrAOWdehWgvMdJeT/Sq5u+qTL26nB+8H4IOd+rNpl4jx2ofY9Q3iPUvkco7xFq3yOU9wi17xHKe4TybhD3PXOvbqhXAeqeoV4FKO/UqwDlnXoVoLxTrwKUd+pVgPJ+pFc3mXt1OD/se4xYeadeBSjv1KsA5Z16FaC8U68ClHfqVYDyfqRXN5l7dTg/eKdetcnknqFehUndM9SrAHXPUK8C1D1DvQpQ90yclPcjvbrJ3KvD+cE79apNJt6pV2FS3qlXAco79SpAeadeBSjv1KsjxPs9c69uqFcB6p6hXgWoe4Z6FaDuGepVgLpnqFcB6p6hXgWofT/Sq5vMvTqcH/adetUmk32nXoVJ7Tv1KkDtO/UqQO079SpA7Tv16ghx3zP36sZ6VVfdlx9MCVD7bnWnP8GXH0wJUPseJ+U9Qu17hPIeofY9QnmPUPseobw76H4G5fQsb5oeztdqP1VM8HyE/c/rfVRMcEtwR7AgWBKsCNYEG4JtAhPFeSt0embB6RVHKMXWbF5xhFIcoRRHKMURSnGEUhyhFEcoxRFKsYOJ4rzBOT2ztvSKI5RiyzOvOEIpjlCKI5TiCKU4QimOUIojlOIIpdjBRHHetpyeWVt6xRFKsZWYVxyhFEcoxRFKcYRSHKEURyjFEUpxhFLsYKI4b0ZOz6wYveIIpdiiyyuOUIojlOIIpThCKY5QiiOU4gilOEIpdjBRnLcYp2cWh15xhFJsfeUVRyjFEUpxhFIcoRRHKMURSnGEUhyhFDuYKM4bh9Mz60CvOEIptr7yiiOU4gilOEIpjlCKI5TiCKU4QimOUIodTBTn7cDpmXWgVxyhFFs1ecURSnGEUhyhFEcoxRFKcYRSHKEURyjFDiaK8ybf9MzqziuOUIqtmrziCKU4QimOUIojlOIIpThCKY5QiiOUYgcTxa7u7KWH7u7DD53e3d7dXD68OdGrvg/65a//NLvpGdQdQSmGuiMoxVB3BKUY6o6gFEPdEZRiqLsEesUTV3fPr3g4P607gOdTg77uAG5pckewIFgSrAjWBBuCbQITxa7uMiimuptQ3RlMFFPdwaQUU90BlGKqO4BSTHUHUIqP1N3E1V0GxTHk3k2HJ/WrrS2mugOoLaa6A6gtproDqC2mugOoLaa68zDZYld3GRRT3U2o7gwmW0x1B5PaYqo7gNpiqjuA2mKqO4Da4iN1N3F1l0Ex1d3wpGGLqe5s8ql3bTHVHUBtMdUdQG0x1R1AbTHVnYfJFvdZ8vjvDjIojiGni4LqzmCyxVR3MKktproDqC2mugOoLaa6A6gtPlJ3E1d3GRRT3Q1PGraY6s4mky2muoNJbTHVHUBtMdUdQG0x1Z2HyRa7usugmOqu/47SfVBMdWeTiWKqO5iUYqo7gFJMdQdQiqnuPEwUu7rLoJjqrjcWFVPd2WSimOoOJqWY6g6gFFPdAZRiqjsPE8WZ625CdQdQL9qo7gDqyx3VHUApproDKMVUdwClmOrOQ694mrnuhvPTugN4PjXov9wB3NLkjmBBsCRYEawJNgTbBCaKM9fdlOoOoBTHlLogKMVxUoqp7gBKMdUdQCmmugMoxUfqbpq57obzwxbH5JNiqjuAUkx1B1BbTHUHUFtMdQdQW0x152GyxZnrbkp1B1CKY0ppi6nuAGqLqe4Aaoup7gBqi6nuAGqLj9Rd/8+Oc6bHcH7Y4ph8Ukx1B1BbTHUHUFtMdQdQW0x1B1BbTHXnYbLFmeuu/zcqyeuzd1OAUhxTSltMdQdQW0x1B1BbTHUHUFtMdQdQW3yk7qaZ6244P2xxTD4pproDqC2mugOoLaa6A6gtproDqC2muvMw2eLMdTelugMoxVR3AKWY6g6gFFPdAZRiqjuAUkx152GiOHPdTanuAEox1R1AKaa6AyjFVHcApZjqDqAUU915mCjOXHdTqjuAUkx1B1CKqe4ASjHVHUApproDKMVUdx56xf13PHO+ohjOT+9igOdTg77uAG5pckewIFgSrAjWBBuCbQITxZnrbkZ1B1CKqe4ASjHVHUApjpNSTHUHUIqp7gBK8ZG6m2Wuu+H8sMVUdzaZbHFMKSmmugMoxVR3ALXFVHcAtcVUdx4mW5y57mZUdwC1xVR3AKU4TuqioLoDqC2mugOoLaa6A6gtPlJ3s8x1N5wftpjqziaTLY4pJcVUdwC1xVR3ALXFVHcAtcVUdx4mW5y57mZUdwC1xVR3AKU4TmqLqe4Aaoup7gBqi6nuAGqLj9TdLHPdDeeHLaa6s8lki2NKSTHVHUBtMdUdQG0x1R1AbTHVnYfJFmeuuxnVHUBtMdUdQCmmugMoxVR3AKWY6g6gFFPdeZgozlx3M6o7gFJMdQdQiqnuAEox1R1AKaa6AyjFVHceJooz192M6g6gFFPdAZRiqjuAUkx1B1CKqe4ASjHVnYde8Txz3Q3np3cxwPOpQX8XA9zS5I5gQbAkWBGsCTYE2wQmijPX3ZzqDqAUU90BlGKqO4BSTHUHUIrjpBRT3QGU4iN1N89cd8P5YYup7mwy2WKqO5jUFsdJKaa6AyjFVHcAtcVUdx4mW5y57uZUdwC1xVR3ALXFVHcApThO6qKgugOoLaa6A6gtPlJ388x1N5wftpjqziaTLaa6g0ltcZyUYqo7gNpiqjuA2mKqOw+TLc5cd3OqO4DaYqo7gNpiqjuAUhwntcVUdwC1xVR3ALXFR+punrnuhvPDFlPd2WSyxVR3MKktjpNSTHUHUFtMdQdQW0x152GyxZnrbk51B1BbTHUHUFtMdQdQiqnuAEox1R1AKaa68zBRnLnu5lR3AKWY6g6gFFPdAZRiqjuAUkx1B1CKqe48TBRnrrs51R1AKaa6AyjFVHcApZjqDqAUU90BlGKqOw+94kXmuhvOT+9igOdTg/4uBrilyR3BgmBJsCJYE2wItglMFGeuuwXVHUApproDKMVUdwClmOoOoBRT3QGU4jgpxUfqbpG57obzwxZT3dlkssVUdzCpLaa6A6gtjpNSTHUHUIqp7jxMtjhz3S2o7gBqi6nuAGqLqe4Aaoup7gBKcZzURUF1B1BbfKTuFpnrbjg/bDHVnU0mW0x1B5PaYqo7gNriOCnFVHcAtcVUdx4mW5y57hZUdwC1xVR3ALXFVHcAtcVUdwClOE5qi6nuAGqLj9TdInPdDeeHLaa6s8lki6nuYFJbTHUHUFscJ6WY6g6gtpjqzsNkizPX3YLqDqC2mOoOoLaY6g6gtpjqDqAUU90BlGKqOw8TxZnrbkF1B1CKqe4ASjHVHUApproDKMVUdwClmOrOw0Rx5rpbUN0BlGKqO4BSTHUHUIqp7gBKMdUdQCmmuvPQK15mrrvh/PQuBng+NejvYoBbmtwRLAiWBCuCNcGGYJvARHHmultS3QGUYqo7gFJMdQdQiqnuAEox1R1AKaa68zBRnLnuljHk3k0BSnGspguCUhwntcVUdwC1xVR3ALXFcVKKqe48TBRnrrsl1R1AKaa6AyjFVHcAtcVUdwC1xVR3AKU4TuqiOFJ3y8x1N5wf7mKqO5tM7mKqO5jUFlPdAdQWU90B1BbHSSmmuvMw2eLMdbekugOoLaa6A6gtproDqC2mugOoLaa6AyjFcVJbfKTulpnrbjg/bDHVnU0mW0x1B5PaYqo7gNpiqjuA2uI4KcVUdx4mW/ytdff7ZH559er9Hxf7+6v9J/2nB89OpydvX1+9uHtz8v10SREHUMtKEQdQy0oRB1DLShEHUMtKEQdQJiniPExMfmvEfcUktdoyQpmkVgMok9RqAGWSWg2gTFKrAZRJajUPE5Pf2mpfMUlJtoxQJinJAMokJRlAmaQkAyiTlGQAZZKSzENvcvWtSXbc5HBMek8CPJ8a9PckwC1N7ggWBEuCFcGaYEOwTWBi8lvL6ysmKbBWEcokBRZAmaTAAiiTFFgAZZICC6BMUmB5mJj81sD6iknqqBV9l8xgspP0XTKY1E5SRwHUTlJHAdROUkcB1E66ycTkt3bUV0xSLq0i1E5SLgHUTlIuAdROUi4B1E5SLgHUTlIueZiY/NZc+orJGEDvpiuqIoPJTlIVwaR2kqoIoHaSqgigdpKqCKB20k0mJr+1ir5ikuJnFaF2kuIHoHaS4gegdpLiB6B2kuIHoHaS4sfDxOS3xs9XTMac0U5S4xhMdpIaBya1k9Q4ALWT1DgAtZPUOAC1k24yMfk8jbOixgGonaTGAaidpMYBqJ2kxgGonaTGAaidpMbxMDH5PI2zosYBKJPUOABlkhoHoExS4wCUSWocgDJJjeNhYvJ5GmdFjQNQJqlxAMokNQ5AmaTGASiT1DgAZZIax0Nvcv08jTMckzYOwPOpQX9PAtzS5I5gQbAkWBGsCTYE2wQmJp+ncdbUOABlkhoHoExS4wCUSWocgDJJjQNQJqlxPExMPk/jrKlxAMokfa8IoEzS94oAymSc1E5S4wDUTlLjANROHmmc9fM0znBM+OymxrHJ5LM7BoVMUuMAlElqHIDaSWocgNpJahwPk518nsZZU+MA1E7GoLggKJNxUvckNQ5A7SQ1DkDtJDUOQO3kkcZZP0/jDMeEnaTGsclkJ2NQyCQ1DkDtJDUOQO0kNQ5A7SQ1jofJTj5P46ypcQBqJ2NQaCepcQBqJ6lxAGonqXEAaiepcQBqJ480zvp5Gmc4JuxkDB+ZpMYBqJ2kxgGonaTGAaidpMYBqJ2kxvEw2cnnaZw1NQ5AmaTGASiT1DgAZZIaB6BMUuMAlElqHA8Tk8/TOGtqHIAySY0DUCapcQDKJDUOQJmkxgEok9Q4HnqTm+donPPpcIx+dpw+kF9+ljTALU3uCBYES4IVwZpgQ7BNYOLn3yqXXsbd7W/9d7Knm3/rlbs76d965dqf9PL+w37/cHH5cPn29ee7608P/+3zw/Xtp/sXH27vrv91++nh8uO5vhW/v9u/H34g4E931+/b6097/dea5UMHfL78ad9d3v10rcd83P84fNN+slmuF2ezzWx1drZar/r/jMXd9U/9zxI8O4W3Pdx+7t/ST55NFqv5+mw2mW/6f7Txw+3Dw+3Nn7zxw/7y/V4+z06H8bPldLPRj99abPrXVT/e3uqd/pM32rv9z/3DL59ffL78vL/75/W/9m9O+k+Zq8uP+l3/rWMJ0J/8stfx5uTj5af3etvnvf4or67l4q56fxCgj+q7u/3lz/cvrm5/6f/RgvDN5adfLj8O+HyEb1//cPfzi/6hk/7HM9xc/t7/bpgdXfYLdzhLH5jfbu9+Hj44b/8/AAAA//8DAFBLAwQUAAYACAAAACEAwqjsSvUFAAD3GQAAEwAAAHhsL3RoZW1lL3RoZW1lMS54bWzsWUtvGzcQvhfofyD23kiy9YiMyIGtR9zGToJYSZEjtUvtMuIuF0vKjm5FcixQoGha9FKgtx6KtgESoJf017hN0aZA/kKHXGmXtLjNywESNBZgaLnfDIczw2841IWLd2KGjkgmKE96XuNc3UMk8XlAk7Dn3RiPPjrvISFxEmDGE9LzFkR4F7c//OAC3pIRiQkC+URs4Z4XSZlu1WrCh2EszvGUJPBuyrMYS3jMwlqQ4WPQG7PaRr3ersWYJh5KcAxqr06n1CdorFR62yvlQwaPiRRqwGfZoVJNLAmNDWYNhRAL0WcZOsKs58E8AT8ekzvSQwwLCS96Xl3/eai2faGGt5ZSTFYIG4Ij/bcSXEoEsw09axZOimmbzVazvVPOoBFMrgOHnWF72C41agT2fVhtbo6ptbXb3R20VmADlX91aB90BpsNW8CYYXPN7p2W+tgCGpXP0FwTGI364ExbQKNygZbDM52NftMW0KhcoL0m0KnvDJodW0CjIkaT2Rq83mpv9oslF5gpZ3tOfLfVHHU2VupLGCRGkWlqkilPZFXexfg2z0YAUECGJU2QXKRkin3I6D5mdJJRtE/DCJIwxQkXMFzfqI/qm/BffZr6W+4VvEWwIa4tA1vE+pgyCQk/o6nseZ+AYs/APHv807PHD9Gzxw9O7j46ufvryb17J3d/WWqzJPdwEpqST3/48p/vPkN/P/z+6f2vKwSEKfDHz5///ttXFUhYcumLJ988+PPRgyfffvHXj/dd+J0MT0z8mMZEoCvkGF3nsVof7Ng8FMW698gke0mRcYSpJYIj0O5SPpSRhbyywMwJ3CW2D29mwDtO5KX5bcvewyibS5hkfWWXo9hCHnDOdnnmdsNlPV3p6fE8CSvmz+bm4q9jfOScvo8TK8rDeQqsS51K+xGxTL3GcCJxSBIikXrHZ4S4lniLUsu/B9TPuOBTiW5RtIup2zFjOrGyqpTaozEEaOG0EaIO46WHDm6iXc6cSx+QIxsKOwQz1wLGhFnevITnEsdOpWMcg4py/n0sI6ehh4vMN4FDISHoIWEcDQMihFPoaqZWXWq/DKxTkQEHbBHb0EzSmVPrPubchA74rB/hOHXbTZPIBH8sZpCxGF3j0ok/4PaeUc8QEJxUR/4mJVbkX4AfbgDtWmEvUky9mUParu+8S4Tbe3TBppjk9AN1waL7mCbP5f5TrN96z/pWATrN+jsZde+201xfCXxHGX6A58k1onaRoxq8J3goC+8JfnWs/H8QfOUOfxO0XjI5kHx53tdHzrjy8D+ljB3KBSP7Qp//BdSwYASDujXRnWrRFqYRfF31GhYwzLAWQhmXn1IZHUY4hS6hofvaUCx1hwKlXEDzoId1h01OKdctyDw+4EHeADcaqtldMorAsnxRb5UvoGWROb7dMfq5YgbdKIe6/17ZoKRfxg5zOtuOTZcdnWIUgvFfduj1nY0hXZch59UERcxW8SwcAtYV4YEjF4KTWs9rNZc3DMLHjAQqYMvLhlWcVZjONOaVLmVmMsDJo0iGMuZdZW71EtUK87x7gZhbdpi5Z9thJmWEA7JMVuti5iyj3jVia5moHFJsj9KSzvk3E3XFLKcIgyUmfbAEHfe89mYLjPJx2vOmcKEAX+MU0kioEzNmIdzQ+TLLSeCV6CbNhBxgEeVu10y0pIiYSpIhRuOep1xQ5gVLNLVo8xobwBJvs31dYJu30D6Ivh1tMp0SX5rxN0aUv/NHoP8lfzhfa/nXQCtRPoe4H0bBMZqweXYdQ7a1Og3lxYAKuF9q5C4NKNyfFvRWpuKpurXkY/PyUidTPo5ZGuFlubFoPsdrbi3s0U+FG4yn5arBp+tenISqAr9+WX5+MVe+M5jUqKkWzaiqWkGxb+4cYNhl1FjLrpzR835DlPTXLegPMtZdQJ5Tll+gVBjmGdNZ5imzHeysyHw1bJt3lqcGwx/tKv+V5cPpj1c+HYDg6RxWpWN1DNXbQP/uYv40wie3gU0GcPE8Z1LkQYVfPjIMZ8T87rokEi28/S8AAAD//wMAUEsDBBQABgAIAAAAIQAyOT0fDwUAAF4nAAANAAAAeGwvc3R5bGVzLnhtbORa32/iOBB+P+n+hyjvND9IUoIIq9IWaaW91UntSfdqEgesdWLkmG7Y0/3vO44TEgSU0EKB3SdsY48/zzceeyYefMoTqr1gnhGWBrp1Y+oaTkMWkXQa6P88jzs9XcsESiNEWYoDfYkz/dPwzz8GmVhS/DTDWGggIs0CfSbEvG8YWTjDCcpu2Byn8E/MeIIEVPnUyOYcoyiTgxJq2KbpGQkiqa4k9JOwjZAE8W+LeSdkyRwJMiGUiGUhS9eSsP95mjKOJhSg5paDQi23PG5rOa8mKVo35klIyFnGYnEDcg0WxyTEm3B9wzdQWEsCyW+TZLmGaa+tPedvlOQYHL8QSZ8+HMQsFZkWskUqAt0BoFIF/W8p+56O5V/AcNlrOMh+aC+IQoula8ZwEDLKuCaAO1CdakpRglWfe0TJhJOiY4wSQpeq3VZDZ4hnYAdKnKcGF2ZQDk8IkFJ0NSRChbOBAIzuPAgmct5KEf5+FHecIHqIFtbWuzbb+9X+qoaLiTPQNKF0ZRGeJB8ahgPYOgLzdAwVrSw/L+fAfAq7vGSq6Lin+5SjpWW7B4zIGCWRxDG9b1ocmIAg0mo75o3l+L7fc24d89Zxbc9WBjUpB5A0wjmOAt0DAwf6jMZaoKYA74G9AwQIVCDMm1sJwfJ6vZ7vdC3HUZb+ARjACs+OAfg8IoaCEjDFCeMRHDSVe7K6YAWqbTigOBaSTE6ms6Ig2FzWJ0wIlshSRNCUpYgWlFfD1oYXJ1KgJzgiiwRkK4+2YS5yqmqicoiYwSG0c0CBaTiQiFpOAV1X0FsOUQs9YJmvY/5dF7mP/N+Ny3oLlXY4Q4TvNvXLs8LX8W7ZaL/8AveZ+MEcntJhntr+PsDZn9sCL3GJV2WDrTxf05Mccts4+THc3vxOCvuAg/WYe94oL41wOcOUPsmcw79xfYWEkyyPtXSRjBPxGUICiCJkgFkVIYIpi0pMWZFBQ1OcEt6Q27XfJjiP6xl24YJgRgYn23CthqP5nC5lwF5E4kXtjpJpmmDVNBxAPK6q2oxx8gO6ylA+hP8xBNqQzxEkbLbIJefx4doCtOuoRsUlvsoQHKp8iKKOKa77NnGAoqIAirVpbCx2nQIZLNeENBRxOEHfOZo/41zxu4+bXXA3lHlxcIGfWruXDxfC/2uCC1H6NcFd22obO/eMtutAymXfqSFzqZVzL7b710UywXxcJLeP5BSO57XhGNzpZk92mgClv7gWT3EGt9Aa7PNLsb0WaL2rQruxU863r1votiXaU9hpGyd5exbq99+l2mCHz5yXssnawL0gn9AGLpyw16TdC/JhbbR7QU7siHBPHPFKd7stDt8Tprwr7Nsa6bVRmXVlFMuP21d0Z7kkuC1SWNZraZRj3O8/9Eg9YlpldwRV5Psgw9fII65lEVfpQE0+egn0rzKwg5ceKyOeLAiFb+LbMoggNMrrpKR6zCLkG6QiX7maB/6IcIwWVDyv/gz0uvxX8eEauC17/U1emChEBHpd/iK/kFtwQoEzgQzSlww+ZsOvtuAk0P97HN36D49ju9MzR72O08Vux3dHDx3XuR89PIx90zbv/288hXrHQ6ji5RZkFC2nn1F4LsXL1Zbon+q2QG9UFH71cgNwN8H7tmfeuZbZGXdNq+N4qNfpeV23M3Yt+8FzRo/u2G2Ad9/4Yso0LEu9vZLo3b4gCaYkrdiqOGq2Ak1QfW0VRsWFUT+MG/4EAAD//wMAUEsDBBQABgAIAAAAIQA7iTyYsgEAANMDAAAUAAAAeGwvc2hhcmVkU3RyaW5ncy54bWysU89KAkEYvwu+wzAnY8nRtSJk3Q5BT1Cn8LDolAvurO2sUjc1MYQuRV2ig5duGliEaZpv8M079CR9axCp23bpsDAz3/f7M7/9xtg5dcqkxj1puyJH08kUJVwU3KItjnP0YH9vfZsS6VuiaJVdwXP0jEu6Y8ZjhpQ+QayQOVry/UqWMVkocceSSbfCBVaOXM+xfNx6x0xWPG4VZYlz3ykzPZXaYo5lC0oKblX4qJuhpCrskyrf/TrQ09Q0pG0ac5GsrFgFFEcWyb0apybcwYtqQw/eYAAjmBGD+abBAkQUqq0a8IrfSr8J3eBYteAF6abqEiZJAldIHwg8w2M89tHsLYmYcKvqCHiHYdCizgOwahLcjGBAkGwIU6Lqy8zYNoUhQeJv+lVmJBlj4xjBI5hAHyEz1YzHCHQZPJBD1cJKX12oDmrgohWU8+E2IxBaGjFwDT10j5bu4Qa64SRX6GAAr5h7RzUwnL9IE2lNX4vw88sVNP1fDLUXcpmTJjLaRpSh8Ei1DPpJRN5WzxN4WkgwVCZ4LiGTHDJ4+Eei0p072tS2vlR+jD7DR2l+AgAA//8DAFBLAwQUAAYACAAAACEABqhUnMIAAABDAQAAIwAAAHhsL3dvcmtzaGVldHMvX3JlbHMvc2hlZXQxLnhtbC5yZWxzhI/BisIwFEX3A/5DeHuT1oUMQ1M3IrhV5wNi+toG25eQ9xT9e7McZcDl5XDP5Tab+zypG2YOkSzUugKF5GMXaLDwe9otv0GxOOrcFAktPJBh0y6+mgNOTkqJx5BYFQuxhVEk/RjDfsTZsY4JqZA+5tlJiXkwyfmLG9Csqmpt8l8HtC9Ote8s5H1Xgzo9Uln+7I59Hzxuo7/OSPLPhEk5kGA+okg5yEXt8oBiQet39p5rfQ4EyrSNebnePgEAAP//AwBQSwMEFAAGAAgAAAAhALBkwjHpAQAAWA0AACcAAAB4bC9wcmludGVyU2V0dGluZ3MvcHJpbnRlclNldHRpbmdzMS5iaW7sVksvQ0EU/ua2SmmiK49dJZJuSKqq7CillVQJIizRJipeUYmNP2AnsbPyM6RL664spYkN/4DaqW9mbqtXVUjrEXpuztwzZ+55zJlzz5lx7GMXB9hAkpQHUcTQTwzCjyH4EEac3LRaTXFMwwrC7jByOHK1nwoYcOKsLdCSgEAzlg3JkaNACIFXct85Pey9eXyxZ5SZztsznOqxdo8EuFWCUCPgIN3MR/HAYBDkoEIiOrRBm+bpr8jqBm5deumiDdjr1HSuCYyl1cenQnWfh6njmuj2WvG8FbikYxfEPjswRl+vqKZLqXJ75aMlKnVbzJt7rO7BX1wpnqw8aIGmOsegQEjUOWzZbLZC40mZ3yH+9SmsYqsGuw2fga+Ps5PVNYFjNxRmjLzdZp6jzEVNGoqyFKEf/g17af+BeV3uhpl/ys165J9UX0zp7yxLQrSw1vvMqv/JQAtZS1Q3oKA8P1l3awOPKT4Zj8SmF6IlZe1vqJ2bn14ShWisPxb0D/nCcU86uZ9Klrr7aLlIj5rcl0JbIFXMw2pvi0n2MdlT7thvNrHOu8YqtrGm7hRbpFPYqXXrDflfFYEZzGIKi5jHCgYwwnvkAHGY1CDfHwQz33R3+ZfXjUZWvxuBCLNsCRPMsd8HzwAAAP//AwBQSwMEFAAGAAgAAAAhAMatMjBnAQAAlQIAABEACAFkb2NQcm9wcy9jb3JlLnhtbCCiBAEooAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHyS3U/CMBTF3038H5a+l34gKM0YiRpelITEGYlvTXuBhq1b2iLw39sNmPgRH9tz7i/n3Nx0si+L5AOcN5UdI9ajKAGrKm3saoxe8ym+Q4kP0mpZVBbG6AAeTbLrq1TVQlUO5q6qwQUDPokk64Wqx2gdQi0I8WoNpfS96LBRXFaulCE+3YrUUm3kCgindEhKCFLLIEkDxHVHRCekVh2y3rqiBWhFoIASbPCE9Rj58gZwpf9zoFUunKUJhzp2OsW9ZGt1FDv33pvOuNvtert+GyPmZ2Qxe35pq2Jjm10pQFmqlVAOZKhcNpPOyORJbjbV1smUXEjNGgvpwyxufGlA3x+yRUp+f559c2dsAJ1xygeYMsxvczoSdCBY/72bO5tihrbyMQjoJJYQx8pn5a3/8JhPUcNjmPYx4zm9FZwLfhN5P+abUkdgeYr7P3GIGcNslHMa4wk6vCCeAVkb+vshZZ8AAAD//wMAUEsDBBQABgAIAAAAIQD6OP+LsgEAAMADAAAQAAgBZG9jUHJvcHMvYXBwLnhtbCCiBAEooAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJxTTU/cMBC9V+I/pL6zzgJC1coxWi0gDlW76i70WE3tycYisSN7iHb76+vEJQRYVWpv8/H0/ObNWFztmzrr0AfjbMHms5xlaJXTxu4Kdr+9Pf3EskBgNdTOYsEOGNiVPPkg1t616MlgyCKFDQWriNoF50FV2ECYxbaNndL5BiimfsddWRqF1049NWiJn+X5Jcc9odWoT9uRkCXGRUf/S6qd6vWFh+2hjYKlWLZtbRRQnFLe7BXW2dJq74wWfNoSUdsG1ZM3dJC54NNUbBTUuIq0soQ6oOAvBXGH0Fu2BuODFB0tOlTkfBbMr2jaBct+QsBeTME68AYsRVE9LCVDXLeBvPzu/GOoECkIHgGpOIRT7DQ2F3I+AGLwV2Di+gIN6uwb2B3+yxNnx5/oNaZZ49uvXdgaqjF8Ldfg6Ygp51NTBmnJkqRy01uQxvpjwWhGan1ce2Ppx9IjTI06jkpS3hk67CjqfqN05ZoW7CE2xuizsY/hvt26ayB83v/rothU4FHHkxnvYyyIu7h6X/ckq6p3Xj9j3jf6W31IH1LOL2f5eR4PcVIT/OXryd8AAAD//wMAUEsBAi0AFAAGAAgAAAAhACtBfzByAQAADgUAABMAAAAAAAAAAAAAAAAAAAAAAFtDb250ZW50X1R5cGVzXS54bWxQSwECLQAUAAYACAAAACEAlwhFmPQAAABPAgAACwAAAAAAAAAAAAAAAACrAwAAX3JlbHMvLnJlbHNQSwECLQAUAAYACAAAACEAHZKv16gDAAASCQAADwAAAAAAAAAAAAAAAADQBgAAeGwvd29ya2Jvb2sueG1sUEsBAi0AFAAGAAgAAAAhAAUJR2/zAAAAvgIAABoAAAAAAAAAAAAAAAAApQoAAHhsL19yZWxzL3dvcmtib29rLnhtbC5yZWxzUEsBAi0AFAAGAAgAAAAhAB++mUCALwAAgKUBABgAAAAAAAAAAAAAAAAA2AwAAHhsL3dvcmtzaGVldHMvc2hlZXQxLnhtbFBLAQItABQABgAIAAAAIQDCqOxK9QUAAPcZAAATAAAAAAAAAAAAAAAAAI48AAB4bC90aGVtZS90aGVtZTEueG1sUEsBAi0AFAAGAAgAAAAhADI5PR8PBQAAXicAAA0AAAAAAAAAAAAAAAAAtEIAAHhsL3N0eWxlcy54bWxQSwECLQAUAAYACAAAACEAO4k8mLIBAADTAwAAFAAAAAAAAAAAAAAAAADuRwAAeGwvc2hhcmVkU3RyaW5ncy54bWxQSwECLQAUAAYACAAAACEABqhUnMIAAABDAQAAIwAAAAAAAAAAAAAAAADSSQAAeGwvd29ya3NoZWV0cy9fcmVscy9zaGVldDEueG1sLnJlbHNQSwECLQAUAAYACAAAACEAsGTCMekBAABYDQAAJwAAAAAAAAAAAAAAAADVSgAAeGwvcHJpbnRlclNldHRpbmdzL3ByaW50ZXJTZXR0aW5nczEuYmluUEsBAi0AFAAGAAgAAAAhAMatMjBnAQAAlQIAABEAAAAAAAAAAAAAAAAAA00AAGRvY1Byb3BzL2NvcmUueG1sUEsBAi0AFAAGAAgAAAAhAPo4/4uyAQAAwAMAABAAAAAAAAAAAAAAAAAAoU8AAGRvY1Byb3BzL2FwcC54bWxQSwUGAAAAAAwADAAmAwAAiVIAAAAA";
function rcN(v){var n=Math.round(v);return n===0?"0":bdNum(n).replace(/,00$/,"")}
function rcModel(){
  var Y=new Date().getFullYear(),B=rcBuild(articles(),S.tenders,S.contracts,S.provisions,Y,null,null),q=String(S.q||"").trim().toLowerCase();
  var all=B.rows.length,rows=q?B.rows.filter(function(r){return (r.code+" "+r.title+" "+r.expl.join(" ")).toLowerCase().indexOf(q)>=0}):B.rows;
  return {Y:Y,rows:rows,all:all,counts:B.counts,heads:rcHeads(Y)};
}
function renderRc(){
  var M=rcModel(),c=M.counts,tl=["Ενεργοί διαγωνισμοί","Συμβάσεις με μεταβολή >"+bdNum(RC_LIMIT)+" €","Τροποποιημένες συμβάσεις με αλλαγή ποσού","Συμβάσεις που επιλέχθηκαν","Γενικές Πρόνοιες που επιλέχθηκαν","Τροποποιημένοι διαγωνισμοί με αλλαγή ποσού"];
  $("#stats").innerHTML=RC_ORDER.map(function(k,i){return '<div class="stat"><b>'+c[k]+'</b><span>'+esc(tl[i])+'</span></div>'}).join("");
  $("#alerts").innerHTML="";$("#chips").innerHTML="";
  var css='<style>#rl-app .tbl .rct{border-collapse:collapse;font-size:13px;min-width:1500px;width:100%}#rl-app .tbl .rct th,.rct td{border:1px solid var(--line);padding:5px 7px;text-align:center;vertical-align:middle}#rl-app .tbl .rct th{background:var(--surface2);color:var(--text);font-size:12px;white-space:pre-line;vertical-align:middle}#rl-app .tbl .rct tr.nr th{font-weight:700;background:transparent;padding:2px}#rl-app .tbl .rct td.num{text-align:right;white-space:nowrap}#rl-app .tbl .rct td.ex{text-align:left;white-space:pre-line;min-width:300px;font-size:12px}#rl-app .tbl .rct td.cd{white-space:nowrap}#rl-app .tbl .rct tr.k-tn td:first-child{box-shadow:inset 4px 0 0 #0f8a8a}#rl-app .tbl .rct tr.k-dv td:first-child{box-shadow:inset 4px 0 0 #c2410c}#rl-app .tbl .rct tr.k-am td:first-child{box-shadow:inset 4px 0 0 #7c3aed}#rl-app .tbl .rct tr.k-inc td:first-child{box-shadow:inset 4px 0 0 #2563eb}#rl-app .tbl .rct tr.k-pv td:first-child{box-shadow:inset 4px 0 0 #b45309}#rl-app .tbl .rct tr.k-tm td:first-child{box-shadow:inset 4px 0 0 #0891b2}#rl-app .tbl .rct .chg{font-weight:600}</style>';
  var h=M.heads,th='<tr class="nr"><th></th><th></th><th></th><th>1</th><th>2</th><th></th><th>3</th><th>4</th><th></th><th>5</th><th>6</th><th></th><th></th></tr><tr>'+h.map(function(x){return '<th>'+esc(x)+'</th>'}).join("")+'</tr>';
  var body=M.rows.map(function(r){
    var cs=rcCells(r);
    return '<tr class="k-'+r.kind+'">'+cs.map(function(v,i){
      if(i===0)return '<td></td>';
      if(i===1)return '<td class="cd">'+(v?esc(v):'<span class="hint">—</span>')+'</td>';
      if(i===12)return '<td class="ex">'+esc(v)+'</td>';
      return '<td class="num'+((i===4||i===7||i===10)&&v?' chg':'')+'" title="'+esc(bdEur(v))+'">'+rcN(v)+'</td>';
    }).join("")+'</tr>';
  }).join("");
  var leg='<p class="bdleg">'+RC_ORDER.map(function(k){return '<span class="lg">'+esc(RC_LBL[k])+'</span>'}).join(" ")+'</p>';
  var info='<p class="hint">Ποσά σε € με ΦΠΑ '+(Math.round(bdVat()*10000)/100).toString().replace(".",",")+'% (όπως στον Προϋπολογισμό), σε ακέραια ευρώ· το ακριβές ποσό φαίνεται στο tooltip και στο Excel. Στις γραμμές Α, Δ και Ε το ποσό του έτους είναι η βάση και η προτεινόμενη αλλαγή είναι 0· στις Β και Γ η βάση είναι το εκτιμώμενο κόστος του διαγωνισμού ή το κόστος πριν την πρώτη τροποποίηση και η αλλαγή η διαφορά. Μια σύμβαση που ανήκει σε περισσότερα από ένα κριτήρια εμφανίζεται σε μία ομάδα γραμμών για το καθένα.</p>';
  var tbl=M.rows.length?'<div class="tbl" style="overflow:auto"><table class="rct"><thead>'+th+'</thead><tbody>'+body+'</tbody></table></div>':'<div class="empty"><h2>'+(String(S.q||"").trim()&&M.all?'Καμία γραμμή δεν ταιριάζει':'Δεν υπάρχουν γραμμές')+'</h2><p>'+(String(S.q||"").trim()&&M.all?'Δεν βρέθηκε τίποτα για «'+esc(S.q)+'».':'Ο πίνακας συμπληρώνεται από τους ενεργούς διαγωνισμούς, τις συμβάσεις και τις γενικές πρόνοιες που πληρούν τα κριτήρια.')+'</p></div>';
  $("#list").innerHTML=css+leg+info+tbl;
}
/* the export is the template workbook itself: its header, styles, widths and print setup are kept, only the rows are written */
async function rcExport(){
  try{
    var M=rcModel(),Y=M.Y,z=await zipRead(b64ToU8(RC_XLSX_B64).buffer),dec=new TextDecoder("utf-8"),enc=new TextEncoder();
    var sx=dec.decode(z["xl/worksheets/sheet1.xml"]),cols="ABCDEFGHIJKLM".split("");
    function tc(ref,s,v){return '<c r="'+ref+'" s="'+s+'" t="inlineStr"><is><t xml:space="preserve">'+xmlEsc(v)+'</t></is></c>'}
    var r1=/<row r="1"[\s\S]*?<\/row>/.exec(sx)[0],hs=[5,6,6,7,7,7,8,8,8,9,9,9,10];
    var rows=r1+'<row r="2" spans="1:14" ht="51.75" customHeight="1" thickBot="1">'+M.heads.map(function(h,i){return tc(cols[i]+"2",hs[i],h)}).join("")+'<c r="N2" s="1"/></row>';
    var last=2;
    M.rows.forEach(function(r,k){
      var n=k+3,cs=rcCells(r),lines=0;r.expl.forEach(function(l){lines+=Math.max(1,Math.ceil(l.length/40))});
      var ht=Math.min(400,Math.max(34.5,lines*15));
      rows+='<row r="'+n+'" spans="1:14" ht="'+ht+'" customHeight="1">'+cs.map(function(v,i){
        var s=i===0?19:i===1?11:i===12?30:13,ref=cols[i]+n;
        if(i===0)return '<c r="'+ref+'" s="19"/>';
        if(i===1)return v?tc(ref,s,v):'<c r="'+ref+'" s="11"/>';
        if(i===12)return tc(ref,s,v);
        return '<c r="'+ref+'" s="13"><v>'+v+'</v></c>';
      }).join("")+'</row>';last=n;
    });
    if(!M.rows.length){rows+='<row r="3" spans="1:14" ht="34.5" customHeight="1"><c r="A3" s="19"/></row>';last=3}
    sx=sx.replace(/<sheetData>[\s\S]*<\/sheetData>/,"<sheetData>"+rows+"</sheetData>").replace(/<dimension ref="[^"]*"\s*\/>/,'<dimension ref="A1:N'+last+'" />').replace(/<rowBreaks[\s\S]*?<\/rowBreaks>/,"").replace(/\s*topLeftCell="[^"]*"/,"").replace(/<selection [^>]*\/>/,'<selection activeCell="A3" sqref="A3" />');
    z["xl/worksheets/sheet1.xml"]=enc.encode(sx);
    var nm="Πλαίσιο Συμφιλίωσης",wb=dec.decode(z["xl/workbook.xml"]).replace(/name="Sheet1"/,'name="'+nm+'"').replace(/Sheet1!\$A\$1:\$M\$\d+/,"'"+nm+"'!$A$1:$M$"+Math.max(last,3)).replace(/Sheet1!/g,"'"+nm+"'!");
    z["xl/workbook.xml"]=enc.encode(wb);
    if(z["docProps/app.xml"])z["docProps/app.xml"]=enc.encode(dec.decode(z["docProps/app.xml"]).replace(/>Sheet1</g,">"+nm+"<"));
    var names=Object.keys(z).sort(function(a,b){return a==="[Content_Types].xml"?-1:b==="[Content_Types].xml"?1:0});
    await offer("plaisio-symfiliosis-"+todayIso()+".xlsx",zipBuild(names.map(function(n){return {name:n,data:z[n]}})));
  }catch(e){window.alert("Δεν ήταν δυνατή η εξαγωγή: "+((e&&e.message)||""))}
}

/* ---------- shared render ---------- */
function render(){
  var _ts=$("#tabSt");if(_ts)_ts.setAttribute("aria-selected",String(S.cat==="st"));
  if(S.cat==="st"&&window.RL_CFG&&window.RL_CFG.canManage===false)S.cat="sw";
  if(S.cat==="st"){if(!(S.stDirty&&$("#stRoot")))renderStPage();else stFilter();return}
  var bd=S.cat==="bd",tn=S.cat==="tn",ct=S.cat==="ct",ar=S.cat==="ar",co=S.cat==="co",pv=S.cat==="pv",rc=S.cat==="rc";
  $("#tabSw").setAttribute("aria-selected",String(!ct&&!bd&&!tn&&!ar&&!co&&!pv&&!rc));var tpv=$("#tabPv");if(tpv)tpv.setAttribute("aria-selected",String(pv));var trc=$("#tabRc");if(trc)trc.setAttribute("aria-selected",String(rc));var ta=$("#tabAr");if(ta)ta.setAttribute("aria-selected",String(ar));$("#tabCt").setAttribute("aria-selected",String(ct));
  var tt=$("#tabTn");if(tt)tt.setAttribute("aria-selected",String(tn));
  var tco=$("#tabCo");if(tco)tco.setAttribute("aria-selected",String(co));
  var tb=$("#tabBd");if(tb)tb.setAttribute("aria-selected",String(bd));
  var el=ct||tn||co||pv||rc;
  $("#btnAdd").style.display=bd||ar||rc?"none":"";$("#btnImport").style.display=bd||tn||ar||co||pv||rc?"none":"";$("#btnExport").style.display=ar?"none":"";
  $("#q").style.display="";
  $("#cntSw").textContent=S.items.length||"";$("#cntCt").textContent=S.contracts.length||"";
  var cn=$("#cntTn");if(cn)cn.textContent=S.tenders.length||"";var ca=$("#cntAr");if(ca)ca.textContent=articles().length||"";var cco=$("#cntCo");if(cco)cco.textContent=(S.contractors||[]).length||"";var cpv=$("#cntPv");if(cpv)cpv.textContent=(S.provisions||[]).length||"";
  $("#btnAdd").textContent=pv?"+ Νέα Γενική Πρόνοια":co?"+ Νέος ανάδοχος":tn?"+ Νέος διαγωνισμός":ct?"+ Νέα σύμβαση":"+ Add software";
  $("#btnImport").textContent=ct?"Εισαγωγή Excel":"Import Excel";
  $("#btnExport").textContent=bd||rc||pv?"Εξαγωγή Excel":el?"Εξαγωγή":"Export";
  $("#q").placeholder=ar?"Αναζήτηση άρθρου, κωδικού, κατηγορίας…":tn?"Αναζήτηση διαγωνισμού, αρ. διαγωνισμού…":ct?"Αναζήτηση σύμβασης, ανάδοχου, αρ. διαγωνισμού…":"Search name, vendor, website…";
  if(co)$("#q").placeholder="Αναζήτηση αναδόχου, email…";
  if(bd)$("#q").placeholder="Αναζήτηση στον προϋπολογισμό (άρθρο, δαπάνη)…";
  if(pv)$("#q").placeholder="Αναζήτηση πρόνοιας, άρθρου…";
  if(rc)$("#q").placeholder="Αναζήτηση στο Πλαίσιο Συμφιλίωσης (σύμβαση, διαγωνισμός, τροποποίηση)…";
  $("#stats").setAttribute("lang",el||bd||ar?"el":"en");
  if(ar)renderAr();else if(bd)renderBd();else if(rc)renderRc();else if(pv&&S.filter!=="trash")renderPv();else if(S.filter==="trash")renderTrash(pv?"pv":co?"co":tn?"tn":ct?"ct":"sw");else if(co)renderCo();else if(tn)renderTn();else if(ct)renderCt();else renderSw();
  $("#note").textContent=ar?"Τα άρθρα προϋπολογισμού του Οργανισμού. Κάθε ποσό σε Λογισμικό, Σύμβαση ή Διαγωνισμό συνδέεται με ένα άρθρο και περνά έτσι στον Προϋπολογισμό. Η στήλη «Εγγραφές» δείχνει πόσες εγγραφές (και του Κάδου) χρησιμοποιούν το άρθρο.":bd?"Ο πίνακας υπολογίζεται αυτόματα από τα επιμέρους ποσά (χωρίς ΦΠΑ στις εγγραφές· εδώ προστίθεται ΦΠΑ 19%) κάθε έτους των Συμβάσεων, των ενεργών Διαγωνισμών και των Λογισμικών. Άρθρα με ανάλυση ανά έτος (ΝΑΙ): το ποσό κατανέμεται ανά μήνα στα ημερολογιακά έτη της περιόδου. Τα υπόλοιπα (ΌΧΙ): ολόκληρο στο έτος έναρξης.":tn?"Τα ποσά των ενεργών διαγωνισμών περιλαμβάνονται στον Προϋπολογισμό. Με ακύρωση ή προώθηση σε Σύμβαση αφαιρούνται από εκεί· η συμπερίληψη γίνεται πλέον μέσω της σύμβασης.":S.db?(ct?"Κοινές εγγραφές, αποθηκευμένες στον server. Οι υπενθυμίσεις στέλνονται και με email.":"Shared records, saved on the server. Reminders are also sent by email."):"Storage is not available in this view, so changes last only until you close the page. · Η αποθήκευση δεν είναι διαθέσιμη εδώ.";
  if(co)$("#note").textContent="Η λίστα των αναδόχων. Στις Συμβάσεις ο ανάδοχος επιλέγεται από εδώ και τα στοιχεία του εμφανίζονται μόνο για ανάγνωση· κάθε αλλαγή γίνεται μόνο σε αυτή την καρτέλα. «Ενεργές συμβάσεις»: συμβάσεις που δεν έχουν λήξει. «Αρ. διαγωνισμού»: οι αριθμοί διαγωνισμού των ενεργών συμβάσεων.";
  if(pv)$("#note").textContent="Γενικές πρόνοιες για σκοπούς προϋπολογισμού. Κάθε πρόνοια έχει σχετικό άρθρο και ποσά (χωρίς ΦΠΑ) για τα 3 έτη που ακολουθούν το έτος καταχώρησης. Τα ποσά περιλαμβάνονται αυτόματα στην καρτέλα «Προϋπολογισμός», στο σχετικό άρθρο, με ΦΠΑ.";
  if(rc)$("#note").textContent="Ένας πίνακας στη μορφή του προτύπου Excel, με μία γραμμή ανά εγγραφή και άρθρο: (Α) ενεργοί διαγωνισμοί, (Β) συμβάσεις από διαγωνισμό με μεταβολή κόστους πάνω από "+bdNum(RC_LIMIT)+" €, (Γ) τροποποιημένες συμβάσεις με αλλαγή ποσού, (Δ) συμβάσεις και (Ε) Γενικές Πρόνοιες με επιλεγμένη τη «Συμπερίληψη στο Πλαίσιο Συμφιλίωσης», (ΣΤ) τροποποιημένοι ενεργοί διαγωνισμοί με αλλαγή ποσού. Τα έτη προκύπτουν από το τρέχον έτος.";
  var oc=OWN_COLL[S.cat];
  if(oc&&window.RL_OWN&&window.RL_OWN.restricted(oc)&&$("#note"))$("#note").textContent="Βλέπετε μόνο τις εγγραφές για τις οποίες είστε "+(oc==="contracts"?"συντονιστής":"υπεύθυνος/η")+". "+($("#note").textContent||"");
  var ov=$("#overlay");
  if(S.open&&!ov.hidden&&ov.dataset.kind==="detail"&&!getItem(S.openCat||"sw",S.open))closePanel();
}

/* ---------- Excel import ---------- */
var ALIAS={name:["software name","name","software","ονομασία λογισμικού"],description:["description","περιγραφή"],vendor:["vendor","supplier","προμηθευτής"],
 website:["website","web site","url","site","ιστοσελίδα"],username:["username","user name","user","login"],emails:["notification emails","notification email","emails","email","e-mail","email ειδοποιήσεων"],
 dateFrom:["date from","from","start","start date"],dateTo:["date to","to","end","end date","expiry","expiry date","expires"],
 cost:["cost excl. vat (€)","cost excl. vat","cost without vat","cost","price","amount"],remindDays:["reminder","reminder days","remind days","alert days"]};
function hk(s){return String(s||"").trim().toLowerCase().replace(/\s+/g," ")}
function toIsoDate(v){
  if(v==null||v==="")return "";
  if(v instanceof Date&&!isNaN(v))return iso(new Date(v.getTime()+12*36e5));
  if(typeof v==="number"){var d=new Date(Math.round((v-25569)*864e5));return iso(new Date(d.getUTCFullYear(),d.getUTCMonth(),d.getUTCDate()))}
  var s=String(v).trim(),m;
  if((m=/^(\d{4})-(\d{1,2})-(\d{1,2})/.exec(s)))return m[1]+"-"+pad(+m[2])+"-"+pad(+m[3]);
  if((m=/^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{2,4})$/.exec(s))){var y=+m[3];if(y<100)y+=2000;return y+"-"+pad(+m[2])+"-"+pad(+m[1])}
  return "";
}
function parseSheet(buf){
  var wb=XLSX.read(buf,{type:"array",cellDates:true});
  var ws=wb.Sheets[wb.SheetNames[0]];
  var rows=XLSX.utils.sheet_to_json(ws,{defval:"",raw:true});
  return rows.map(function(r,idx){
    var map={};Object.keys(r).forEach(function(k){map[hk(k)]=r[k]});
    var o={};
    Object.keys(ALIAS).forEach(function(key){for(var i=0;i<ALIAS[key].length;i++){var a=ALIAS[key][i];if(map[a]!==undefined&&map[a]!==""){o[key]=map[a];break}}});
    var rec=norm({name:o.name,description:o.description,vendor:o.vendor,website:o.website,username:o.username,emails:o.emails==null?"":String(o.emails),
      dateFrom:toIsoDate(o.dateFrom),dateTo:toIsoDate(o.dateTo),cost:o.cost==null?"":Number(String(o.cost).replace(/[€\s,]/g,function(c){return c===","?".":""})),remindDays:o.remindDays});
    var errs=[];
    if(!rec.name)errs.push("name missing");
    if(!rec.dateTo)errs.push("Date To missing/invalid");
    if(rec.dateFrom&&rec.dateTo&&rec.dateTo<rec.dateFrom)errs.push("Date To before Date From");
    if(!isFinite(rec.cost))errs.push("cost invalid");
    if(emailsErr(rec.emails))errs.push(emailsErr(rec.emails));
    return {n:idx+2,rec:rec,errs:errs};
  });
}
function showImport(rows){
  S.imp=rows;S.impCat="sw";
  var good=rows.filter(function(r){return !r.errs.length}).length;
  var tr=rows.slice(0,200).map(function(r){
    var x=r.rec;
    return '<tr class="'+(r.errs.length?"badrow":"")+'"><td>'+r.n+'</td><td>'+esc(x.name)+'</td><td>'+esc(x.vendor)+'</td><td>'+fmtDate(x.dateFrom)+'</td><td>'+fmtDate(x.dateTo)+'</td><td class="num">'+(isFinite(x.cost)?money(x.cost):"—")+'</td><td>'+(r.errs.length?esc(r.errs.join(", ")):"OK")+'</td></tr>';
  }).join("");
  openPanel('<div class="ph"><h2>Import preview</h2><button class="btn small" type="button" data-act="close">Cancel</button></div>'+
   '<p class="hint">'+rows.length+' row'+(rows.length==1?"":"s")+' found, '+good+' ready to import. Rows with problems are skipped. Imported rows are added to your existing list.</p>'+
   '<div class="tbl"><table><thead><tr><th>Row</th><th>Software Name</th><th>Vendor</th><th>Date From</th><th>Date To</th><th>Cost</th><th>Check</th></tr></thead><tbody>'+tr+'</tbody></table></div>'+
   '<div class="actions"><button class="btn primary" type="button" data-act="doimport"'+(good?'':' disabled')+'>Import '+good+' row'+(good==1?"":"s")+'</button></div>',"imp",true);
}
async function doImport(){
  var good=(S.imp||[]).filter(function(r){return !r.errs.length}),n=0,miss=0;
  /* WordPress: the coordinator of an imported contract is the user whose name matches; otherwise the contract belongs to the person who imports it */
  if(ownOn()&&S.impCat==="ct"){try{await window.RL_OWN.users().then(function(l){S.ownUsers=l})}catch(e){}}
  for(var i=0;i<good.length;i++){
    var rc=good[i].rec;
    if(ownOn()&&S.impCat==="ct"){var mu=ownMatch(rc.coordinator);if(mu)rc._owner=mu.id;else if(String(rc.coordinator||"").trim())miss++}
    if(await save(uid(),rc,S.impCat||"sw"))n++;
  }
  closePanel();toast("Imported "+n+" row"+(n==1?"":"s")+(miss?" · "+miss+" συμβάσεις: ο συντονιστής δεν αντιστοιχίστηκε σε χρήστη και έγιναν δικές σας":""));
}

function needX(){
  if(typeof XLSX!=="undefined")return false;
  toast("Η βιβλιοθήκη Excel δεν φορτώθηκε. Χρειάζεται σύνδεση στο internet. / Excel library not loaded: internet connection needed.");
  return true;
}
/* ---------- export ---------- */
var HEAD=["Software Name","Description","Vendor","Website","Username","Date From","Date To","Cost excl. VAT (€)","Reminder (days before)","Notification emails","Cost breakdown","Attachments","Milestones","Status"];
function rowsOut(){
  return S.items.slice().sort(function(a,b){return (a.dateTo||"").localeCompare(b.dateTo||"")}).map(function(i){
    return [i.name,i.description,i.vendor,i.website,i.username,i.dateFrom,i.dateTo,Number(i.cost)||0,i.remindDays,i.emails||"",bpText(i),(i.attachments||[]).map(function(a){return a.name}).join("; "),msText(i),status(i).t];
  });
}
async function offer(name,data){
  if(!S.dl){toast("Downloads are not available in this view");return}
  try{await S.dl.save({filename:name,data:data});toast("Saved "+name)}
  catch(e){if(!e||e.code!=="declined")toast("Could not save the file")}
}
function wbBuffer(rows,cols,head){
  head=head||HEAD;
  var ws=XLSX.utils.aoa_to_sheet([head].concat(rows));
  ws["!cols"]=cols||head.map(function(h){return {wch:Math.max(14,h.length+2)}});
  var wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,"Software");
  return XLSX.write(wb,{bookType:"xlsx",type:"array"});
}
function exportXlsx(){if(needX())return;if(S.cat==="co")return coExportXlsx();if(S.cat==="tn")return tnExportXlsx();if(S.cat==="ct")return ctExportXlsx();if(!S.items.length){toast("Nothing to export yet");return}offer("renewal-ledger-"+todayIso()+".xlsx",wbBuffer(swRowsOut(),null,swHead()))}
function exportCsv(){if(S.cat==="co")return coExportCsv();if(S.cat==="tn")return tnExportCsv();if(S.cat==="ct")return ctExportCsv();
  if(!S.items.length){toast("Nothing to export yet");return}
  var q=function(v){v=String(v==null?"":v);return /[",\n;]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v};
  offer("renewal-ledger-"+todayIso()+".csv","﻿"+[swHead()].concat(swRowsOut()).map(function(r){return r.map(q).join(",")}).join("\r\n"));
}
function templateXlsx(){if(needX())return;if(S.cat==="ct")return ctTemplate();
  offer("renewal-ledger-template.xlsx",wbBuffer([["Example App","Team chat","Example Ltd","https://example.com","admin@example.com","2026-01-01","2026-12-31",120,30,"a@example.com, b@example.com","","","",""]]));
}
function showExport(){if(S.cat==="bd")return bdExport();if(S.cat==="rc")return rcExport();if(S.cat==="pv")return pvExport();if(S.cat==="co")return coShowExport();if(S.cat==="tn")return tnShowExport();if(S.cat==="ct")return ctShowExport();
  openPanel('<div class="ph"><h2>Export &amp; import</h2><button class="btn small" type="button" data-act="close">Close</button></div>'+
   '<div class="sec"><h3>Export all software</h3><p class="hint">Includes every field, the reminder setting, attachment file names and the current status. Keep the file safe.</p><div class="actions"><button class="btn primary" type="button" data-act="xlsx">Excel (.xlsx)</button><button class="btn" type="button" data-act="csv">CSV</button></div></div>'+
   '<div class="sec"><h3>Import template</h3><p class="hint">Use these column headings: '+HEAD.slice(0,8).join(", ")+'. Optional: Reminder (days before), Notification emails (several separated by commas). Dates can be dd/mm/yyyy or yyyy-mm-dd.</p><div class="actions"><button class="btn" type="button" data-act="tpl">Download template</button><button class="btn" type="button" data-act="pick">Choose Excel file to import…</button></div></div>',"export");
}


/* ---------- events ---------- */
ROOT.addEventListener("click",async function(ev){
  var t=ev.target;
  if(t.id==="overlay"){if(!formOpen())closePanel();return}
  var b=t.closest("button,[data-f]");if(!b)return;
  var a=b.dataset.act;
  if(a&&stAction(a,b))return;
  if(b.dataset.f&&!a){S.filter=b.dataset.f;if(S.filter==="trash")loadTrash(S.cat);render();return}
  if(b.dataset.sort)return setSort(b.dataset.sort);
  if(b.id==="btnAdd"||b.id==="emAdd")return S.cat==="pv"?pvStart():S.cat==="co"?coStart():S.cat==="tn"?tnStart():S.cat==="ct"?ctStart():startWizard();
  if(b.id==="btnImport"||b.id==="emImp"){$("#fileXlsx").click();return}
  if(b.id==="btnExport")return showExport();
  if(b.id==="emSample")return S.cat==="ct"?ctSample():loadSample();
  if(b.classList.contains("row"))return reopen(S.cat,b.dataset.id);
  if(b.dataset.copy){var it=byId(S.open);try{await navigator.clipboard.writeText(it[b.dataset.copy]||"");toast("Copied")}catch(e){toast("Copy is blocked here — select the text instead")}return}
  if(b.dataset.delfile!==undefined)return removeFile(+b.dataset.delfile);
  if(b.id==="delYes"){var id=S.open;var dc=S.openCat||"sw";if(dc==="co"&&coContracts(id).length){toast("Ο ανάδοχος χρησιμοποιείται σε συμβάσεις και δεν μπορεί να διαγραφεί.");return}if(await remove(id,dc)){closePanel();toastUndo(dc!=="sw"?"Μεταφέρθηκε στον κάδο":"Moved to the trash",function(){restoreItem(dc,id).then(function(ok){if(ok)toast(dc!=="sw"?"Η εγγραφή επαναφέρθηκε":"Record restored")})},null,dc!=="sw")}return}
  if(b.id==="delNo"){$("#delbox").innerHTML="";return}
  switch(a){
    case "close":askClose();break;
    case "pvopen":showPvDetail(b.dataset.id);break;
    case "pvsave":pvSave();break;
    case "pvdel":$("#delbox").innerHTML='<p class="err">Να διαγραφεί η Γενική Πρόνοια; Θα μεταφερθεί στον Κάδο και τα ποσά της θα φύγουν από τον Προϋπολογισμό· μπορείς να την επαναφέρεις.</p><div class="actions"><button class="btn danger" type="button" id="delYes">Ναι, μεταφορά στον κάδο</button><button class="btn" type="button" id="delNo">Άκυρο</button></div>';break;
    case "gocat":S.cat=b.dataset.cat;S.filter="all";S.q="";$("#q").value="";try{localStorage.setItem("rl.cat",S.cat)}catch(e){}render();break;
    case "ctnext":ctNext();break;
    case "ctback":ctCollect();S.cw.err="";S.cw.i--;ctDraw();break;
    case "ctfull":ctCollect();S.cw.mode="full";S.cw.err="";ctDraw();break;
    case "ctstep":ctCollect();S.cw.mode="step";S.cw.i=0;S.cw.err="";ctDraw();break;
    case "ctsave":ctSave();break;
    case "coaddfromct":ctCollect();coStart(null,{fromContract:true,prevDirty:S.dirty});break;
    case "coaddlegacy":{ctCollect();var ld=S.cw.d;coStart(null,{fromContract:true,prevDirty:S.dirty,prefill:{name:ld.contractor,vat:ld.contractorVat,address:ld.contractorAddress,contact:ld.contractorContact,phone:ld.contractorPhone,email:ld.contractorEmail}});break}
    case "cosave":coSave();break;
    case "cocancel":coCancel();break;
    case "comigrate":coMigrate();break;
    case "codel":{var cu=coContracts(S.open);$("#delbox").innerHTML=cu.length?'<p class="err">Ο ανάδοχος χρησιμοποιείται σε '+cu.length+' '+(cu.length===1?'σύμβαση':'συμβάσεις')+' και δεν μπορεί να διαγραφεί. Άλλαξε πρώτα τον ανάδοχο στις συμβάσεις αυτές.</p>':'<p class="err">Να διαγραφεί ο ανάδοχος; Θα μεταφερθεί στον Κάδο και μπορείς να τον επαναφέρεις.</p><div class="actions"><button class="btn danger" type="button" id="delYes">Ναι, μεταφορά στον κάδο</button><button class="btn" type="button" id="delNo">Άκυρο</button></div>';break}
    case "gocontractor":{var gco=b.dataset.id;S.cat="co";S.filter="all";S.q="";$("#q").value="";try{localStorage.setItem("rl.cat","co")}catch(e){}render();showCoDetail(gco);break}
    case "ctamend":ctAmend(S.open);break;
    case "ctsum":ctCollect();var cs=$("#c_cost");if(cs)cs.value=ctSum(S.cw.d.years);break;
    case "tndel":$("#delbox").innerHTML='<p class="err">Να διαγραφεί ο διαγωνισμός; Θα μεταφερθεί στον Κάδο και μπορείς να τον επαναφέρεις.</p><div class="actions"><button class="btn danger" type="button" id="delYes">Ναι, μεταφορά στον κάδο</button><button class="btn" type="button" id="delNo">Άκυρο</button></div>';break;
    case "tncancel":$("#delbox").innerHTML='<p class="err">Να ακυρωθεί ο διαγωνισμός; Θα αποθηκευτεί για αναφορά και τα ποσά του θα αφαιρεθούν από τον Προϋπολογισμό.</p><div class="actions"><button class="btn danger" type="button" data-act="tncancelyes">Ναι, ακύρωση και αποθήκευση για αναφορά</button><button class="btn" type="button" id="delNo">Όχι</button></div>';break;
    case "tncancelyes":tnSetStatus(S.open,"cancelled");break;
    case "tnreopen":tnSetStatus(S.open,"active");break;
    case "tnpromote":tnPromoteStart(S.open);break;
    case "tnamend":tnAmend(S.open);break;
    case "tnapprove":tnSetStatus(S.open,"active");break;
    case "tnreject":tnSetStatus(S.open,"cancelled");break;
    case "gotender":{var gtid=b.dataset.id;S.cat="tn";S.filter="all";S.q="";$("#q").value="";try{localStorage.setItem("rl.cat","tn")}catch(e){}render();showTnDetail(gtid);break}
    case "gocontract":{var gid=b.dataset.id;S.cat="ct";S.filter="all";S.q="";$("#q").value="";try{localStorage.setItem("rl.cat","ct")}catch(e){}render();showCtDetail(gid);break}
    case "ctarch":ctSetArchive(S.open,true);break;
    case "ctunarch":ctSetArchive(S.open,false);break;
    case "ctdel":$("#delbox").innerHTML='<p class="err">Να διαγραφεί η σύμβαση; Θα μεταφερθεί στον Κάδο και μπορείς να την επαναφέρεις.</p><div class="actions"><button class="btn danger" type="button" id="delYes">Ναι, μεταφορά στον κάδο</button><button class="btn" type="button" id="delNo">Άκυρο</button></div>';break;
    case "back":showDetail(b.dataset.id);break;
    case "renewid":S.open=b.dataset.id;S.openCat="sw";showRenew(b.dataset.id);break;
    case "openid":reopen(b.dataset.cat||"sw",b.dataset.id);break;
    case "cols":showCols();break;
    case "arts":showArticles();break;
    case "undo":doUndo();break;
    case "trrestore":{var tc=S.cat;if(await restoreItem(tc,b.dataset.id))toast(tc!=="sw"?"Η εγγραφή επαναφέρθηκε":"Record restored");break}
    case "trpurge":{var pc=S.cat,pit=(S.trash[pc]||[]).find(function(x){return x.id===b.dataset.id});if(!pit)break;
      if(!window.confirm((pc!=="sw"?"ΟΡΙΣΤΙΚΗ διαγραφή «":"PERMANENTLY delete \"")+recName(pc,pit)+(pc!=="sw"?"» και όλων των συνημμένων της; ΔΕΝ μπορεί να αναιρεθεί.":"\" and all its attachments? This CANNOT be undone.")))break;
      if(await purgeItem(pc,b.dataset.id))toast(pc!=="sw"?"Διαγράφηκε οριστικά":"Deleted for good");break}
    case "artsave":saveArticles();break;
    case "artadd":{if(!artCan("create"))break;var rows=$("#artRows");rows.insertAdjacentHTML("beforeend",artRow());var ins=rows.querySelectorAll("tr");ins[ins.length-1].querySelector("input").focus();break}
    case "artdel":{if(!artCan("delete"))break;var tr=b.closest("tr"),cd=tr&&tr.querySelector("[data-k=code]"),us=cd&&cd.defaultValue?artUsage(cd.defaultValue):0;
      if(us){toast(S.cat!=="sw"?"Το άρθρο χρησιμοποιείται σε "+us+" εγγραφές και δεν μπορεί να διαγραφεί":"This article is used by "+us+" record(s) and cannot be deleted");break}
      if(tr)tr.remove();break}
    case "exadd":ctCollect();S.cw.d.extras=S.cw.d.extras||[];S.cw.d.extras.push({id:uid(),kind:"extra",desc:"",amount:"",article:""});{var cx=$("#cExtras");if(cx)cx.innerHTML=exBlock(S.cw.d)}break;
    case "exdel":ctCollect();S.cw.d.extras.splice(+b.dataset.i,1);{var cx2=$("#cExtras");if(cx2)cx2.innerHTML=exBlock(S.cw.d)}break;
    case "bpadd":{var dd=ctLike(S.cat)?(ctCollect(),S.cw.d):(collect(),S.wiz.data);dd.budget=dd.budget||[];dd.budget.push({year:+b.dataset.year||1,amount:"",article:""});bpRedraw();break}
    case "bpdel":{var dd2=ctLike(S.cat)?(ctCollect(),S.cw.d):(collect(),S.wiz.data);dd2.budget.splice(+b.dataset.i,1);if(ctLike(S.cat))(dd2.years||[]).forEach(function(y,i){if(!bpHas(dd2,i+1)&&false)y.cost=""});bpRedraw();break}
    case "colsreset":resetCols();break;
    case "attach":$("#fileAttach").click();break;
    case "msadd":showMsForm(S.openCat||"sw",S.open,null,+b.dataset.year||1);break;
    case "msedit":showMsForm(S.openCat||"sw",S.open,b.dataset.mid);break;
    case "msdel":msDelete(b.dataset.mid);break;
    case "msdone":msToggleDone(b.dataset.mid);break;
    case "msattach":msPick();break;
    case "mssave":msSave();break;
    case "mscancel":msCancel();break;
    case "msrmfile":msCollect();var rm=S.ms.d.attachments.splice(+b.dataset.i,1)[0];if(rm){var ai=S.ms.added.indexOf(rm.id);if(ai>=0){S.ms.added.splice(ai,1);try{S.assets.delete(rm.id)}catch(_){}}else S.ms.removed.push(rm.id)}msDraw();break;
    case "renew":showRenew(S.open);break;
    case "swnote":ntStart(S.open);break;
    case "ntgen":ntGen();break;
    case "guide":showGuide(S.cat);break;
    case "gsec":{var ge=document.getElementById("g-"+b.dataset.id);if(ge&&ge.scrollIntoView)ge.scrollIntoView({behavior:"smooth",block:"start"});break}
    case "rsave":doRenew(b.dataset.id);break;
    case "edit":S.openCat==="pv"?pvStart(S.open):S.openCat==="co"?coStart(S.open):S.openCat==="tn"?tnStart(S.open):S.openCat==="ct"?ctStart(S.open):startWizard(S.open);break;
    case "del":$("#delbox").innerHTML='<p class="err">Delete this software? It moves to the Trash, where you can restore it.</p><div class="actions"><button class="btn danger" type="button" id="delYes">Yes, move to the trash</button><button class="btn" type="button" id="delNo">Keep it</button></div>';break;
    case "wnext":wizNext();break;
    case "wback":collect();S.wiz.err="";S.wiz.i--;drawWizard();break;
    case "wfull":collect();S.wiz.mode="full";S.wiz.err="";drawWizard();break;
    case "wstep":collect();S.wiz.mode="step";S.wiz.i=0;S.wiz.err="";drawWizard();break;
    case "wsave":wizSave();break;
    case "doimport":doImport();break;
    case "xlsx":exportXlsx();break;
    case "csv":exportCsv();break;
    case "tpl":templateXlsx();break;
    case "pick":$("#fileXlsx").click();break;
  }
  if(b.dataset.act&&b.closest("#chips"))return;
});
ROOT.addEventListener("keydown",function(ev){
  if(ev.key==="Enter"&&S.cw&&!S.co&&S.cw.mode==="step"&&ev.target.tagName==="INPUT"){ev.preventDefault();S.cw.i===cwBase().length?ctSave():ctNext()}
  if(ev.key==="Enter"&&S.wiz&&S.wiz.mode==="step"&&ev.target.tagName==="INPUT"){ev.preventDefault();var l=S.wiz.i===swF().length;l?wizSave():wizNext()}
});
ROOT.addEventListener("input",function(ev){var t=ev.target;if(t&&t.closest&&t.closest("#overlay")&&formOpen())S.dirty=true;if(t&&t.id&&t.id.indexOf("bp_amt_")===0)bpLive();else if(t&&t.id&&t.id.indexOf("ex_amt_")===0)exTotals();if(S.cw&&S.cw.am)amLive()});
ROOT.addEventListener("change",async function(ev){
  var t=ev.target;if(t&&t.closest&&t.closest("#overlay")&&formOpen())S.dirty=true;
  if(S.cw&&S.cw.am&&t.closest&&t.closest("#overlay"))setTimeout(amLive,0);
  if(t.id==="bdArt"){S.bdArt=t.value;try{localStorage.setItem("rl.bdart",t.value)}catch(e){}render();return}
  if(t.dataset&&t.dataset.col){toggleCol(t.dataset.col,t.checked);return}
  if(t.id&&t.id.indexOf("bp_amt_")===0){bpLive();return}
  if(t.id==="remSel"){var it=byId(S.open);if(it){var rec=norm(it);rec.remindDays=+t.value;rec.attachments=it.attachments;rec.history=it.history;rec.createdAt=it.createdAt;rec.sample=it.sample;if(await save(it.id,rec))toast("Reminder set to "+t.value+" days before expiry")}}
  if(t.id==="fileXlsx"&&t.files[0]){
    var f=t.files[0];t.value="";
    try{if(needX())return;var buf=await f.arrayBuffer();var ct=S.cat==="ct";var rows=ct?parseCtSheet(buf):parseSheet(buf);if(!rows.length){toast(ct?"Δεν βρέθηκαν γραμμές στο πρώτο φύλλο":"No rows found in the first sheet");return}ct?showCtImport(rows):showImport(rows)}
    catch(e){toast("Could not read that file")}
  }
  if(S.cw&&!S.co&&t.id==="c_contractorId"){ctCollect();var ci=$("#cCtrInfo");if(ci)ci.innerHTML=ctrInfoHtml(S.cw.d)}
  if(S.cw&&(t.id==="c_months"||t.id==="c_dateFrom")){ctCollect();ctRegen();ctRefresh()}
  if(S.cw&&t.id==="c_dateTo"){ctCollect();ctApplyEnd();ctRefresh(true)}
  if(S.cw&&t.id&&t.id.indexOf("cy_cost_")===0){ctCollect();var sp=$("#cSum");if(sp)sp.textContent=mc(ctSum(S.cw.d.years))}
  if(t.classList&&t.classList.contains("yrRem")){var cc=getItem("ct",S.open);if(cc){var rc=strip(cc);rc.years=cc.years.map(function(y,i){return i===+t.dataset.i?Object.assign({},y,{remind:+t.value}):y});if(await save(cc.id,rc,"ct"))toast("Η υπενθύμιση ενημερώθηκε")}}
  if(t.id==="fileAttach"&&t.files.length){var fl=Array.prototype.slice.call(t.files);t.value="";attachFiles(fl)}
});
$("#q").addEventListener("input",function(e){S.q=e.target.value;render()});
document.addEventListener("input",function(e){if(e.target&&e.target.id==="gq")gFilter(e.target.value)});

async function loadSample(){
  var t=todayIso();
  var d=[["Example CRM Suite","Customer records and pipeline","Example Soft Ltd","https://example.com/crm",addDays(t,-340),addDays(t,25),480],
         ["Example Cloud Backup","Offsite backups","Example Cloud","https://example.com/backup",addDays(t,-200),addDays(t,165),220],
         ["Example Design Pack","Design licences","Example Studio","https://example.com/design",addDays(t,-400),addDays(t,-6),360]];
  for(var i=0;i<d.length;i++){var x=d[i];await save(uid(),norm({name:x[0],description:x[1],vendor:x[2],website:x[3],dateFrom:x[4],dateTo:x[5],cost:x[6],remindDays:30,sample:true}))}
}

/* ---------- start ---------- */
async function start(){
  try{var rc=localStorage.getItem("rl.cat");if(rc==="ct"||rc==="bd"||rc==="tn"||rc==="ar"||rc==="co"||rc==="st"||rc==="pv"||rc==="rc")S.cat=rc}catch(e){}
  render();
  var c=window.claude;if(!c||!c.use)return;
  try{S.assets=await c.use("assets")}catch(e){}
  try{S.dl=await c.use("downloads")}catch(e){}
  try{
    var u=await c.use("user"),db=await c.use("db");
    var id=u&&u.id?await u.id():null;
    if(db&&id){
      S.db=db;S.uid=id;
      S.loaded={};
      var sub=function(name,cat,key){return col(name).onSnapshot(function(snap){var all=snap.docs.map(function(d){return Object.assign({id:d.id},d.data())});S[key]=all.filter(function(x){return !x.deletedAt});if(!window.RL_TRASH)S.trash[cat]=all.filter(function(x){return x.deletedAt}).map(function(x){return Object.assign({},x,{_at:x.deletedAt})});S.loaded[cat]=true;if(key==="items")purgePasswords();if(S.loaded.sw&&S.loaded.ct&&S.loaded.tn&&S.loaded.co&&!S.tinit){S.tinit=1;if(!window.RL_CFG)autoTnMaybe();if(window.RL_TRASH){loadTrash("sw");loadTrash("ct");loadTrash("tn");loadTrash("co");loadTrash("pv")}else autoPurge()}render();maybeDigest()},function(){toast("Live sync stopped — reload the page")})};
      S.unsub=[sub("software","sw","items"),sub("contracts","ct","contracts"),sub("tenders","tn","tenders"),sub("contractors","co","contractors"),sub("provisions","pv","provisions")];
    }
  }catch(e){}
  render();
}
start();
})();
